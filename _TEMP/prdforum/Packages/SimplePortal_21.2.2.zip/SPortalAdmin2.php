<?php
/**********************************************************************************
* SPortalAdmin2.php                                                               *
***********************************************************************************
* SimplePortal                                                                    *
* SMF Modification Project Founded by [SiNaN] (sinan@simplemachines.org)          *
* =============================================================================== *
* Software Version:           SimplePortal 2.2.2                                  *
* Software by:                SimplePortal Team (http://www.simpleportal.net)     *
* Copyright 2008-2009 by:     SimplePortal Team (http://www.simpleportal.net)     *
* Support, News, Updates at:  http://www.simpleportal.net                         *
***********************************************************************************
* This program is free software; you may redistribute it and/or modify it under   *
* the terms of the provided license as published by Simple Machines LLC.          *
*                                                                                 *
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
*                                                                                 *
* See the "license.txt" file for details of the Simple Machines license.          *
* The latest version can always be found at http://www.simplemachines.org.        *
**********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

/*
	void SPortalAdmin_Config()
		// !!!

	void GeneralSettings()
		// !!!

	void BlockSettings()
		// !!!

	void ArticleSettings()
		// !!!

	void Information()
		// !!!

	void SPortalAdmin_Blocks()
		// !!!

	void BlockList()
		// !!!

	void BlockEdit()
		// !!!

	void BlockDelete()
		// !!!

	void BlockMove()
		// !!!

	void SPortalAdmin_Articles()
		// !!!

	void ArticleList()
		// !!!

	array getArticleEntry()
		// !!!

	void ArticleAdd()
		// !!!

	void ArticleEdit()
		// !!!

	void ArticleDelete()
		// !!!

	void SPortalAdmin_Categories()
		// !!!

	void CategoryList()
		// !!!

	void CategoryAdd()
		// !!!

	void CategoryEdit()
		// !!!

	void CategoryDelete()
		// !!!

	void StateChange()
		// !!!

	void ColumnChange()
		// !!!
*/

// This is the main function for the 'Configuration' admin area.
function SPortalAdmin_Config()
{
	global $context, $txt, $scripturl, $sourcedir;

	// Can you moderate it my dear?
	isAllowedTo('sp_moderate');

	// Love this template. :)
	loadTemplate('SPortalAdmin2');

	// Include for the saveDBSettings and prepareDBSettings function.
	require_once($sourcedir . '/ManageServer.php');

	// Setup some stuff for the template.
	$context['page_title'] = $txt['sp-adminTitle'];
	
	// Setup some more information for the menu template.
	$context[$context['admin_menu_name']]['tab_data'] = array(
		'title' => $txt['sp-adminConfiguration'],
		'help' => 'sp_ConfigurationArea',
		'description' => $txt['sp-adminConfigurationDesc'],
	);

	// General area actions.
	$subActions = array(
		'information' => 'Information',
		'generalsettings' => 'GeneralSettings',
		'blocksettings' => 'BlockSettings',
		'articlesettings' => 'ArticleSettings',
	);

	// No actions set? Gives us a pretty info page then!
	$_REQUEST['sa'] = isset($_REQUEST['sa']) && isset($subActions[$_REQUEST['sa']]) ? $_REQUEST['sa'] : 'information';

	// Show us the right way to go.
	$subActions[$_REQUEST['sa']]();
}

function GeneralSettings($return_config = '')
{
	global $smcFunc, $context, $scripturl, $txt;

	$request = $smcFunc['db_query']('','
		SELECT id_theme, value AS name
		FROM {db_prefix}themes
		WHERE variable = {string:name}
			AND id_member = {int:member}
		ORDER BY id_theme',
		array(
			'member' => 0,
			'name' => 'name',
		)
	);
	$context['SPortal']['themes'] = array('0' => &$txt['portalthemedefault']);
	while ($row = $smcFunc['db_fetch_assoc']($request))
		$context['SPortal']['themes'][$row['id_theme']] = $row['name'];
	$smcFunc['db_free_result']($request);

	$config_vars = array(
			array('select', 'sp_portal_mode', explode('|', $txt['sp_portal_mode_options'])),
			array('check', 'sp_maintenance'),
			array('text', 'sp_standalone_url'),
		'',
			array('select', 'portaltheme', $context['SPortal']['themes']),
			array('check', 'sp_disableColor'),
			array('check', 'sp_disableForumRedirect'),
			array('check', 'sp_disable_random_bullets'),
			array('check', 'sp_disable_php_validation'),
			array('check', 'sp_disable_side_collapse'),
	);
	
	if ($return_config)
		return $config_vars;

	if (isset($_GET['save']))
	{
		checkSession();

		saveDBSettings($config_vars);
		redirectexit('action=admin;area=sportalconfig;sa=generalsettings');
	}
	
	$context['post_url'] = $scripturl . '?action=admin;area=sportalconfig;sa=generalsettings;save';
	$context['settings_title'] = $txt['sp-adminGeneralSettingsName'];
	$context['sub_template'] = 'general_settings';

	prepareDBSettingContext($config_vars);
}

function BlockSettings($return_config = '')
{
	global $context, $scripturl, $txt;

	$config_vars = array(
			array('check', 'showleft'),
			array('check', 'showright'),
			array('text', 'leftwidth'),
			array('text', 'rightwidth'),
		'',
			array('check', 'sp_enableIntegration'),
			array('multicheck', 'sp_IntegrationHide', 'subsettings' => array('sp_adminIntegrationHide' => $txt['admin'], 'sp_profileIntegrationHide' => $txt['profile'], 'sp_pmIntegrationHide' => $txt['personal_messages'], 'sp_mlistIntegrationHide' => $txt['members_title'], 'sp_searchIntegrationHide' => $txt['search'], 'sp_calendarIntegrationHide' => $txt['calendar'], 'sp_moderateIntegrationHide' => $txt['moderate'])),
	);

	if ($return_config)
		return $config_vars;

	if (isset($_GET['save']))
	{
		checkSession();

		$width_checkup = array('left', 'right');
		foreach ($width_checkup as $pos) 
		{
			if (!empty($_POST[$pos . 'width'])) 
			{
				if (stripos($_POST[$pos . 'width'], 'px') !== false)
					$suffix = 'px';
				elseif (strpos($_POST[$pos . 'width'], '%') !== false)
					$suffix = '%';
				else
					$suffix = '';

				preg_match_all('/(?:([0-9]+)|.)/i', $_POST[$pos . 'width'], $matches);

				$number = (int) implode('', $matches[1]);
				if (!empty($number) && $number > 0)
					$_POST[$pos . 'width'] = $number . $suffix;
				else
					$_POST[$pos . 'width'] = '';
			}
			else
				$_POST[$pos . 'width'] = '';
		}

		unset($config_vars[7]);
		$config_vars = array_merge(
			$config_vars,
			array(
				array('check', 'sp_adminIntegrationHide'),
				array('check', 'sp_profileIntegrationHide'),
				array('check', 'sp_pmIntegrationHide'),
				array('check', 'sp_mlistIntegrationHide'),
				array('check', 'sp_searchIntegrationHide'),
				array('check', 'sp_calendarIntegrationHide'),
				array('check', 'sp_moderateIntegrationHide'),
			)
		);

		saveDBSettings($config_vars);
		redirectexit('action=admin;area=sportalconfig;sa=blocksettings');
	}

	$context['post_url'] = $scripturl . '?action=admin;area=sportalconfig;sa=blocksettings;save';
	$context['settings_title'] = $txt['sp-adminBlockSettingsName'];
	$context['sub_template'] = 'general_settings';

	prepareDBSettingContext($config_vars);
}

function ArticleSettings($return_config = '')
{
	global $context, $scripturl, $txt;

	$config_vars = array(
			array('check', 'articleactive'),
			array('int', 'articleperpage'),
			array('int', 'articlelength'),
			array('check', 'articleavatar'),
	);

	if ($return_config)
		return $config_vars;

	if (isset($_GET['save']))
	{
		checkSession();

		saveDBSettings($config_vars);
		redirectexit('action=admin;area=sportalconfig;sa=articlesettings');
	}

	$context['post_url'] = $scripturl . '?action=admin;area=sportalconfig;sa=articlesettings;save';
	$context['settings_title'] = $txt['sp-adminArticleSettingsName'];
	$context['sub_template'] = 'general_settings';

	prepareDBSettingContext($config_vars);
}

// The most important function of SP. :P
function Information($in_admin = true)
{
	global $context, $scripturl, $txt, $sourcedir, $sportal_version, $user_profile;

	$context['sp_credits'] = array(
		array(
			'pretext' => $txt['sp-info_intro'],
			'title' => $txt['sp-info_team'],
			'groups' => array(
				array(
					'title' => $txt['sp-info_groups_pm'],
					'members' => array(
						'Eliana Tamerin',
						'Huw',
					),
				),
				array(
					'title' => $txt['sp-info_groups_dev'],
					'members' => array(
						'<span onclick="if (getInnerHTML(this).indexOf(\'Sinan\') == -1) setInnerHTML(this, \'Sinan &quot;\' + getInnerHTML(this) + \'&quot; &Ccedil;evik\'); return false;">[SiNaN]</span>',
						'LHVWB',
						'&#12487;&#12451;&#12531;1031',
					),
				),
				array(
					'title' => $txt['sp-info_groups_support'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_customize'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_language'],
					'members' => array(
						'Jade &quot;Alundra&quot; Elizabeth',
					),
				),
				array(
					'title' => $txt['sp-info_groups_marketing'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_beta'],
					'members' => array(
						'Robbo',
						'BurkeKnight',
						'Mulgarus',
						'Ya&#287;&#305;z...',
					),
				),
			),
		),
		array(
			'title' => $txt['sp-info_special'],
			'posttext' => $txt['sp-info_anyone'],
			'groups' => array(
				array(
					'title' => $txt['sp-info_groups_translators'],
					'members' => array(
						$txt['sp-info_translators_message'],
					),
				),
				array(
					'title' => $txt['sp-info_groups_founder'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_orignal_pm'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_fam_fam'],
					'members' => array(
						$txt['sp-info_fam_fam_message'],
					),
				),
			),
		),
	);

	if (!$in_admin)
	{
		loadTemplate('SPortalAdmin2');

		$context['robot_no_index'] = true;
		$context['in_admin'] = false;
	}
	else
	{
		$context['in_admin'] = true;
		$context['sp_version'] = $sportal_version;
		$context['sp_managers'] = array();

		require_once($sourcedir . '/Subs-Members.php');
		$manager_ids = loadMemberData(membersAllowedTo('sp_moderate'), false, 'minimal');

		if ($manager_ids)
			foreach ($manager_ids as $member)
				$context['sp_managers'][] = '<a href="' . $scripturl . '?action=profile;u=' . $user_profile[$member]['id_member'] . '">' . $user_profile[$member]['real_name'] . '</a>';
	}

	$context['sub_template'] = 'information';
	$context['page_title'] = $txt['sp-info_title'];
}

// This is the main function for the 'Blocks' admin area.
function SPortalAdmin_Blocks()
{
	global $context, $txt, $scripturl, $sourcedir;

	// Can you moderate it my dear?
	isAllowedTo('sp_moderate');

	// Love this template. :)
	loadTemplate('SPortalAdmin2');

	// Rather a *small* one, yeah? :P
	$subActions = array(
		'list' => 'BlockList',
		'left' => 'BlockList',
		'right' => 'BlockList',
		'top' => 'BlockList',
		'bottom' => 'BlockList',
		'add' => 'BlockEdit',
		'edit' => 'BlockEdit',
		'delete' => 'BlockDelete',
		'move' => 'BlockMove',
		'statechange' => 'StateChange',
		'columnchange' => 'ColumnChange',
	);

	// Set the default as the general settings.
	$_REQUEST['sa'] = isset($_REQUEST['sa']) && isset($subActions[$_REQUEST['sa']]) ? $_REQUEST['sa'] : 'list';

	// Setup some stuff for the template.
	$context['page_title'] = $txt['sp-adminTitle'];
	$context['sub_action'] = $_REQUEST['sa'];
	
	// Setup some more information for the menu template.
	$context[$context['admin_menu_name']]['tab_data'] = array(
		'title' => $txt['sp-blocksBlocks'],
		'help' => 'sp_BlocksArea',
		'description' => $txt['sp-adminBlockListDesc'],
		'tabs' => array(
			'list' => array(
				'description' => $txt['sp-adminBlockListDesc'],
			),
			'add' => array(
				'description' => $txt['sp-adminBlockAddDesc'],
			),
			'left' => array(
				'description' => $txt['sp-adminBlockLeftListDesc'],
			),
			'top' => array(
				'description' => $txt['sp-adminBlockTopListDesc'],
			),
			'bottom' => array(
				'description' => $txt['sp-adminBlockBottomListDesc'],
			),
			'right' => array(
				'description' => $txt['sp-adminBlockRightListDesc'],
			),
		),
	);

	// We need this everywhere.
	require_once($sourcedir . '/Subs-SPortal2.php');

	// Call the right function.
	$subActions[$_REQUEST['sa']]();
}

// Show the Block List.
function BlockList()
{
	global $txt, $context;

	// We have 4 sides...
	$context['SPortal']['sides'] = array(
		'left' => array(
			'id' => '1',
			'name' => 'adminLeft',
			'label' => $txt['sp-positionLeft'],
			'help' => 'sp-blocksLeftList',
		),
		'top' => array(
			'id' => '2',
			'name' => 'adminTop',
			'label' => $txt['sp-positionTop'],
			'help' => 'sp-blocksTopList',
		),
		'bottom' => array(
			'id' => '3',
			'name' => 'adminBottom',
			'label' => $txt['sp-positionBottom'],
			'help' => 'sp-blocksBottomList',
		),
		'right' => array(
			'id' => '4',
			'name' => 'adminRight',
			'label' => $txt['sp-positionRight'],
			'help' => 'sp-blocksRightList',
		),
	);
	
	$sides = array('left', 'top', 'bottom', 'right');
	// Are we viewing any of the sub lists for an individual side?
	if(in_array($context['sub_action'], $sides))
	{
		// Remove any sides that we don't need to show. ;)
		foreach($sides as $side)
		{
			if($context['sub_action'] != $side)
				unset($context['SPortal']['sides'][$side]);
		}
		$context['sp_blocks_single_side_list'] = true;
	}

	// Columns to show.
	$context['SPortal']['columns'] = array(
		'label' => array(
			'width' => '40%',
			'label' => $txt['sp-adminColumnName'],
		),
		'type' => array(
			'width' => '40%',
			'label' => $txt['sp-adminColumnType'],
		),
		'move' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnMove'],
		),
		'action' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnAction'],
		),
	);

	// Get the block info for each side.
	foreach($context['SPortal']['sides'] as $side)
		$context['SPortal']['blocks'][$side['name']] = getBlockInfo($side['id']);

	// Call the sub template.
	$context['sub_template'] = 'block_list';
}

// Adding or editing a block.
function BlockEdit()
{
	global $txt, $context, $modSettings, $smcFunc;

	$context['SPortal']['is_new'] = empty($_REQUEST['block_id']);

	if ($context['SPortal']['is_new'] && empty($_POST['selected_type']) && empty($_POST['add_block']))
	{
		$context['SPortal']['block_types'] = getFunctionInfo();
			
		if (!empty($_REQUEST['col']))
			$context['SPortal']['block']['column'] = $_REQUEST['col'];

		$context['sub_template'] = 'block_select_type';
	}
	elseif ($context['SPortal']['is_new'] && !empty($_POST['selected_type']))
	{
		$context['SPortal']['block'] = array(
			'id' => 0,
			'label' => $txt['sp-blocksDefaultLabel'],
			'type' => $_POST['selected_type'][0],
			'type_text' => !empty($txt['sp_function_' . $_POST['selected_type'][0] . '_label']) ? $txt['sp_function_' . $_POST['selected_type'][0] . '_label'] : $txt['sp_function_unknown_label'],
			'column' => !empty($_POST['block_column']) ? $_POST['block_column'] : 0,
			'row' => 0,
			'state' => 1,
			'force_view' => 0,
			'allowed_groups' => 'all',
			'permission_type' => 0,
			'display' => '',
			'display_custom' => '',
			'style' => '',
			'parameters' => array(),
			'options'=> $_POST['selected_type'][0](array(), false, true),
			'list_blocks' => !empty($_POST['block_column']) ? getBlockInfo($_POST['block_column']) : array(),
		);
	}
	elseif (!$context['SPortal']['is_new'] && empty($_POST['add_block']))
	{
		$_REQUEST['block_id'] = (int) $_REQUEST['block_id'];
		$context['SPortal']['block'] = current(getBlockInfo(null, $_REQUEST['block_id']));

		$context['SPortal']['block'] += array(
			'options'=> $context['SPortal']['block']['type'](array(), false, true),
			'list_blocks' => getBlockInfo($context['SPortal']['block']['column']),
		);

		if ($context['SPortal']['block']['type'] == 'sp_php' && isset($context['SPortal']['block']['parameters']['content']))
			$context['SPortal']['block']['parameters']['content'] = htmlspecialchars($context['SPortal']['block']['parameters']['content']);
	}

	if (!empty($_POST['preview_block']))
	{
		if (empty($_POST['display_advanced']))
		{
			if (!empty($_POST['display_simple']) && in_array($_POST['display_simple'], array('all', 'sportal', 'sforum', 'allaction', 'allboard')))
				$display = $_POST['display_simple'];
			else
				$display = '';

			$custom = '';
		}
		else
		{
			$display = array();
			$custom = array();

			if (!empty($_POST['display_actions']))
				foreach ($_POST['display_actions'] as $action)
					$display[] = $smcFunc['htmlspecialchars']($action, ENT_QUOTES);
			
			if (!empty($_POST['display_boards']))
				foreach ($_POST['display_boards'] as $board)
					$display[] = (int) $board;

			if (!empty($_POST['display_custom']))
			{
				$temp = explode(',', $_POST['display_custom']);
				foreach ($temp as $action)
					$custom[] = $smcFunc['htmlspecialchars']($smcFunc['htmltrim']($action), ENT_QUOTES);
			}

			$display = empty($display) ? '' : implode(', ', $display);
			$custom = empty($custom) ? '' : implode(', ', $custom);
		}

		$style = '';
		$style_parameters = array(
			'title_default_class',
			'title_custom_class',
			'title_custom_style',
			'body_default_class',
			'body_custom_class',
			'body_custom_style',
			'no_title',
			'no_body',
		);

		foreach ($style_parameters as $parameter)
			if (isset($_POST[$parameter]))
				$style .= $parameter . '~' . $smcFunc['htmlspecialchars']($smcFunc['htmltrim']($_POST[$parameter]), ENT_QUOTES) . '|';
			else
				$style .= $parameter . '~|';

		if (!empty($style))
			$style = substr($style, 0, -1);

		$context['SPortal']['block'] = array(
			'id' => $_POST['block_id'],
			'label' => $_POST['block_name'],
			'type' => $_POST['block_type'],
			'type_text' => !empty($txt['sp_function_' . $_POST['block_type'] . '_label']) ? $txt['sp_function_' . $_POST['block_type'] . '_label'] : $txt['sp_function_unknown_label'],
			'column' => $_POST['block_column'],
			'row' => !empty($_POST['block_row']) ? $_POST['block_row'] : 0,
			'state' => !empty($_POST['block_active']),
			'force_view' => !empty($_POST['block_force']),
			'allowed_groups' => $_POST['member_groups'],
			'permission_type' => $_POST['permission_type'],
			'display' => $display,
			'display_custom' => $custom,
			'style' => $style,
			'parameters' => !empty($_POST['parameters']) ? $_POST['parameters'] : array(),
			'options'=> $_POST['block_type'](array(), false, true),
			'list_blocks' => getBlockInfo($_POST['block_column']),
			'collapsed' => false,
		);

		if (strpos($modSettings['leftwidth'], '%') !== false || strpos($modSettings['leftwidth'], 'px') !== false)
			$context['widths'][1] = $modSettings['leftwidth'];
		else
			$context['widths'][1] = $modSettings['leftwidth'] . 'px';

		if (strpos($modSettings['rightwidth'], '%') !== false || strpos($modSettings['rightwidth'], 'px') !== false)
			$context['widths'][4] = $modSettings['rightwidth'];
		else
			$context['widths'][4] = $modSettings['rightwidth'] . 'px';

		if (strpos($context['widths'][1], '%') !== false)
			$context['widths'][2] = $context['widths'][3] = 100 - ($context['widths'][1] + $context['widths'][4]) . '%';
		elseif (strpos($context['widths'][1], 'px') !== false)
			$context['widths'][2] = $context['widths'][3] = 960 - ($context['widths'][1] + $context['widths'][4]) . 'px';

		$context['SPortal']['preview'] = true;
	}

	if (!empty($_POST['selected_type']) || !empty($_POST['preview_block']) || (!$context['SPortal']['is_new'] && empty($_POST['add_block'])))
	{
		if ($context['SPortal']['block']['type'] == 'sp_php' && !allowedTo('admin_forum'))
			fatal_lang_error('cannot_admin_forum', false);

		$context['html_headers'] .= '
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		function sp_collapseObject(id)
		{
			mode = document.getElementById("sp_object_" + id).style.display == "" ? 0 : 1;
			document.getElementById("sp_collapse_" + id).src = smf_images_url + (mode ? "/collapse.gif" : "/expand.gif");
			document.getElementById("sp_object_" + id).style.display = mode ? "" : "none";
		}
	// ]]></script>';

		loadLanguage('SPortalHelp', sp_languageSelect('SPortalHelp'));

		if (isset($_POST['member_groups']))
			$context['SPortal']['block']['allowed_groups'] = $_POST['member_groups'];

		sp_loadMemberGroups($context['SPortal']['block']['allowed_groups']);

		$context['simple_actions'] = array(
			'sportal' => $txt['sp-portal'],
			'sforum' => $txt['sp-forum'],
			'allaction' => $txt['sp-blocksOptionAllActions'],
			'allboard' => $txt['sp-blocksOptionAllBoards'],
			'all' => $txt['sp-blocksOptionAllPages'],
		);

		$context['display_actions'] = array(
			'portal' => $txt['sp-portal'],
			'forum' => $txt['sp-forum'],
			'recent' => $txt['recent_posts'],
			'unread' => $txt['unread_topics_visit'],
			'unreadreplies' => $txt['unread_replies'],
			'profile' => $txt['profile'],
			'pm' => $txt['pm_short'],
			'calendar' => $txt['calendar'],
			'admin' =>  $txt['admin'],
			'login' =>  $txt['login'],
			'register' =>  $txt['register'],
			'post' =>  $txt['post'],
			'stats' =>  $txt['forum_stats'],
			'search' =>  $txt['search'],
			'mlist' =>  $txt['members_list'],
			'moderate' =>  $txt['moderate'],
			'help' =>  $txt['help'],
			'who' =>  $txt['who_title'],
		);

		$request = $smcFunc['db_query']('','
			SELECT id_board, name
			FROM {db_prefix}boards
			ORDER BY name DESC'
		);
		$context['display_boards'] = array();
		while ($row = $smcFunc['db_fetch_assoc']($request))
			$context['display_boards'][$row['id_board']] = $row['name'];
		$smcFunc['db_free_result']($request);

		if (empty($context['SPortal']['block']['display']))
			$context['SPortal']['block']['display'] = array('0');
		else
			$context['SPortal']['block']['display'] = explode(', ', $context['SPortal']['block']['display']);

		if (in_array($context['SPortal']['block']['display'][0], array('all', 'sportal', 'sforum', 'allaction', 'allboard')) || $context['SPortal']['is_new'] || empty($context['SPortal']['block']['display'][0]) && empty($context['SPortal']['block']['display_custom']))
			$context['SPortal']['block']['display_type'] = 0;
		else
			$context['SPortal']['block']['display_type'] = 1;

		if (!empty($context['SPortal']['block']['style']))
		{
			$temp = explode('|', $context['SPortal']['block']['style']);
			$context['SPortal']['block']['style'] = array();

			foreach ($temp as $style)
			{
				list ($key, $value) = explode('~', $style);
				$context['SPortal']['block']['style'][$key] = $value;
			}
		}
		else
		{
			$context['SPortal']['block']['style'] = array(
				'title_default_class' => 'catbg',
				'title_custom_class' => '',
				'title_custom_style' => '',
				'body_default_class' => 'windowbg',
				'body_custom_class' => '',
				'body_custom_style' => '',
				'no_title' => false,
				'no_body' => false,
			);
		}

		$context['sub_template'] = 'block_edit';
	}

	if (!empty($_POST['add_block']))
	{
		if ($_POST['block_type'] == 'sp_php' && !allowedTo('admin_forum'))
			fatal_lang_error('cannot_admin_forum', false);

		if (!isset($_POST['block_name']) || $smcFunc['htmltrim']($smcFunc['htmlspecialchars']($_POST['block_name']), ENT_QUOTES) === '')
			fatal_lang_error('error_sp_name_empty', false);
		
		if ($_POST['block_type'] == 'sp_php' && !empty($_POST['block_content']) && empty($modSettings['sp_disable_php_validation']))
		{
			$error = sp_validate_php($_POST['block_content']);

			if ($error)
				fatal_lang_error('error_sp_php_' . $error, false);
		}

		if (!empty($_POST['placement']) && (($_POST['placement'] == 'before') || ($_POST['placement'] == 'after')))
		{
			if (!empty($_REQUEST['block_id']) && ($temp = current(getBlockInfo(null, $_REQUEST['block_id']))))
				$current_row = $temp['row'];
			else
				$current_row = null;

			if ($_POST['placement'] == 'before')
				$row = (int) $_POST['block_row'];
			else
				$row = (int) $_POST['block_row'] + 1;
			
			if (!empty($current_row) && ($row > $current_row))
			{
				$row = $row - 1;

				$smcFunc['db_query']('', '
					UPDATE {db_prefix}sp_blocks
					SET row = row - 1
					WHERE col = {int:col}
						AND row > {int:start}
						AND row <= {int:end}',
					array(
						'col' => (int) $_POST['block_column'],
						'start' => $current_row,
						'end' => $row,
					)
				);
			}
			else
			{
				$smcFunc['db_query']('', '
					UPDATE {db_prefix}sp_blocks
					SET row = row + 1
					WHERE col = {int:col}
						AND row >= {int:start}' . (!empty($current_row) ? '
						AND row < {int:end}' : ''),
					array(
						'col' => (int) $_POST['block_column'],
						'start' => $row,
						'end' => !empty($current_row) ? $current_row : 0,
					)
				);
			}
		}
		elseif (!empty($_POST['placement']) && $_POST['placement'] == 'nochange') 
			$row = 0;
		else 
		{
			$request =  $smcFunc['db_query']('','
				SELECT row
				FROM {db_prefix}sp_blocks
				WHERE col = {int:col}' . (!empty($_REQUEST['block_id']) ? '
					AND id_block != {int:current_id}' : '' ) . '
				ORDER BY row DESC
				LIMIT 1',
				array(
					'col' => $_POST['block_column'],   
					'current_id' => $_REQUEST['block_id'],
				)
			);
			list ($row) = $smcFunc['db_fetch_row']($request);
			$smcFunc['db_free_result']($request);

			$row = $row + 1;
		}

		$type_parameters = $_POST['block_type'](array(), 0, true);

		if (!empty($_POST['parameters']) && is_array($_POST['parameters']) && !empty($type_parameters))
		{
			foreach ($type_parameters as $name => $type)
			{
				if (isset($_POST['parameters'][$name]))
				{
					if ($type == 'int' || $type == 'select')
						$_POST['parameters'][$name] = (int) $_POST['parameters'][$name];
					elseif (($type == 'text' || $type == 'content') && $_POST['block_type'] != 'sp_php')
						$_POST['parameters'][$name] = $smcFunc['htmlspecialchars']($_POST['parameters'][$name], ENT_QUOTES);
					elseif ($type == 'check')
						$_POST['parameters'][$name] = !empty($_POST['parameters'][$name]) ? 1 : 0;
				}
			}
		}
		else
			$_POST['parameters'] = array();

		if (!empty($_POST['member_groups']) && is_array($_POST['member_groups']))
			$_POST['allowed_groups'] = implode(',', $_POST['member_groups']);
		else
			$_POST['allowed_groups'] = '';

		if (empty($_POST['display_advanced']))
		{
			if (!empty($_POST['display_simple']) && in_array($_POST['display_simple'], array('all', 'sportal', 'sforum', 'allaction', 'allboard')))
				$display = $_POST['display_simple'];
			else
				$display = '';

			$custom = '';
		}
		else
		{
			$display = array();
			$custom = array();

			if (!empty($_POST['display_actions']))
				foreach ($_POST['display_actions'] as $action)
					$display[] = $smcFunc['htmlspecialchars']($action, ENT_QUOTES);
			
			if (!empty($_POST['display_boards']))
				foreach ($_POST['display_boards'] as $board)
					$display[] = (int) $board;

			if (!empty($_POST['display_custom']))
			{
				$temp = explode(',', $_POST['display_custom']);
				foreach ($temp as $action)
					$custom[] = $smcFunc['htmlspecialchars']($smcFunc['htmltrim']($action), ENT_QUOTES);
			}

			$display = empty($display) ? '' : implode(', ', $display);
			$custom = empty($custom) ? '' : implode(', ', $custom);
		}

		$style = '';
		$style_parameters = array(
			'title_default_class',
			'title_custom_class',
			'title_custom_style',
			'body_default_class',
			'body_custom_class',
			'body_custom_style',
			'no_title',
			'no_body',
		);

		foreach ($style_parameters as $parameter)
			if (isset($_POST[$parameter]))
				$style .= $parameter . '~' . $smcFunc['htmlspecialchars']($smcFunc['htmltrim']($_POST[$parameter]), ENT_QUOTES) . '|';
			else
				$style .= $parameter . '~|';

		if (!empty($style))
			$style = substr($style, 0, -1);

		$blockInfo = array(
			'id' => (int) $_POST['block_id'],
			'label' => $smcFunc['htmlspecialchars']($_POST['block_name'], ENT_QUOTES),
			'type' => $_POST['block_type'],
			'col' => $_POST['block_column'],
			'row' => $row,
			'state' => !empty($_POST['block_active']) ? 1 : 0,
			'force_view' => !empty($_POST['block_force']) ? 1 : 0,
			'allowed_groups' => $_POST['allowed_groups'],
			'permission_type' => empty($_POST['permission_type']) || $_POST['permission_type'] > 2 ? 0 : $_POST['permission_type'],
			'display' => $display,
			'display_custom' => $custom,
			'style' => $style,
		);

		if ($context['SPortal']['is_new'])
		{
			unset($blockInfo['id']);

			$smcFunc['db_insert']('',
				'{db_prefix}sp_blocks',
				array(
					'label' => 'string',
					'type' => 'string',
					'col' => 'int',
					'row' => 'int',
					'state' => 'int',
					'force_view' => 'int',
					'allowed_groups' => 'string',
					'permission_type' => 'string',
					'display' => 'string',
					'display_custom' => 'string',
					'style' => 'string',
				),
				$blockInfo,
				array('id_block')
			);

			$blockInfo['id'] = $smcFunc['db_insert_id']('{db_prefix}sp_blocks', 'id_block');
		}
		else
		{
			$block_fields = array(
				"label = {string:label}",
				"state = {int:state}",
				"force_view = {int:force_view}",
				"allowed_groups = {string:allowed_groups}",
				"permission_type = {string:permission_type}",
				"display = {string:display}",
				"display_custom = {string:display_custom}",
				"style = {string:style}",
			);

			if (!empty($blockInfo['row']))
				$block_fields[] = "row = {int:row}";
			else
				unset($blockInfo['row']);

			$smcFunc['db_query']('','
				UPDATE {db_prefix}sp_blocks
				SET ' . implode(', ', $block_fields) . '
				WHERE id_block = {int:id}',
				$blockInfo
			);

			$smcFunc['db_query']('','
				DELETE FROM {db_prefix}sp_parameters
				WHERE id_block = {int:id}',
				array(
					'id' => $blockInfo['id'],
				)
			);
		}

		if (!empty($_POST['parameters']))
		{
			$parameters = array();
			foreach ($_POST['parameters'] as $variable => $value)
				$parameters[] = array(
					'id_block' => $blockInfo['id'],
					'variable' => $variable,
					'value' => $value,
				);

			$smcFunc['db_insert']('',
				'{db_prefix}sp_parameters',
				array(
					'id_block' => 'int',
					'variable' => 'string',
					'value' => 'string',
				),
				$parameters,
				array()
			);
		}

		redirectexit('action=admin;area=blocks');
	}
}

// Function for deleting a block.
function BlockDelete()
{
	global $smcFunc;

	// Check if he can?
	checkSession('get');

	// Make sure ID is an integer.
	$_REQUEST['block_id'] = (int) $_REQUEST['block_id'];

	// Do we have that?
	if(empty($_REQUEST['block_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// Make sure column ID is an integer too.
	$_REQUEST['col'] = (int) $_REQUEST['col'];

	// Only Admins can Remove PHP Blocks
	if(!allowedTo('admin_forum'))
	{
		$context['SPortal']['block'] = current(getBlockInfo(null, $_REQUEST['block_id']));
		if($context['SPortal']['block']['type'] == 'sp_php' && !allowedTo('admin_forum'))
			fatal_lang_error('cannot_admin_forum', false);
	}
	
	// We don't need it anymore.
	$smcFunc['db_query']('','
		DELETE FROM {db_prefix}sp_blocks
		WHERE id_block = {int:id}',
		array(
			'id' => $_REQUEST['block_id'],
		)
	);

	$smcFunc['db_query']('','
		DELETE FROM {db_prefix}sp_parameters
		WHERE id_block = {int:id}',
		array(
			'id' => $_REQUEST['block_id'],
		)
	);

	// Fix column rows.
	fixColumnRows($_REQUEST['col']);

	// Return back to the block list.
	redirectexit('action=admin;area=blocks');
}

// Function for moving a block.
function BlockMove()
{
	// Check if he can?
	checkSession('get');

	// Make sure ID is an integer.
	$_REQUEST['block_id'] = (int) $_REQUEST['block_id'];

	// Check it!
	if(empty($_REQUEST['block_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// Change it with the magical tool.
	changeBlockRow($_REQUEST['block_id'], $_REQUEST['direction']);

	$area = !empty($_GET['redirect']) ? $_GET['redirect'] : 'list';

	// Return back to the block list.
	redirectexit('action=admin;area=blocks;sa=' . $area);
}

// This is the main function for the 'Articles' admin area.
function SPortalAdmin_Articles()
{
	global $context, $txt, $scripturl, $sourcedir;

	// Can you moderate it my dear?
	isAllowedTo('sp_moderate');

	// Love this template. :)
	loadTemplate('SPortalAdmin2');

	// Rather a *small* one, yeah? :P
	$subActions = array(
		'list' => 'ArticleList',
		'add' => 'ArticleAdd',
		'edit' => 'ArticleEdit',
		'delete' => 'ArticleDelete',
		'statechange' => 'StateChange',
	);

	// Set the default as the general settings.
	$_REQUEST['sa'] = isset($_REQUEST['sa']) && isset($subActions[$_REQUEST['sa']]) ? $_REQUEST['sa'] : 'list';

	// Setup some stuff for the template.
	$context['page_title'] = $txt['sp-adminTitle'];
	$context['sub_action'] = $_REQUEST['sa'];
	
	// Setup some more information for the menu template.
	$context[$context['admin_menu_name']]['tab_data'] = array(
		'title' => $txt['sp-adminCatTitle'],
		'help' => 'sp_ArticlesArea',
		'description' => $txt['sp-adminCatDesc'],
		'tabs' => array(
			'list' => array(
				'description' => $txt['sp-adminArticleListDesc'],
			),
			'add' => array(
				'description' => $txt['sp-adminArticleAddDesc'],
			),
		),
	);

	// We need this everywhere.
	require_once($sourcedir . '/Subs-SPortal2.php');

	// Call the right function.
	$subActions[$_REQUEST['sa']]();
}

// Function to 'Show' a list of Articles, and allow 'quick' deletion of them.
function ArticleList()
{
	global $txt, $smcFunc, $context, $article_request, $scripturl;

	// Call the template.
	$context['sub_template'] = 'article_list';

	// You clicked the remove button? Naughty boy. :P
	if (!empty($_POST['removeArticles']) && !empty($_POST['remove']) && is_array($_POST['remove']))
	{
		// Are you even allowed to be here?
		checkSession();

		// Sanitize the articles to remove non integers.
		foreach ($_POST['remove'] as $index => $article_id)
			$_POST['remove'][(int) $index] = (int) $article_id;

		$article_count = count($_POST['remove']);

		// Delete the required articles.
		$smcFunc['db_query']('','
			DELETE FROM {db_prefix}sp_articles
			WHERE id_article IN ({array_int:remove}) ' . ($article_count > 1 ? '
			LIMIT {int:limit}' : ''),
			array(
				'remove' => $_POST['remove'],
				'limit' => $article_count,
			)
		);
		
		// Fix the category article count.
		fixCategoryArticles();
	}

	// How can we sort the list of articles?
	$sort_methods = array(
		'topic' =>  array(
			'down' => 'm.subject ASC',
			'up' => 'm.subject DESC'
		),
		'board' => array(
			'down' => 'b.name ASC',
			'up' => 'b.name DESC'
		),
		'poster' => array(
			'down' => 'm.poster_name ASC',
			'up' => 'm.poster_name DESC'
		),
		'time' => array(
			'down' => 'm.poster_time ASC',
			'up' => 'm.poster_time DESC'
		),
		'category' => array(
			'down' => 'c.name ASC',
			'up' => 'c.name DESC'
		),
		'approved' => array(
			'down' => 'a.approved ASC',
			'up' => 'a.approved DESC'
		),
	);

	// Columns to show.
	$context['columns'] = array(
		'topic' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnTopic'],
			'sortable' => true
		),
		'board' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnBoard'],
			'sortable' => true
		),
		'poster' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnPoster'],
			'sortable' => true
		),
		'time' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnTime'],
			'sortable' => true
		),
		'category' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnCategory'],
			'sortable' => true
		),
		'approved' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnApproved'],
			'sortable' => true,
		),
		'actions' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnAction'],
			'sortable' => false
		)
	);

	// Default sort is according to the topic.
	if (!isset($_REQUEST['sort']) || !isset($sort_methods[$_REQUEST['sort']]))
		$_REQUEST['sort'] = 'topic';

	// Setup the sort links.
	foreach ($context['columns'] as $col => $dummy)
	{
		$context['columns'][$col]['selected'] = $col == $_REQUEST['sort'];
		$context['columns'][$col]['href'] = $scripturl . '?action=admin;area=articles;sa=list;sort=' . $col;

		if (!isset($_REQUEST['desc']) && $col == $_REQUEST['sort'])
			$context['columns'][$col]['href'] .= ';desc';

		$context['columns'][$col]['link'] = '<a href="' . $context['columns'][$col]['href'] . '">' . $context['columns'][$col]['label'] . '</a>';
	}

	$context['sort_by'] = $_REQUEST['sort'];
	$context['sort_direction'] = !isset($_REQUEST['desc']) ? 'down' : 'up';

	// Count all the articles.
	$request = $smcFunc['db_query']('','
		SELECT COUNT(*)
		FROM {db_prefix}sp_articles'
	);
	list ($totalArticles) =  $smcFunc['db_fetch_row']($request);
	$smcFunc['db_free_result']($request);

	// Construct the page index. 20 articles per page.
	$context['page_index'] = constructPageIndex($scripturl . '?action=admin;area=articles;sa=list;sort=' . $_REQUEST['sort'] . (isset($_REQUEST['desc']) ? ';desc' : ''), $_REQUEST['start'], $totalArticles, 20);
	$context['start'] = $_REQUEST['start'];

	// A *small* query to get article info.
	$article_request = $smcFunc['db_query']('','
		SELECT a.id_article, a.id_category, a.id_message, a.approved, c.name as cname, m.id_member, m.poster_name,
			m.poster_time, m.subject, t.id_topic, t.num_replies, t.num_views, b.id_board, b.name as bname, mem.real_name		
		FROM {db_prefix}sp_articles AS a
			LEFT JOIN {db_prefix}sp_categories AS c ON (c.id_category = a.id_category)
			LEFT JOIN {db_prefix}messages AS m ON (m.id_msg = a.id_message)
			LEFT JOIN {db_prefix}topics AS t ON (t.id_first_msg = a.id_message)
			LEFT JOIN {db_prefix}boards AS b ON (b.id_board = m.id_board)
			LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = m.id_member)
		ORDER BY {raw:sort}
		LIMIT {int:start}, {int:limit}',
		array(
			'sort' => $sort_methods[$_REQUEST['sort']][$context['sort_direction']],
			'start' => $context['start'],
			'limit' => 20,
		)
	);

	// Call-back...
	$context['get_article'] = 'getArticleEntry';
}

// Call-back for getting a row of article data.
function getArticleEntry($reset = false)
{
	global $scripturl, $article_request, $txt, $context, $settings, $smcFunc;

	if ($article_request == false)
		return false;

	if (!($row = $smcFunc['db_fetch_assoc']($article_request)))
		return false;

	// Build up the array.		
	$output = array(
		'article' => array(
			'id' => $row['id_article'],
			'approved' => $row['approved'],
		),
		'category' => array(
			'id' => $row['id_category'],
			'name' => '<a href="' . $scripturl . '?action=admin;area=categories;sa=edit;category_id=' . $row['id_category'] . '">'.$row['cname'].'</a>',
		),
		'message' => array(
			'id' => $row['id_message'],
			'subject' => $row['subject'],
			'time' => timeformat($row['poster_time'], '%H:%M:%S, %d/%m/%y'),
		),
		'poster' => array(
			'id' => $row['id_member'],
			'name' => $row['poster_name'],
			'link' => !empty($row['id_member']) ? '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '">' . $row['real_name'] . '</a>' : $row['poster_name'],
		),
		'topic' => array(
			'id' => $row['id_topic'],
			'replies' => $row['num_replies'],
			'views' => $row['num_views'],
			'link' => '<a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.0">' . $row['subject'] . '</a>',
		),
		'board' => array(
			'id' => $row['id_board'],
			'name' => $row['bname'],
			'link' => '<a href="' . $scripturl . '?board=' . $row['id_board'] . '.0">' . $row['bname'] . '</a>',
		),
		'edit' => '<a href="' . $scripturl . '?action=admin;area=articles;sa=edit;article_id=' . $row['id_article'] . ';' . $context['session_var'] . '=' . $context['session_id'] . '">' . sp_embed_image('modify') . '</a>',
		'delete' => '<a href="' . $scripturl . '?action=admin;area=articles;sa=delete;article_id=' . $row['id_article'] . ';' . $context['session_var'] . '=' . $context['session_id'] . '" onclick="return confirm(\'' . $txt['sp-articlesDeleteConfirm'] . '\');">' . sp_embed_image('delete') . '</a>'
	);

	return $output;
}

// Function for adding articles.
function ArticleAdd()
{
	global $txt, $context, $scripturl, $smcFunc, $modSettings;

	// Are we ready?
	if(empty($_POST['createArticle']) || empty($_POST['articles'])) 
	{
		// List all the categories.
		$context['list_categories'] = getCategoryInfo();

		// Do we have any category to add?
		if(empty($context['list_categories']))
			fatal_error($txt['error_sp_no_category'] . '<br />' . (allowedTo('sp_moderate') ? sprintf($txt['error_sp_no_category_sp_moderator'], $scripturl . '?action=admin;area=categories;sa=add') : $txt['error_sp_no_category_normaluser']), false);
			
		// Which board to show?
		if(isset($_REQUEST['targetboard']))
			$_REQUEST['targetboard'] = (int) $_REQUEST['targetboard'];
		else 
		{
			// Find one yourself.
			$request = $smcFunc['db_query']('','
				SELECT id_board
				FROM {db_prefix}boards
				WHERE redirect = \'\'
				ORDER BY id_board DESC
				LIMIT 1'
			);
			list ($_REQUEST['targetboard']) = $smcFunc['db_fetch_row']($request);
			$smcFunc['db_free_result']($request);
		}
		
		$context['target_board'] = $_REQUEST['targetboard'];

		// Get the total topic count.
		$request = $smcFunc['db_query']('','
			SELECT COUNT(*)
			FROM {db_prefix}topics as t
				LEFT JOIN {db_prefix}sp_articles as a ON (a.id_message = t.id_first_msg)
			WHERE id_board = {int:targetboard}
				AND IFNULL(a.id_article, 0) = 0',
			array(
				'targetboard' => $_REQUEST['targetboard'],
			)
		);
		list ($topiccount) = $smcFunc['db_fetch_row']($request);
		$smcFunc['db_free_result']($request);

		// Create the page index.
		$context['page_index'] = constructPageIndex($scripturl . '?action=admin;area=articles;sa=add;targetboard=' . $_REQUEST['targetboard'] . ';board=' . $_REQUEST['targetboard'] . '.%d', $_REQUEST['start'], $topiccount, $modSettings['defaultMaxTopics'], true);

		// Get some info about the boards and categories.
		$request = $smcFunc['db_query']('','
			SELECT b.id_board, b.name AS bName, c.name AS cName
			FROM {db_prefix}boards AS b
				LEFT JOIN {db_prefix}categories AS c ON (c.id_cat = b.id_cat)
			WHERE b.redirect = \'\''
		);
		$context['boards'] = array();
		while ($row = $smcFunc['db_fetch_assoc']($request))
			$context['boards'][] = array(
				'id' => $row['id_board'],
				'name' => $row['bName'],
				'category' => $row['cName']
			);
		$smcFunc['db_free_result']($request);

		// Time to get the topic data.
		$request = $smcFunc['db_query']('','
			SELECT t.id_topic, m.subject, m.id_member, IFNULL(mem.real_name, m.poster_name) AS poster_name, m.id_msg
			FROM ({db_prefix}topics AS t, {db_prefix}messages AS m)
				LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = m.id_member)
				LEFT JOIN {db_prefix}sp_articles as a ON (a.id_message = t.id_first_msg)
			WHERE m.id_msg = t.id_first_msg
				AND IFNULL(a.id_article, 0) = {int:article}
				AND t.id_board = {int:targetboard}
			ORDER BY ' . (!empty($modSettings['enableStickyTopics']) ? 't.is_sticky DESC, ' : '') . 't.id_last_msg DESC
			LIMIT {int:start}, {int:max}',
			array(
				'article' => 0,
				'targetboard' => $_REQUEST['targetboard'],
				'start' => $_REQUEST['start'],
				'max' => $modSettings['defaultMaxTopics'],
			)
		);
		$context['topics'] = array();
		while ($row = $smcFunc['db_fetch_assoc']($request))
		{
			censorText($row['subject']);

			$context['topics'][] = array(
				'id' => $row['id_topic'],
				'msg_id' => $row['id_msg'],
				'poster' => array(
					'id' => $row['id_member'],
					'name' => $row['poster_name'],
					'href' => empty($row['id_member']) ? '' : $scripturl . '?action=profile;u=' . $row['id_member'],
					'link' => empty($row['id_member']) ? $row['poster_name'] : '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" target="_blank">' . $row['poster_name'] . '</a>'
				),
				'subject' => $row['subject'],
				'js_subject' => addcslashes(addslashes($row['subject']), '/')
			);
		}
		$smcFunc['db_free_result']($request);

		// Set the page title and sub-template.
		$context['page_title'] = $txt['sp-articlesAdd'];
		$context['sub_template'] = 'article_add';
	}
	else 
	{
		// But can you?
		checkSession();

		// Are they integer?
		foreach ($_POST['articles'] as $index => $article_id)
			$_POST['articles'][(int) $index] = (int) $article_id;
			
		// Add all of them.
		foreach($_POST['articles'] as $article) {

			// Set them. They have their own IDs.
			$articleOptions = array(
				'id_category' => !empty($_POST['category']) ? (int) $_POST['category'] : 0,
				'id_message' => $article,
				'approved' => 1,
			);

			// A tricky function.
			createArticle($articleOptions);
		}

		// Time to go back.
		redirectexit('action=admin;area=articles');
	}
}

// Function for editing an article.
function ArticleEdit()
{
	global $txt, $smcFunc, $context;
	global $func;

	// Seems that we aren't ready.
	if(empty($_POST['add_article'])) 
	{
		// Check it as we just accept integer.
		$_REQUEST['article_id'] = (int) $_REQUEST['article_id'];

		// Do we know the one to be edited?
		if(empty($_REQUEST['article_id']))
			fatal_lang_error('error_sp_id_empty', false);

		// Get the article info.
		$context['article_info'] = getArticleInfo($_REQUEST['article_id']);
		$context['article_info'] = $context['article_info'][0];

		// List all the categories.
		$context['list_categories'] = getCategoryInfo();

		// Call the right template.
		$context['sub_template'] = 'article_edit';
	}
	else 
	{
		// A small array.
		$articleInfo = array(
			'category' => $_POST['category'],
			'approved' => empty($_POST['approved']) ? '0' : '1',
		);

		// Do it please.
		$smcFunc['db_query']('','
			UPDATE {db_prefix}sp_articles
			SET id_category = {int:category}, approved = {int:approved}
			WHERE id_article = {int:id}',
			array(
				'id' => $_POST['article_id'],
				'category' => $articleInfo['category'],
				'approved' => $articleInfo['approved'],
			)
		);

		// Fix the article counts.
		fixCategoryArticles();

		// I wanna go back to the list. :)
		redirectexit('action=admin;area=articles');
	}
}

// Deleting an article...
function ArticleDelete()
{
	global $smcFunc, $context;

	// Check if he can?
	checkSession('get');

	// We just accept integers.
	$_REQUEST['article_id'] = (int) $_REQUEST['article_id'];
	
	// Can't delete without an ID.
	if(empty($_REQUEST['article_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// Life is short... Delete it.
	$smcFunc['db_query']('','
		DELETE FROM {db_prefix}sp_articles
		WHERE id_article = {int:id}',
		array(
			'id' => $_REQUEST['article_id'],
		)
	);

	// Fix the article counts.
	fixCategoryArticles();
	
	// Again comes the list.
	redirectexit('action=admin;area=articles');
}

// Function to handle the category admin pages.
function SPortalAdmin_Categories()
{
	global $context, $txt, $scripturl, $sourcedir;

	// Can you moderate it my dear?
	isAllowedTo('sp_moderate');

	// Love this template. :)
	loadTemplate('SPortalAdmin2');

	$subActions = array(
		'list' => 'CategoryList',
		'add' => 'CategoryAdd',
		'edit' => 'CategoryEdit',
		'delete' => 'CategoryDelete',
		'statechange' => 'StateChange',
	);

	// Set the default as the general settings.
	$_REQUEST['sa'] = isset($_REQUEST['sa']) && isset($subActions[$_REQUEST['sa']]) ? $_REQUEST['sa'] : 'list';

	// Setup some stuff for the template.
	$context['page_title'] = $txt['sp-adminTitle'];
	$context['sub_action'] = $_REQUEST['sa'];
	
	// Setup some more information for the menu template.
	$context[$context['admin_menu_name']]['tab_data'] = array(
		'title' => $txt['sp-adminCatTitle'],
		'help' => 'sp_CategoriesArea',
		'description' => $txt['sp-adminCatDesc'],
		'tabs' => array(
			'list' => array(
				'description' => $txt['sp-adminCategoryListDesc'],
			),
			'add' => array(
				'description' => $txt['sp-adminCategoryAddDesc'],
			),
		),
	);

	// We need this everywhere.
	require_once($sourcedir . '/Subs-SPortal2.php');

	// Call the right function.
	$subActions[$_REQUEST['sa']]();
}

// Gets the category list.
function CategoryList()
{
	global $txt, $context;

	// Category list columns.
	$context['columns'] = array(
		'picture' => array(
			'width' => '35%',
			'label' => $txt['sp-adminColumnPicture'],
		),
		'name' => array(
			'width' => '45%',
			'label' => $txt['sp-adminColumnName'],
		),
		'articles' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnArticles'],
		),
		'publish' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnPublish'],
		),
		'action' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnAction'],
		),
	);

	// Get all the categories.
	$context['categories'] = getCategoryInfo();

	// Call the sub template.
	$context['sub_template'] = 'category_list';
}

// Function for adding a category.
function CategoryAdd()
{
	global $txt, $smcFunc, $context, $func;

	// Not actually adding a category? Show the add category page.
	if(empty($_POST['add_category'])) 
	{
		// Just we need the template.
		$context['sub_template'] = 'category_add';
	}
	// Adding a category? Lets do this thang! ;D
	else 
	{
		// Session check.
		checkSession();

		// Category name can't be empty.
		if (empty($_POST['category_name']))
			fatal_lang_error('error_sp_name_empty', false);

		// A small info array.
		$categoryInfo = array(
			'name' => $smcFunc['htmlspecialchars']($_POST['category_name'], ENT_QUOTES),
			'picture' => $smcFunc['htmlspecialchars']($_POST['picture_url'], ENT_QUOTES),
			'publish' => empty($_POST['show_on_index']) ? '0' : '1',
		);
		
		// Insert the category data.
		$smcFunc['db_insert']('normal', '{db_prefix}sp_categories',
			// Columns to insert.
			array(
				'name' => 'string',
				'picture' => 'string',
				'articles' => 'int',
				'publish' => 'int'
			),
			// Data to put in.
			array(
				'name' => $categoryInfo['name'],
				'picture' => $categoryInfo['picture'],
				'articles' => 0,
				'publish' => $categoryInfo['publish']
			),
			// We had better tell SMF about the key, even though I can't remember why? ;)
			array('id_category')
		);
		
		// Return back to the category list.
		redirectexit('action=admin;area=categories');
	}
}

// Handles the category edit issue.
function CategoryEdit()
{
	global $txt, $smcFunc, $context, $func;

	// Not Time to edit? Show the cagegory edit page.
	if(empty($_POST['add_category'])) 
	{
		// Be sure you made it an integer.
		$_REQUEST['category_id'] = (int) $_REQUEST['category_id'];

		// Show you ID.
		if(empty($_REQUEST['category_id']))
			fatal_lang_error('error_sp_id_empty', false);

		// Get the category info. You need in template.
		$context['category_info'] = getCategoryInfo($_REQUEST['category_id']);
		$context['category_info'] = $context['category_info'][0];

		// Call the right sub template.
		$context['sub_template'] = 'category_edit';
	}
	// Perform the actual edits.
	else 
	{
		// Again.
		checkSession();

		// Why empty? :S
		if (empty($_POST['category_name']))
			fatal_lang_error('error_sp_name_empty', false);

		// Array for the db.		
		$categoryInfo = array(
			'name' => $smcFunc['htmlspecialchars']($_POST['category_name'], ENT_QUOTES),
			'picture' => $smcFunc['htmlspecialchars']($_POST['picture_url'], ENT_QUOTES),
			'publish' => empty($_POST['show_on_index']) ? '0' : '1',
		);

		// What to change?
		$category_fields = array();
		$category_fields[] = "name = {string:name}";
		$category_fields[] = "picture = {string:picture}";
		$category_fields[] = "publish = {int:publish}";

		// Go on.
		$smcFunc['db_query']('','
			UPDATE {db_prefix}sp_categories
			SET ' . implode(', ', $category_fields) . '
			WHERE id_category = {int:id}',
			array(
				'id' => $_POST['category_id'],
				'name' => $categoryInfo['name'],
				'picture' => $categoryInfo['picture'],
				'publish' => $categoryInfo['publish'],
			)
		);

		// Take him back to the list.
		redirectexit('action=admin;area=categories');
	}
}

// Does more than deleting...
function CategoryDelete()
{
	global $smcFunc, $context;

	// Is an id set? If yes, then we need to get some category information.
	if(!empty($_REQUEST['category_id'])) 
	{
		// Be sure you made it an integer.
		$_REQUEST['category_id'] = (int) $_REQUEST['category_id'];

		// Do you know which one to delete?
		if(empty($_REQUEST['category_id']))
			fatal_lang_error('error_sp_id_empty', false);

		// Get the category info. You need in template.
		$context['category_info'] = getCategoryInfo($_REQUEST['category_id']);
		$context['category_info'] = $context['category_info'][0];

		// Also get the category list.
		$context['list_categories'] = getCategoryInfo();

		// If we have one, that is itself. Delete it.
		if(count($context['list_categories']) < 2)
			$context['list_categories'] = array();
	}

	if(empty($_REQUEST['category_id']) && empty($_POST['category_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// No need to delete articles if category has no articles. But articles are executed if there isn't any other category. :P
	if(empty($_POST['delete_category']) && !empty($context['category_info']['articles'])) 
	{
		// Call the right sub template.
		$context['sub_template'] = 'category_delete';
	}
	elseif(!empty($_POST['delete_category'])) 
	{
		// Again.
		checkSession();

		// Are we going to move something?
		if(!empty($_POST['category_move']) && !empty($_POST['category_move_to'])) {

			// We just need an integer.
			$_POST['category_move_to'] = (int) $_POST['category_move_to'];
			
			// These are the lucky ones, move them.
			$smcFunc['db_query']('','
				UPDATE {db_prefix}sp_articles
				SET id_category = {int:category_move_to}
				WHERE id_category = {int:category_id}',
				array(
					'category_move_to' => $_POST['category_move_to'],
					'category_id' => $_POST['category_id'],
				)
			);
			
			// Fix the article counts.
			fixCategoryArticles();
		}
		else 
		{
			// Kill 'em all. (It's not the Metallica album. :P)
			$smcFunc['db_query']('','
				DELETE FROM {db_prefix}sp_articles
				WHERE id_category = {int:category_id}',
				array(
					'category_id' => $_POST['category_id'],
				)
			);
		}
			
		// Everybody will die one day...
		$smcFunc['db_query']('','
			DELETE FROM {db_prefix}sp_categories
			WHERE id_category = {int:category_id}',
			array(
				'category_id' => $_POST['category_id'],
			)
		);
		
		// Return to the list.
		redirectexit('action=admin;area=categories');
	}
	else 
	{
		// Again.
		checkSession('get');

		// Just delete the category.
		$smcFunc['db_query']('','
			DELETE FROM {db_prefix}sp_categories
			WHERE id_category = {int:category_id}',
			array(
				'category_id' => $_REQUEST['category_id'],
			)
		);

		// Fix the article counts.
		fixCategoryArticles();
			
		// Return to the list.
		redirectexit('action=admin;area=categories');
	}
}

// Function for changing the state of everything.
function StateChange()
{
	// Check if he can?
	checkSession('get');

	// Make sure ID is an integer.
	if (!empty($_REQUEST['block_id']))
		$id = (int) $_REQUEST['block_id'];
	elseif (!empty($_REQUEST['category_id']))
		$id = (int) $_REQUEST['category_id'];
	elseif (!empty($_REQUEST['article_id']))
		$id = (int) $_REQUEST['article_id'];
	else
		fatal_lang_error('error_sp_id_empty', false);

	// I love these Subs functions. :)
	changeState($_REQUEST['type'], $id);
	
	// Return back to the list where we were.
	if($_REQUEST['type'] == 'block')
	{
		$sides = array(1 => 'left', 2 => 'top', 3 => 'bottom', 4 => 'right');
		$list = !empty($_GET['redirect']) && isset($sides[$_GET['redirect']]) ? $sides[$_GET['redirect']] : 'list';
		
		redirectexit('action=admin;area=blocks;sa=' . $list);
	}
	elseif($_REQUEST['type'] == 'category')
		redirectexit('action=admin;area=categories');
	elseif($_REQUEST['type'] == 'article')
		redirectexit('action=admin;area=articles');
	else
		redirectexit('action=admin;area=sportalconfig');
}

function ColumnChange()
{
	global $smcFunc;

	checkSession('get');

	if (empty($_REQUEST['block_id']))
		fatal_lang_error('error_sp_id_empty', false);
	else
		$id = (int) $_REQUEST['block_id'];

	if (empty($_REQUEST['to']) || !in_array($_REQUEST['to'], array('left', 'right')))
		fatal_lang_error('error_sp_side_wrong', false);
	else
		$to = $_REQUEST['to'];

	$request =  $smcFunc['db_query']('','
		SELECT col
		FROM {db_prefix}sp_blocks
		WHERE id_block = {int:block_id}
		LIMIT 1',
		array(
			'block_id' => $id,
		)
	);
	list ($from) = $smcFunc['db_fetch_row']($request);
	$smcFunc['db_free_result']($request);

	if (empty($from))
		fatal_lang_error('error_sp_block_wrong', false);

	$to = ($to == 'left') ? ($from - 1) : ($from + 1);

	if ($to < 1 || $to > 4)
		fatal_lang_error('error_sp_side_wrong', false);

	$smcFunc['db_query']('','
		UPDATE {db_prefix}sp_blocks
		SET col = {int:to}, row = {int:row}
		WHERE id_block = {int:block_id}',
		array(
			'block_id' => $id,
			'to' => $to,
			'row' => 100,
		)
	);

	fixColumnRows($from);
	fixColumnRows($to);
	
	$sides = array(1 => 'left', 2 => 'top', 3 => 'bottom', 4 => 'right');
	$list = isset($_GET['redirect']) ? $sides[$to] : 'list';
	
	redirectexit('action=admin;area=blocks;sa=' . $list);
}

?>