<?php
// Version: 2.2.2; SPortalAdmin
// Last Revision: Sunday, March 29th by Jade (Alundra), who was sick at the time, so don't pick on her for mistakes!! :P
// I dub this the confusing file. You can never be sure where THAT string is displayed. They're phantom strings.

// Configuration area
$txt['sp-adminConfiguration'] = 'Configuration';
$txt['sp-adminConfigurationDesc'] = 'This area allows you to view SimplePortal information and manage SimplePortal settings.';
$txt['sp-adminGeneralSettingsName'] = 'General Settings';
$txt['sp-adminBlockSettingsName'] = 'Block Settings';
$txt['sp-adminArticleSettingsName'] = 'Article Settings';

// General settings
$txt['portalactive'] = 'Enable SimplePortal';
$txt['sp_portal_mode'] = 'Portal Mode';
$txt['sp_portal_mode_options'] = 'Disabled|Front Page|Integration|Standalone';
$txt['sp_maintenance'] = 'Maintenance Mode';
$txt['sp_standalone_url'] = 'Standalone URL';
$txt['sp_disableForumRedirect'] = 'Disable Portal Redirection';
$txt['sp_disableColor'] = 'Disable Colored Member Links';
$txt['sp_disable_random_bullets'] = 'Disable Colored Bullets on Blocks';
$txt['sp_disable_php_validation'] = 'Disable PHP Validation<br /><span class="smalltext">Recommended value: Off</span>';
$txt['sp_disable_side_collapse'] = 'Disable Side Collapsing';
$txt['portaltheme'] = 'Portal Theme';
$txt['portalthemedefault'] = 'Forum Default';

// Block settings
$txt['showleft'] = 'Enable Left Side Blocks';
$txt['showright'] = 'Enable Right Side Blocks';
$txt['leftwidth'] = 'Width of Left Side Blocks';
$txt['rightwidth'] = 'Width of Right Side Blocks';
$txt['sp_enableIntegration'] = 'Display Blocks in Forum';
$txt['sp_IntegrationHide'] = 'Hide Blocks in Forum Areas<br /><span class="smalltext">The <em>Display blocks in Forum</em> setting<br />must be enabled for this to work</span>';

// Article settings
$txt['articleactive'] = 'Enable Articles';
$txt['articleperpage'] = 'Maximum Articles Per Page';
$txt['articlelength'] = 'Maximum Characters Before Article Cut-off';
$txt['articleavatar'] = 'Display Authors Avatar';

// Blocks area
$txt['sp-adminBlockListName'] = 'Block List';
$txt['sp-adminBlockListDesc'] = 'This page displays a list of all blocks which have been created for the portal or the forum.';
$txt['sp-adminBlockAddName'] = 'Add Block';
$txt['sp-adminBlockAddDesc'] = 'This page enables new blocks to be created and added to the portal page or the forum.';
$txt['sp-adminBlockLeftListDesc'] = 'This page displays a list of all left side blocks which have been created. These blocks can be modified by selecting the appropriate options.';
$txt['sp-adminBlockRightListDesc'] = 'This page displays a list of all right side blocks which have been created. These blocks can be modified by selecting the appropriate options.';
$txt['sp-adminBlockTopListDesc'] = 'This page displays a list of all top area blocks which have been created. These blocks can be modified by selecting the appropriate options.';
$txt['sp-adminBlockBottomListDesc'] = 'This page displays a list of all bottom area blocks which have been created. These blocks can be modified by selecting the appropriate options.';

// Block list
$txt['sp-blocksBlocks'] = 'Blocks';
$txt['sp-blocksActive'] = 'Active';
$txt['sp-blocksMoveUp'] = 'Move Up';
$txt['sp-blocksMoveDown'] = 'Move Down';
$txt['sp-blocksMoveLeft'] = 'Move Left';
$txt['sp-blocksMoveRight'] = 'Move Right';
$txt['sp-blocksActivate'] = 'Activate';
$txt['sp-blocksDeactivate'] = 'Deactivate';
$txt['sp-blocksCreate'] = 'Create %s Block';
$txt['sp-deleteblock'] = 'Are you sure you want to delete this block?';

// Add/Edit blocks
$txt['sp-blocksSelectType'] = 'Select Block Type';
$txt['sp-blocksAdd'] = 'Add Block';
$txt['sp-blocksEdit'] = 'Edit Block';
$txt['sp-blocksPreview'] = 'Preview';
$txt['sp-blocksDefaultLabel'] = 'Untitled';
$txt['sp-blocksPermissionAll'] = 'All Membergroups';
$txt['sp-blocksPermissionOne'] = 'One Membergroup';
$txt['sp-blocksPermissionIgnore'] = 'Ignore Permissions';
$txt['sp-blocksDisabledBoth'] = 'Left and right side blocks are currently disabled';
$txt['sp-blocksDisabledLeft'] = 'Left side blocks are currently disabled';
$txt['sp-blocksDisabledRight'] = 'Right side blocks are currently disabled';
$txt['sp-blocksPermissions'] = 'Block Permissions';
$txt['sp-blocksPermissionType'] = 'Permission Settings';
$txt['sp-blocksContent'] = 'Content';
$txt['sp-blocksColumn'] = 'Column';
$txt['sp-blocksRow'] = 'Order';
$txt['sp-blocksForce'] = 'Not Collapsible';
$txt['sp-blocksActive'] = 'Active';
$txt['sp-blocksDisplayOptions'] = 'Display Options';
$txt['sp-blocksAdvancedOptions'] = 'Advanced Options';
$txt['sp-blocksShowBlock'] = 'Show Block On';
$txt['sp-blocksOptionAllPages'] = 'All Pages';
$txt['sp-blocksOptionAllActions'] = 'All Actions';
$txt['sp-blocksOptionAllBoards'] = 'All Boards';
$txt['sp-blocksSelectActions'] = 'Select Actions';
$txt['sp-blocksSelectBoards'] = 'Select Boards';
$txt['sp_display_custom'] = 'Custom Display Options';
$txt['sp-blocksStyleOptions'] = 'Style Options';
$txt['sp-blocksTitleDefaultClass'] = 'Default Title Class';
$txt['sp-blocksTitleCustomClass'] = 'Custom Title Class';
$txt['sp-blocksTitleCustomStyle'] = 'Custom Title Style';
$txt['sp-blocksBodyDefaultClass'] = 'Default Body Class';
$txt['sp-blocksBodyCustomClass'] = 'Custom Body Class';
$txt['sp-blocksBodyCustomStyle'] = 'Custom Body Style';
$txt['sp-blocksNoTitle'] = 'No Title';
$txt['sp-blocksNoBody'] = 'No Body';

// Articles area
$txt['sp-adminArticleListName'] = 'Article List';
$txt['sp-adminArticleListDesc'] = 'This page displays a list of all topics that have been added as articles. These can be modified by selecting the appropriate options.';
$txt['sp-adminArticleAddName'] = 'Add Article';
$txt['sp-adminArticleAddDesc'] = 'This page enables articles to be added to the portal page.';

// Article list
$txt['sp-articlesRemove'] = 'Remove Selected';
$txt['sp-articlesConfirm'] = 'Are you sure you want to delete these articles?';
$txt['sp-articlesDeleteConfirm'] = 'Are you sure you want to delete this article?';

// Add/Edit articles
$txt['sp-articlesAdd'] = 'Add Article';
$txt['sp-articlesEdit'] = 'Edit Article';
$txt['sp-articlesCategory'] = 'Article Category';
$txt['sp-articlesApproved'] = 'Approved';

// Categories area
$txt['sp-adminCategoryListName'] = 'Category List';
$txt['sp-adminCategoryListDesc'] = 'This page displays a list of article categories that have been created. These can be modified by selecting the appropriate options.';
$txt['sp-adminCategoryAddName'] = 'Add Category';
$txt['sp-adminCategoryAddDesc'] = 'This page enables new categories to be added for articles to be placed in.';

// Category list
$txt['sp-categoriesCategories'] = 'Categories';

// Add/Edit category
$txt['sp-categoriesAdd'] = 'Add Category';
$txt['sp-categoriesEdit'] = 'Edit Category';
$txt['sp-categoriesName'] = 'Name';
$txt['sp-categoriesPicture'] = 'Image URL';
$txt['sp-categoriesPublish'] = 'Publish on Portal';

// Delete category
$txt['sp-categoriesDelete'] = 'Delete Category';
$txt['sp-categoriesDeleteCount'] = 'There are %s article(s) in this category.';
$txt['sp-categoriesDeleteOption1'] = 'Do you want to move these articles to another category?';
$txt['sp-categoriesDeleteOption2'] = 'By deleting this category your articles will also be deleted.';
$txt['sp-categoriesDeleteConfirm'] = 'Are you sure you wish to delete this category?';
$txt['sp-categoriesMove'] = 'Move';
$txt['sp-categoriesMoveTo'] = 'Move To';

// Block list titles
$txt['sp-adminColumnType'] = 'Type';
$txt['sp-adminColumnMove'] = 'Move';

// Article list titles
$txt['sp-adminColumnTopic'] = 'Topic';
$txt['sp-adminColumnBoard'] = 'Board';
$txt['sp-adminColumnPoster'] = 'Poster';
$txt['sp-adminColumnTime'] = 'Time';
$txt['sp-adminColumnCategory'] = 'Category';
$txt['sp-adminColumnApproved'] = 'Approved';

// Category list titles
$txt['sp-adminColumnPicture'] = 'Picture';
$txt['sp-adminColumnArticles'] = 'Articles';
$txt['sp-adminColumnPublish'] = 'Publish';

// General titles
$txt['sp-adminColumnAction'] = 'Action';
$txt['sp-adminColumnName'] = 'Name';

// Miscellaneous strings
$txt['sp-positionLeft'] = 'Left';
$txt['sp-positionTop'] = 'Top';
$txt['sp-positionBottom'] = 'Bottom';
$txt['sp-positionRight'] = 'Right';
$txt['sp-placementBefore'] = 'Before';
$txt['sp-placementAfter'] = 'After';
$txt['sp-placementUnchanged'] = 'Unchanged';
$txt['sp-stateYes'] = 'Yes';
$txt['sp-stateNo'] = 'No';

// Information area
$txt['sp-info_title'] = 'Information';
$txt['sp-info_desc'] = 'Some useful system, and SimplePortal information.';
$txt['sp-info_live'] = 'Live from SimplePortal...';
$txt['sp-info_no_live'] = 'Sorry! At this time you are unable to connect to simpleportal.net\'s latest news file.';
$txt['sp-info_general'] = 'General Information';
$txt['sp-info_versions'] = 'Version Information';
$txt['sp-info_your_version'] = 'Your Version';
$txt['sp-info_current_version'] = 'Current Version';
$txt['sp-info_managers'] = 'Managers';
$txt['sp-info_intro'] = 'The SimplePortal Team wants to thank everyone who helped make SimplePortal what it is today, and the Simple Machines Team for the great forum software, SMF. It wouldn\'t have been possible without you, our users, and SMF.';
$txt['sp-info_team'] = 'The Team';
$txt['sp-info_special'] = 'Special Thanks';
$txt['sp-info_and'] = 'and';
$txt['sp-info_anyone'] = 'For anyone we may have missed, thank you!';
$txt['sp-info_groups_pm'] = 'Project Managers';
$txt['sp-info_groups_dev'] = 'Developers';
$txt['sp-info_groups_support'] = 'Support Specialists';
$txt['sp-info_groups_customize'] = 'Customizers';
$txt['sp-info_groups_language'] = 'Language Managers';
$txt['sp-info_groups_marketing'] = 'Marketing';
$txt['sp-info_groups_beta'] = 'Beta Testers';
$txt['sp-info_groups_translators'] = 'Language Translators';
$txt['sp-info_translators_message'] = 'Thank you for your efforts in the internationalization of SimplePortal.';
$txt['sp-info_groups_founder'] = 'Founding Father of SimplePortal';
$txt['sp-info_groups_orignal_pm'] = 'Original Project Managers';
$txt['sp-info_fam_fam'] = 'Pretty Icons';
$txt['sp-info_fam_fam_message'] = 'Mark James for his <a href="http://www.famfamfam.com/lab/icons/silk/">Fam Fam Fam Silk Icons</a>.';

// Compatibility strings
$txt['sp-adminCatHelp'] = 'Here you can manage and configure SimplePortal.';
$txt['sp-adminCatDesc'] = 'Here you can manage and configure SimplePortal.';

?>