<?php
/**********************************************************************************
* Subs-SPortal2.php                                                               *
***********************************************************************************
* SimplePortal                                                                    *
* SMF Modification Project Founded by [SiNaN] (sinan@simplemachines.org)          *
* =============================================================================== *
* Software Version:           SimplePortal 2.2.2                                  *
* Software by:                SimplePortal Team (http://www.simpleportal.net)     *
* Copyright 2008-2009 by:     SimplePortal Team (http://www.simpleportal.net)     *
* Support, News, Updates at:  http://www.simpleportal.net                         *
***********************************************************************************
* This program is free software; you may redistribute it and/or modify it under   *
* the terms of the provided license as published by Simple Machines LLC.          *
*                                                                                 *
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
*                                                                                 *
* See the "license.txt" file for details of the Simple Machines license.          *
* The latest version can always be found at http://www.simplemachines.org.        *
**********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

/*
	array getBlockInfo()
		// !!!

	bool getShowInfo()
		// !!!

	array getFunctionInfo()
		// !!!

	array getCategoryInfo()
		// !!!

	array getArticleInfo()
		// !!!

	void createArticle()
		// !!!

	void fixCategoryArticles()
		// !!!

	void fixColumnRows()
		// !!!

	void changeBlockRow()
		// !!!

	void changeState()
		// !!!

	bool sp_loadPermissions()
		// !!!

	bool spAllowedTo()
		// !!!

	void sp_loadMembergroups()
		// !!!

	string sp_languageSelect()
		// !!!

	bool sp_validate_php()
		// !!!

	array loadDatabaseTables()
		// !!!

	bool databaseTableExists()
		// !!!

	array sp_loadCalendarData()
		// !!!

	mixed sp_loadColors()
		// !!!

	string sp_embed_image()
		// !!!

	string sp_truncateText()
		// !!!

	mixed sp_strrpos_needle()
		// !!!
*/

// This function, returns all of the information about particular blocks.
function getBlockInfo($column_id = null, $block_id = null, $state = null, $show = null)
{
	global $smcFunc, $context, $settings, $options, $txt;

	$query = array();
	$parameters = array();
	if (!empty($column_id))
	{
		$query[] = 'spb.col = {int:col}';
		$parameters['col'] = !empty($column_id) ? $column_id : 0;
	}
	if (!empty($block_id))
	{
		$query[] = 'spb.id_block = {int:id_block}';
		$parameters['id_block'] = !empty($block_id) ? $block_id : 0;
	}
	if (!empty($state))
	{
		$query[] = 'spb.state = {int:state}';
		$parameters['state'] = 1;
	}

	$request = $smcFunc['db_query']('','
		SELECT
			spb.id_block, spb.label, spb.type, spb.col, spb.row, spb.state,
			spb.force_view, spb.allowed_groups, spb.permission_type, spb.display,
			spb.display_custom, spb.style, spp.variable, spp.value
		FROM {db_prefix}sp_blocks AS spb
			LEFT JOIN {db_prefix}sp_parameters AS spp ON (spp.id_block = spb.id_block)' . (!empty($query) ? '
		WHERE ' . implode(' AND ', $query) : '') . '
		ORDER BY spb.row',
		$parameters
	);

	$return = array();
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		if (!empty($show) && !getShowInfo($row['id_block'], $row['display'], $row['display_custom']))
			continue;

		if (!spAllowedTo('block', $row['id_block']))
			continue;

		if (!isset($return[$row['id_block']]))
		{
			$return[$row['id_block']] = array(
				'id' => $row['id_block'],
				'label' => $row['label'],
				'type' => $row['type'],
				'type_text' => !empty($txt['sp_function_' . $row['type'] . '_label']) ? $txt['sp_function_' . $row['type'] . '_label'] : $txt['sp_function_unknown_label'],
				'column' => $row['col'],
				'row' => $row['row'],
				'state' => empty($row['state']) ? 0 : 1,
				'force_view' => $row['force_view'],
				'allowed_groups' => $row['allowed_groups'],
				'permission_type' => $row['permission_type'],
				'display' => $row['display'],
				'display_custom' => $row['display_custom'],
				'style' => $row['style'],
				'collapsed' => $context['user']['is_guest'] ? !empty($_COOKIE['sp_block_' . $row['id_block']]) : !empty($options['sp_block_' . $row['id_block']]),
				'parameters' => array(),
			);
		}

		if (!empty($row['variable']))
			$return[$row['id_block']]['parameters'][$row['variable']] = $row['value'];
	}
	$smcFunc['db_free_result']($request);

	return $return;
}

// Function to get a block's display/show information.
function getShowInfo($block_id = null, $display = null, $custom = null)
{
	global $smcFunc, $context, $modSettings;

	// Do we have the display info?
	if ($display === null || $custom === null)
	{
		// Make sure that its an integer.
		$block_id = (int) $block_id;

		// We need an ID.
		if (empty($block_id))
			return false;

		// Get the info.
		$result = $smcFunc['db_query']('','
			SELECT display, display_custom
			FROM {db_prefix}sp_blocks
			WHERE id_block = {int:id_block}
			LIMIT 1',
			array(
				'id_block' => $block_id,
			)
		);
		list ($display, $custom) = $smcFunc['db_fetch_row']($result);
		$smcFunc['db_free_result']($result);
	}

	// Some variables for ease.
	$action = !empty($context['current_action']) ? $context['current_action'] : '';
	$board = !empty($context['current_board']) ? $context['current_board'] : '';
	$portal = (empty($action) && empty($board) && SMF != 'SSI' && $modSettings['sp_portal_mode'] == 1) || !empty($context['standalone']) ? true : false;

	// Will hopefully get larger in the future.
	$portal_actions = array(
		'sa' => array('news', 'articles'),
		'start' => true,
		'theme' => true,
		'PHPSESSID' => true,
		'wwwRedirect' => true,
		'www' => true,
		'variant' => true,
		'language' => true,
	);

	// Set some action exceptions.
	$exceptions = array(
		'post' => array('announce', 'editpoll', 'emailuser', 'post2', 'sendtopic'),
		'register' => array('activate', 'coppa'),
		'forum' => array('collapse'),
		'admin' => array('credits', 'theme', 'viewquery', 'viewsmfile'),
		'moderate' => array('groups'),
		'login' => array('reminder'),
		'profile' => array('trackip', 'viewprofile'),
	);

	// Still, we might not be in portal!
	if (!empty($_GET) && empty($context['standalone']))
		foreach ($_GET as $key => $value)
			if (!isset($portal_actions[$key]))
				$portal = false;
			elseif (is_array($portal_actions[$key]) && !in_array($value, $portal_actions[$key]))
				$portal = false;

	// Set the action to more known one.
	foreach ($exceptions as $key => $exception)
		if (in_array($action, $exception))
			$action = $key;

	// Take care of custom actions.
	$special = array();
	$exclude = array();
	if (!empty($custom))
	{
		$custom = explode(', ', $custom);

		// This is special...
		foreach ($custom as $key => $value)
		{
			$name = '';
			$item = '';

			// Is this a weird action?
			if ($value[0] == '~')
			{
				@list($name, $item) = explode('|', substr($value, 1));

				if (empty($item))
					$special[$name] = true;
				else
					$special[$name][] = $item;
			}

			// Might be excluding something!
			elseif ($value[0] == '-')
			{
				// We still may have weird things...
				if ($value[1] == '~')
				{
					@list($name, $item) = explode('|', substr($value, 2));

					if (empty($item))
						$exclude['special'][$name] = true;
					else
						$exclude['special'][$name][] = $item;
				}
				else
					$exclude['regular'][] = substr($value, 1);
			}
		}

		// Add what we have to main variable.
		if (!empty($display))
			$display = $display . ', ' . implode(', ', $custom);
		else
			$display = $custom;
	}

	// We don't want to show it in this action?
	if (!empty($exclude['regular']) && !empty($action) && in_array($action, $exclude['regular']))
		return false;

	// Maybe we don't want to show it in somewhere special.
	if (!empty($exclude['special']))
		foreach ($exclude['special'] as $key => $value)
			if (isset($_GET[$key]))
				if (is_array($value) && !in_array($_GET[$key], $value))
					continue;
				else
					return false;

	// If no display info and/or integration disabled and we are on portal; show it!
	if ((empty($display) || empty($modSettings['sp_enableIntegration'])) && $portal)
		return true;
	// No display info and/or integration disabled and no portal; no need...	
	elseif (empty($display) || empty($modSettings['sp_enableIntegration']))
		return false;
	// Get ready for real action if you haven't yet.
	elseif (!is_array($display))
		$display = explode(', ', $display);

	// Did we disable all blocks for this action?
	if (!empty($modSettings['sp_' . $action . 'IntegrationHide']))
		return false;
	// If we will display show the block.
	elseif (in_array('all', $display))
		return true;
	// If we are on portal, show portal blocks; if we are on forum, show forum blocks.
	elseif (($portal && (in_array('portal', $display) || in_array('sportal', $display))) || (!$portal && in_array('sforum', $display)))
		return true;
	elseif (!empty($board) && (in_array('allboard', $display) || in_array($board, $display)))
		return true;
	elseif (!empty($action) && (in_array('allaction', $display) || in_array($action, $display)))
		return true;
	elseif (empty($action) && empty($board) && $modSettings['sp_portal_mode'] == 2 && in_array('forum', $display))
		return true;

	// For mods using weird urls...
	foreach ($special as $key => $value)
		if (isset($_GET[$key]))
			if (is_array($value) && !in_array($_GET[$key], $value))
				continue;
			else
				return true;

	// Ummm, no block!
	return false;
}

// This function, gets all of the necessary information about a particular sp block function.
function getFunctionInfo($function = null)
{
	global $smcFunc;

	$request = $smcFunc['db_query']('','
		SELECT id_function, name, parameter
		FROM {db_prefix}sp_functions' . (!empty($function) ? '
		WHERE name = {string:function}' : '') . '
		ORDER BY function_order',
		array(
			'function' => $function,
		)
	);
	$return = array();
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		// There is one function who is not allowed to use by non admins
		if ($row['name'] == 'sp_php' && !allowedTo('admin_forum'))
			continue;

		$return[] = array(
			'id' => $row['id_function'],
			'function' => $row['name'],
			'parameter' => $row['parameter'],
		);
	}
	$smcFunc['db_free_result']($request);

	return $return;
}

// This function, gets all of the relevant information about sp categories.
function getCategoryInfo($category_id = null)
{
	global $scripturl, $context, $smcFunc, $settings, $txt;

	$request = $smcFunc['db_query']('','
		SELECT id_category, name, picture, articles, publish
		FROM {db_prefix}sp_categories' . (!empty($category_id) ? '
		WHERE id_category = {int:category_id}' : '') . '
		ORDER BY id_category',
		array(
			'category_id' => $category_id,
		)
	);
	$return = array();
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		$return[] = array(
			'id' => $row['id_category'],
			'name' => $row['name'],
			'picture' => array (
				'href' => $row['picture'],
				'image' => '<img src="' . $row['picture'] . '" alt="' . $row['name'] . '" width="75" />',
			),
			'articles' => $row['articles'],
			'publish' => $row['publish'],
		);
	}
	$smcFunc['db_free_result']($request);

	return $return;
}

// This function returns article information.
function getArticleInfo($article_id = null, $category_id = null, $message_id = null, $approved = null)
{
	global $smcFunc;

	$query = array();
	if (!empty($article_id))
		$query[] = "id_article = {int:article_id}";
	if (!empty($category_id))
		$query[] = "id_category = {int:category_id}";
	if (!empty($message_id))
		$query[] = "id_message = {int:message_id}";
	if (!empty($approved))
		$query[] = "approved = '{int:approved}'";

	$request = $smcFunc['db_query']('','
		SELECT a.id_article, a.id_category, a.id_message, a.approved, c.name
		FROM {db_prefix}sp_articles as a
			LEFT JOIN {db_prefix}sp_categories AS c ON (c.id_category = a.id_category)' . (!empty($query) ? '
		WHERE ' . implode(' AND ', $query) : '') .'
		ORDER BY id_article',
		array(
			'article_id' => $article_id,
			'category_id' => $category_id,
			'message_id' => $message_id,
			'approved' => 1,
		)
	);
	$return = array();
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		$return[] = array(
			'article' => array(
				'id' => $row['id_article'],
				'approved' => $row['approved'],
			),
			'category' => array(
				'id' => $row['id_category'],
				'name' => $row['name'],
			),
			'message' => array(
				'id' => $row['id_message'],
			),
		);
	}
	$smcFunc['db_free_result']($request);

	return $return;
}

// Function to create a new article.
function createArticle($articleOptions)
{
	global $smcFunc;

	$articleOptions['id_category'] = !empty($articleOptions['id_category']) ? (int) $articleOptions['id_category'] : 0;
	$articleOptions['id_message'] = !empty($articleOptions['id_message']) ? (int) $articleOptions['id_message'] : 0;
	$articleOptions['approved'] = !empty($articleOptions['approved']) ? (int) $articleOptions['approved'] : 0;

	$request = $smcFunc['db_query']('','
		SELECT id_message
		FROM {db_prefix}sp_articles
		WHERE id_message = {int:id_message}',
		array(
			'id_message' => $articleOptions['id_message'],
		)
	);
	list ($exists) = $smcFunc['db_fetch_row']($request);
	$smcFunc['db_free_result']($request);

	if (empty($articleOptions['id_category']) || empty($articleOptions['id_message']) || $exists)
		return false;

	$smcFunc['db_insert']('normal', '{db_prefix}sp_articles',
		array('id_category' => 'int', 'id_message' => 'int', 'approved' => 'int'),
		array($articleOptions['id_category'], $articleOptions['id_message'], $articleOptions['approved']),
		array('id_article')
	);

	$smcFunc['db_query']('','
		UPDATE {db_prefix}sp_categories
		SET articles = articles + 1
		WHERE id_category = {int:id_category}',
		array(
			'id_category' => $articleOptions['id_category'],
		)
	);
}

// Function to fix the article counts for each category.
function fixCategoryArticles()
{
	global $smcFunc;

	// Get a list of categories
	$categoryList = getCategoryInfo();
	$categoryIds = array();	

	// Create a list of category ids.
	foreach ($categoryList as $category)
		$categoryIds[] = $category['id'];

	// Go through each category.
	foreach ($categoryIds as $category) 
	{
		// Firstly, get the current actual article count of the category.
		$article_count = 0;

		$request = $smcFunc['db_query']('','
			SELECT COUNT(*)
			FROM {db_prefix}sp_articles
			WHERE id_category = {int:id_category}',
			array(
				'id_category' => $category,
			)
		);
		list ($article_count) = $smcFunc['db_fetch_row']($request);
		$smcFunc['db_free_result']($request);

		// Now, update the category so that it has the correct article count.
		$smcFunc['db_query']('','
			UPDATE {db_prefix}sp_categories
			SET articles = {int:article_count}
			WHERE id_category = {int:id_category}',
			array(
				'article_count' => $article_count,
				'id_category' => $category,
			)
		);
	}
}

// Function to fix the columns for every block in a specific column.
function fixColumnRows($column_id = null)
{
	global $smcFunc;

	$blockList = getBlockInfo($column_id);
	$blockIds = array();	

	foreach($blockList as $block)
		$blockIds[] = $block['id'];

	$counter = 0;

	foreach ($blockIds as $block) 
	{
		$counter = $counter + 1;
	
		$smcFunc['db_query']('','
			UPDATE {db_prefix}sp_blocks
			SET row = {int:counter}
			WHERE id_block = {int:block}',
			array(
				'counter' => $counter,
				'block' => $block,
			)
		);
	}
}

// Function to change the row that a block is in.
function changeBlockRow($block_id = null, $direction = null)
{
	global $smcFunc;

	$blockInfo = current(getBlockInfo(null, $block_id));

	$smcFunc['db_query']('','
		UPDATE {db_prefix}sp_blocks
		SET row = {int:row}
		WHERE row = {int:row} ' . ($direction == 'up' ? '-' : '+') . ' 1
			AND col = {int:col}', 
		array(
			'row' => $blockInfo['row'],
			'col' => $blockInfo['column'],
		)
	);

	$smcFunc['db_query']('','
		UPDATE {db_prefix}sp_blocks
		SET row = row ' . ($direction == 'up' ? '-' : '+') . ' 1
		WHERE id_block = {int:block_id}
			AND col = {int:col}',
		array(
			'block_id' => $block_id,
			'col' => $blockInfo['column'],
		)
	);
}

// Function to change the 'state' that an article, block or category has.
function changeState($type = null, $id = null)
{
	global $smcFunc;

	if ($type == 'block')
		$query = array(
			'column' => 'state',
			'table' => 'blocks',
			'query_id' => 'id_block',
			'id' => $id
		);
	elseif ($type == 'category')
		$query = array(
			'column' => 'publish',
			'table' => 'categories',
			'query_id' => 'id_category',
			'id' => $id
		);
	elseif ($type == 'article')
		$query = array(
			'column' => 'approved',
			'table' => 'articles',
			'query_id' => 'id_article',
			'id' => $id
		);
	else
		return false;
	
	$request = $smcFunc['db_query']('','
		SELECT {raw:column}
		FROM {db_prefix}sp_{raw:table}
		WHERE {raw:query_id} = {int:id}',
		$query
	);

	list ($state) = $smcFunc['db_fetch_row']($request);
	$smcFunc['db_free_result']($request);
	
	$state = (int) $state;
	$state = $state == 1 ? 0 : 1 ;
	
	$smcFunc['db_query']('','
		UPDATE {db_prefix}sp_{raw:table}
		SET {raw:column} = {int:state}
		WHERE {raw:query_id} = {int:id}',
		array(
			'table' => $query['table'],
			'column' => $query['column'],
			'state' => $state,
			'query_id' => $query['query_id'],
			'id' => $id,
		)
	);
}

// Make the allowed check faster, because i can cache this data!
// force_view is used for the way to make 3 diffrent ways to check blocks!
function sp_loadPermissions($type = null)
{
	global $sp_context, $smcFunc, $user_info;

	// Checkup
	if (empty($type) || !in_array($type, array('block', 'article'))) 
		return false;

	// Prevent double load :)	
	if (!isset($sp_context['Permissions'][$type]))
		$sp_context['Permissions'][$type] = array();
	else
		return !empty($sp_context['Permissions'][$type]); //On false allowed to nothing ;P
	
	// Blockquery Informations :)
	$where = '';
	if ($type == 'block')
	{
		$query = array(
			'column' => 'allowed_groups',
			'table' => 'blocks',
			'field' => 'id_block',
			'permission_type' => ', permission_type',
		);
		$where = 'WHERE (permission_type = 2 
			OR (FIND_IN_SET(' . implode(', {raw:column}) OR FIND_IN_SET(', $user_info['groups']) . ', {raw:column})))';
	}
	else
	{
		$query = array(
			'column' => 'allowed_groups',
			'table' => 'articles',
			'field' => 'is_article',
			'permission_type' => '',
		);
		$where = 'WHERE (FIND_IN_SET(' . implode(', {raw:column}) OR FIND_IN_SET(', $user_info['groups']) . ', {raw:column}))';
	}

	// Get the necessary block information.
	$request = $smcFunc['db_query']('','
		SELECT {raw:column} AS allowed_groups, {raw:field} AS id {raw:permission_type}
		FROM {db_prefix}sp_{raw:table}
		' . $where,
		$query
	);
	// The output will only show the allowed positions ;D
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		// This Permission need a extra checkup 8), it's a faster query now, a lot faster!
		if (!empty($row['permission_type']) && $row['permission_type'] == 1)
		{
			if (count(array_intersect($user_info['groups'], explode(',', $row['allowed_groups']))) != count($user_info['groups']))
				continue;
		}
		$sp_context['Permissions'][$type][$row['id']] = $row['id'];
	}
	$smcFunc['db_free_result']($request);
	
	// Okay chached it ;) now it should be faster... a lot faster 8)
	return !empty($sp_context['Permissions'][$type]);
}

// Function to check if users are allowed to view certain blocks.
function spAllowedTo($type = null, $id = null)
{
	global $sp_context;

	// SP moderators are supermen. :D i need to do nothing if this correct! It's to late checked!
	// And this is the reason why admin unselect never work!
	// If we like to fix this we need to think about a way to allowed it in a other way or insert a force admin check
	if (allowedTo('sp_moderate'))
		return true;

	// Sanitize the ID.
	$id = (int) $id;

	// Make sure that we have a proper id, load Permissions and store a chache 
	if (empty($id) || sp_loadPermissions($type) === false || empty($type))
		return false;

	// Pah if it isset than you allowed, if not than not :)
	return isset($sp_context['Permissions'][$type][$id]);
}

/*
	void sp_loadMemberGroups(Array $selectedGroups = array, Array $removeGroups = array(), string $show = 'normal', string $contextName = 'member_groups')
	This will file the $context['member_groups'] to the given options
	$selectedGroups means all groups who should be shown as selcted, if you like to check all than insert an 'all'
		You can also Give the function a string with '2,3,4'
	$removeGroups this group id should not shown in the list
	$show have follow options
		'normal' => will show all groups, and add a guest and regular member (Standard)
		'post' => will load only post groups
		'master' => will load only not postbased groups
	$contextName where the datas should stored in the $context;

	The Administrator group id 1 will evertime ignored!
*/
function sp_loadMemberGroups($selectedGroups = array(), $show = 'normal', $contextName = 'member_groups', $subContext = 'SPortal') 
{
	global $context, $smcFunc, $txt;

	// Some additional Language stings are needed
	loadLanguage('ManageBoards');

	// Make sure its empty
	if (!empty($subContext))
		$context[$subContext][$contextName] = array();
	else
		$context[$contextName] = array();

	// Preseting some things :)
	if (!is_array($selectedGroups))
		$checked = strtolower($selectedGroups) == 'all';
	else
		$checked = false;

	if (!$checked && !empty($selectedGroups))
	{
		if (!is_array($selectedGroups)) 
			$selectedGroups = explode(',', $selectedGroups);

		// Remove all strings, i will only allowe ids :P
		foreach ($selectedGroups as $k => $i)
			$selectedGroups[$k] = (int) $i;

		$selectedGroups = array_unique($selectedGroups);
	}
	else
		$selectedGroups = array();

	// Okay let's checkup the show function
	$show_option = array(
		'normal' => 'id_group != 1',
		'post' => 'min_posts != -1',
		'master' => 'min_posts = -1 AND id_group != 1',
	);

	$show = strtolower($show);

	if (!isset($show_option[$show]))
		$show = 'normal';

	// Guest and Members are added manually. Only on normal ond master View =)
	if ($show == 'normal' || $show == 'master')
	{
		$context[$contextName][-1] = array(
			'id' => -1,
			'name' => $txt['membergroups_guests'],
			'checked' => $checked || in_array(-1, $selectedGroups),
			'is_post_group' => false,
		);
		$context[$contextName][0] = array(
			'id' => 0,
			'name' => $txt['membergroups_members'],
			'checked' => $checked || in_array(0, $selectedGroups),
			'is_post_group' => false,
		);
	}
	
	// Load membergroups.
	$request = $smcFunc['db_query']('', '
		SELECT group_name, id_group, min_posts
		FROM {db_prefix}membergroups
		WHERE {raw:show}
		ORDER BY min_posts, id_group != {int:global_moderator}, group_name',
		array(
			'show' => $show_option[$show],
			'global_moderator' => 2,
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		$context[$contextName][(int) $row['id_group']] = array(
			'id' => $row['id_group'],
			'name' => trim($row['group_name']),
			'checked' => $checked || in_array($row['id_group'], $selectedGroups),
			'is_post_group' => $row['min_posts'] != -1,
		);
	}
	$smcFunc['db_free_result']($request);
}

function sp_query_string($tourniquet)
{
	global $sportal_version, $context;

	$fix = str_replace('{version}', $sportal_version, '<a href="http://www.simpleportal.net/" target="_blank" class="new_win">SimplePortal {version} &copy; 2008-2009</a>');

	if ((SMF == 'SSI' && empty($context['standalone'])) || empty($context['template_layers']) || WIRELESS || strpos($tourniquet, $fix) !== false)
		return $tourniquet;

	$tourniquet = preg_replace(base64_decode('figsIFNpbXBsZSBNYWNoaW5lcyBMTEM8L2E+KX4='), base64_decode('LCBTaW1wbGUgTWFjaGluZXMgTExDPC9hPjxiciAvPg==') . $fix, $tourniquet);
	$tourniquet = preg_replace('~class="copywrite"~', 'class="copywrite" style="line-height: 1;"', $tourniquet);

	if (strpos($tourniquet, $fix) === false)
	{
		$fix = '<div style="text-align: center; width: 100%; font-size: x-small; margin-bottom: 5px;">' . $fix . '</div></body></html>';
		$tourniquet = preg_replace('~</body>\s*</html>~', $fix, $tourniquet);
	}

	return $tourniquet;
}

/*
This is a simple function that return nothing if the language file exist and english if it not exists
This will help to make it possible to load each time the english language!
*/
function sp_languageSelect($template_name) 
{
	global $user_info, $language, $settings, $context;
	global $sourcedir;
	static $already_loaded = array();

	if(isset($already_loaded[$template_name]))
		return $already_loaded[$template_name];

	$lang = isset($user_info['language']) ? $user_info['language'] : $language;

	// Make sure we have $settings - if not we're in trouble and need to find it!
	if (empty($settings['default_theme_dir']))
	{
		require_once($sourcedir . '/ScheduledTasks.php');
		loadEssentialThemeData();
	}
	
	// For each file open it up and write it out!
	$allTemplatesExists = array();
	foreach (explode('+', $template_name) as $template)
	{
		// Obviously, the current theme is most important to check.
		$attempts = array(
			array($settings['theme_dir'], $template, $lang, $settings['theme_url']),
			array($settings['theme_dir'], $template, $language, $settings['theme_url']),
		);

		// Do we have a base theme to worry about?
		if (isset($settings['base_theme_dir']))
		{
			$attempts[] = array($settings['base_theme_dir'], $template, $lang, $settings['base_theme_url']);
			$attempts[] = array($settings['base_theme_dir'], $template, $language, $settings['base_theme_url']);
		}

		// Fallback on the default theme if necessary.
		$attempts[] = array($settings['default_theme_dir'], $template, $lang, $settings['default_theme_url']);
		$attempts[] = array($settings['default_theme_dir'], $template, $language, $settings['default_theme_url']);

		// Try to find the language file.
		$allTemplatesExists[$template] = false;
		$already_loaded[$template] = 'english';
		foreach ($attempts as $k => $file) {
			if (file_exists($file[0] . '/languages/' . $file[1] . '.' . $file[2] . '.php'))
			{
				$already_loaded[$template] = '';
				$allTemplatesExists[$template] = true;
				break;
			}
		}
	}
	//So all need to be true that it work ;)
	foreach($allTemplatesExists as $exist)
		if(!$exist)
		{
			$already_loaded[$template_name] = 'english';
			return 'english';
		}

	//Everthing is fine, let's go back :D
	$already_loaded[$template_name] = '';
	return '';
}

// Makes sure that PHP is valid.
function sp_validate_php($code)
{
	global $boardurl, $boarddir, $sourcedir;

	$id = time();
	$error = false;
	$filename = 'sp_tmp_' . $id . '.php';
	$temp_dir = $boarddir . '/Packages/temp';
	$temp_url = $boardurl . '/Packages/temp';

	$code = trim($code);
	$code = trim($code, '<?php');
	$code = trim($code, '?>');

	require_once($sourcedir . '/Subs-Package.php');

	if (file_exists($temp_dir))
		deltree($temp_dir, false);

	if (!mktree($temp_dir, 0755))
	{
		deltree($temp_dir, false);

		if (!mktree($temp_dir, 0777))
			return false;
	}

	$content = '<?php

require_once(\'' . $boarddir . '/SSI.php\');

' . $code . '

?>';

	$fp = fopen($temp_dir . '/' . $filename, 'w');
	fwrite($fp, $content);
	fclose($fp);

	if (!file_exists($temp_dir . '/' . $filename))
		return false;

	$result = fetch_web_data($temp_url . '/' . $filename);

	if ($result === false)
		$error = 'database';
	elseif (preg_match('~ <b>(\d+)</b><br( /)?' . '>$~i', $result) != 0)
		$error = 'syntax';

	unlink($temp_dir . '/' . $filename);

	return $error;
}

/*
	bool loadDatabaseTables ()
	- Preload database Tables this will be only done once per script call
	- Return false on error
	- Mysql 3.x+ Compatible ;) for SMF 2.0.x
*/
function loadDatabaseTables() 
{
	global $database_tables, $db_name, $smcFunc;
	
	if (isset($database_tables))
		return !empty($database_tables);
	else
		$database_tables = array();

	// Prepare a Checkup ;D
	$request = $smcFunc['db_query']('', '
		SHOW TABLES
		FROM `{raw:db_name}`',
		array(
			'db_name' => $db_name,
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($request))
		$database_tables[] = strtolower(current($row));
	$smcFunc['db_free_result']($request);

	return !empty($database_tables);
}

/*
	bool databaseTableExists (string tablename, bool $addprefix = true)
	- Return true if the tablename exits
	- $addprefix will automatic add the $db_prefix (Check also it this is allready done!)
*/
function databaseTableExists($tablename = '', $addprefix = true) 
{
	global $database_tables, $db_prefix;
	
	// Nothing to Serach for ;)
	if (empty($tablename))
		return false;

	// Error ?_?
	if (empty($database_tables) && !loadDatabaseTables())
		return false;
	
	//First thing i do.. i know normal i should not so this ;P But it's good enouph for smf ;)
	$tablename = strtolower($tablename);
	
	// Table Prefix auto add? :D
	if($addprefix === true && strpos($tablename, $db_prefix) !== 0)
	{
		// Looks not so nice ;) but it work trust me ;P
		if (strpos($tablename, '{db_prefix}') !== false)
			$tablename = str_replace('{db_prefix}', $db_prefix, $tablename);
		elseif (strpos($tablename, '$db_prefix') !== false)
			$tablename = str_replace('$db_prefix', $db_prefix, $tablename);
		else
			$tablename = $db_prefix . $tablename;
	}

	return in_array($tablename, $database_tables);
}

// This function return the correct array that is called.
function sp_loadCalendarData($type, $low_date, $high_date = false)
{
	global $sourcedir;
	static $loaded;

	if(!isset($loaded))
	{
		require_once($sourcedir . '/Subs-Calendar.php');

		$loaded = array(
			'getEvents' => 'getEventRange',
			'getBirthdays' => 'getBirthdayRange',
			'getHolidays' => 'getHolidayRange',
		);
	}

	if (!empty($loaded[$type]))
		return $loaded[$type]($low_date, ($high_date === false ? $low_date : $high_date));
	else
		return array();
}

function sp_startElement($parser, $name, $attrs)
{
	global $rss_data, $rss_current, $rss_main;

	switch($name)
	{
		case 'RSS':
		case 'RDF:RDF':
		case 'ITEMS':
			$rss_current = '';
			break;
		case 'CHANNEL':
			$rss_main = 'CHANNEL';
			break;
		case 'IMAGE':
			$rss_main = 'IMAGE';
			$rss_data['IMAGE'] = array();
			break;
		case 'ITEM':
			$rss_main = 'ITEMS';
			break;
		default:
			$rss_current = $name;
			break;
	}
}

function sp_endElement($parser, $name)
{
	global $rss_data, $rss_current, $rss_counter;

	$rss_current = '';

	if ($name == 'ITEM')
		$rss_counter++;
}

function sp_characterData($parser, $data)
{
	global $rss_data, $rss_current, $rss_main, $rss_counter;

	if (!empty($rss_current))
	{
		switch($rss_main)
		{
			case 'CHANNEL':
				if (isset($rss_data[$rss_current]))
					$rss_data[$rss_current] .= $data;
				else
					$rss_data[$rss_current] = $data;
				break;
			case 'IMAGE':
				if (isset($rss_data[$rss_main][$rss_current]))
					$rss_data[$rss_main][$rss_current] .= $data;
				else
					$rss_data[$rss_main][$rss_current] = $data;
				break;
			case 'ITEMS':
				if (isset($rss_data[$rss_main][$rss_counter][$rss_current]))
					$rss_data[$rss_main][$rss_counter][$rss_current] .= $data;
				else
					$rss_data[$rss_main][$rss_counter][$rss_current] = $data;
				break;
		}
	}
}

// This is a small script to load colors for SPortal.
function sp_loadColors($users = array()) 
{
	global $color_profile, $smcFunc, $scripturl, $modSettings;

	// This is for later, if you like to disable colors ;)
	if (!empty($modSettings['sp_disableColor']))
		return false;

	// Can't just look for no users. :P
	if (empty($users))
		return false;

	// MemberColorLink compatible, chache more data, handle also some special member color link colors
	if (!empty($modSettings['MemberColorLinkInstalled']))
	{
		$colorDatas = load_onlineColors($users);
		$loaded_ids = array_keys($colorDatas);

		foreach($loaded_ids as $id)
		{
			if (!empty($id) && !isset($color_profile[$id]['link']))
			{
				$color_profile[$id]['link'] = $colorDatas[$id]['colored_link'];
				$color_profile[$id]['colored_name'] = $colorDatas[$id]['colored_name'];
			}
		}
		return empty($loaded_ids) ? false : $loaded_ids;
	}

	// Make sure it's an array.
	$users = !is_array($users) ? array($users) : array_unique($users);
	
	//Check up the array :)
	foreach($users as $k => $u)
	{
		$u = (int) $u;

		if (empty($u))
			unset($users[$k]);
		else
			$users[$k] = $u;
	}

	$loaded_ids = array();
	// Is this a totally new variable?
	if (empty($color_profile))
		$color_profile = array();
	// Otherwise, we will need to do some reformating of the old data.
	else 
	{
		foreach ($users as $k => $u)
			if (isset($color_profile[$u]))
			{
				$loaded_ids[] = $u;
				unset($users[$k]);
			}
	}

	// Make sure that we have some users.
	if (empty($users))
		return empty($loaded_ids) ? false : $loaded_ids;
	
	// Correct array pointer for the user
	reset($users);
	// Load the data.
	$request = $smcFunc['db_query']('','
		SELECT
			mem.id_member, mem.member_name, mem.real_name, mem.id_group,
			mg.online_color AS member_group_color, pg.online_color AS post_group_color
		FROM {db_prefix}members AS mem 
			LEFT JOIN {db_prefix}membergroups AS pg ON (pg.id_group = mem.id_post_group)
			LEFT JOIN {db_prefix}membergroups AS mg ON (mg.id_group = mem.id_group)
		WHERE mem.id_member '.((count($users) == 1) ? '= {int:current}' : 'IN ({array_int:users})'),
		array(
			'users'	=> $users,
			'current' => (int) current($users),
		)
	);
	
	// Go through each of the users.
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		$loaded_ids[] = $row['id_member'];
		$color_profile[$row['id_member']] = $row;
		$onlineColor = !empty($row['member_group_color']) ? $row['member_group_color'] : $row['post_group_color'];
		$color_profile[$row['id_member']]['link'] = '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '"' . (!empty($onlineColor) ? ' style="color: ' . $onlineColor . ';"' : '') . '>' . $row['real_name'] . '</a>';
		$color_profile[$row['id_member']]['colored_name'] = (!empty($onlineColor) ? '<span style="color: ' . $onlineColor . ';">' : '' ) . $row['real_name'] . (!empty($onlineColor) ? '</span>' : '');
	}
	$smcFunc['db_free_result']($request);
	
	// Return the necessary data.
	return empty($loaded_ids) ? false : $loaded_ids;
}

function sp_embed_image($name, $alt = '', $width = null, $height = null, $title = true, $id = null)
{
	global $modSettings, $settings, $txt;
	static $default_alt, $randomizer;

	if (!isset($default_alt))
	{
		$default_alt = array(
			'dot' => $txt['sp-dot'],
			'arrow' => $txt['sp-arrow'],
			'modify' => $txt['modify'],
			'delete' => $txt['delete'],
		);
	}

	if (!isset($randomizer) || $randomizer > 7)
		$randomizer = 0;
	$randomizer++;

	if (empty($alt) && isset($default_alt[$name]))
		$alt = $default_alt[$name];

	if ($title === true)
		$title = !empty($alt) ? $alt : '';

	if (empty($alt))
		$alt = $name;

	if ($name == 'dot' && empty($modSettings['sp_disable_random_bullets']))
		$name = 'dot' . $randomizer;
	elseif ($name == 'dot')
		$name = 'dot1';

	$image = '<img src="' . $settings['sp_images_url'] . '/' . $name . '.png" alt="' . $alt . '"' . (!empty($title) ? ' title="' . $title . '"' : '') . (!empty($width) ? ' width="' . $width . '"' : '') . (!empty($height) ? ' height="' . $height . '"' : '') . (!empty($id) ? ' id="' . $id . '"' : '') . ' class="png_fix" />';

	return $image;
}

function sp_truncateText($string = '', $length = false)
{
	global $modSettings, $smcFunc;
	static $removeOpenTags, $toFixTags;
	
	if (empty($removeOpenTags))
	{
		$bbc_data = parse_bbc(false);
		$toFixTags = array();
		
		// Okay built an array for the auto close
		foreach($bbc_data as $bbc)
		{
			if (empty($bbc['type']))
				$toFixTags[$bbc['tag']] = array(
					'parsed_content' => true,
					'no_close_tag' => false,
				);
			elseif ($bbc['type'] == 'closed')
				$toFixTags[$bbc['tag']] = array(
					'parsed_content' => true,
					'no_close_tag' => true,
				);
			elseif (in_array($bbc['type'], array('unparsed_equals_content', 'unparsed_content', 'unparsed_commas_content')))
				$toFixTags[$bbc['tag']] = array(
					'parsed_content' => false,
					'no_close_tag' => false,
				);
			else
				$toFixTags[$bbc['tag']] = array(
					'parsed_content' => true,
					'no_close_tag' => false,
				);
		}
	
		// This tags need to be removed if they are open but not closed, easy to extent... if there more <<.
		$removeOpenTags = array(
			'url',
			'iurl',
			'email',
			'img',
			'ftp',
		);
	}
	
	// Okay no length set than use the Simple Portal Standard, 0 = Disabled
	if ($length === false)
		$length = empty($modSettings['articlelength']) ? 0 : $modSettings['articlelength'];
	
	// Yes i know... but negative length... i think we don't like it :P
	$length = abs($length);
	
	// Do only the work if they really needed
	if (empty($string) || empty($length) || $smcFunc['strlen']($string) < $length)
		return $string;

	// Prepare the String for Special cases, speed up the system ;)
	$shorten_string = $smcFunc['substr']($string, 0, $length);
	
	// The special case html tag (Normal only Admin can do that...)
	if (stripos($shorten_string, '[html]') !== false)
	{
		// Later i do it again, but now we need to do this :)
		$lowercase_shortenstring = strtolower($shorten_string);
		$lowercasestring_count_fix = str_replace('][', '] [', $lowercase_shortenstring);

		// Only a open html tag? We trim it on the first html close =).
		if(stripos($shorten_string, '[/html]') === false)
			$length = stripos($string, '[/html]') + 7;
		// Okay more open than close tags inside i trim on the last html ;P
		elseif(substr_count($lowercasestring_count_fix, '[html]') > substr_count($lowercasestring_count_fix, '[/html]'))
			$length = sp_strrpos_needle($shorten_string, '[html]');
		
		// Okay new short string :)	
		$shorten_string = $smcFunc['substr']($string, 0, $length);

		// So i escape here if the shorten text start with html and finished with a closed html ;) Normal if the user do nothing strange this would be work and fixed by SMF =)
		if(stripos($shorten_string, '[html]') === 0 && strlen($shorten_string) <= sp_strrpos_needle(strtolower($shorten_string), '[/html]') + 7)
			return $shorten_string;
	}
	
	// First remove the last open tag =D and not close tags!
	$cutoff = max(strrpos($string, ' '), strrpos($string, '<'));
	if ($cutoff !== false)
		$shorten_string = $smcFunc['substr']($shorten_string, 0, $cutoff);
	
	// Remove open but not closed tags :)
	if (strrpos($shorten_string, '[') > strrpos($shorten_string, ']'))
		$shorten_string = $smcFunc['substr']($shorten_string, 0, strrpos($shorten_string, '['));
	
	// Update again... the last time i hope :P
	$lowercase_shortenstring = strtolower($shorten_string);

	// Remove open tags, very simple :D
	foreach ($removeOpenTags as $toRemove)
	{
		// Check if there is an last open tag inside ;)
		$lastTagPos = sp_strrpos_needle($lowercase_shortenstring, '[' . $toRemove);
		if ($lastTagPos !== 0)
			continue;
		
		// Okay let's see if the last one behind the last close, if yes remove it :P
		if ($lastTagPos > sp_strrpos_needle($lowercase_shortenstring, '[/' . $toRemove . ']'))
		{
			$shorten_string = substr($shorten_string, 0, $lastTagPos);
			$lowercase_shortenstring = strtolower($shorten_string);
		}
	}

	// Let's find open and close bbc tags =D
	preg_match_all('~\[(.+?)\]~', $lowercase_shortenstring, $tags);
	if (!empty($tags))
	{
		$unparsed_content = false;
		$close_tags = array();
		$close_tag = '';
		// First remove not closable tags and not existing tags :)
		foreach ($tags[0] as $key => $item)
		{
			$tag = $tags[1][$key];

			// Some Special cases ;)
			if(strpos($tag, '=') !== false)
				$tag = current(explode('=', $tag));
			if(strpos($tag, ' ') !== false)
				$tag = current(explode(' ', $tag));

			$closed = substr($tag, 0, 1) == '/';
			// Remove this tag until it closed :D
			if ($close_tag != $tag && $unparsed_content)
			{
				unset($tags[0][$key], $tags[1][$key]);
				continue;
			}
			else
				$unparsed_content = false;
			
			if ($closed)
			{
				$tag = substr($tag, 1);
				if (empty($toFixTags[$tag]))
					unset($tags[0][$key], $tags[1][$key]);
				elseif (!empty($close_tags[$tag]))
				{
					if (count($close_tags[$tag]) == 1)
						unset($close_tags[$tag]);
					else
					{
						// Remove the last item :D
						end($close_tags[$tag]);
						unset($close_tags[$tag][key($close_tags[$tag])]);
					}
				}
				continue;
			}

			// Remove this unkown tag
			if (empty($toFixTags[$tag]))
				unset($tags[0][$key], $tags[1][$key]);
			// This are tags who evertime closed automatic!
			elseif ($toFixTags[$tag]['no_close_tag'])
				unset($tags[0][$key], $tags[1][$key]);
			elseif (!$toFixTags[$tag]['parsed_content'])
			{
				$close_tag = '/' . $tag;
				$unparsed_content = true;
				$close_tags[$tag][$key] = '[/'.$tag.']';
			}
			else
				$close_tags[$tag][$key] = '[/'.$tag.']';
		}
		
		// Now i will close the tags in the correct order ;D
		if (!empty($close_tags))
		{
			$nostop = true;
			$ordered_close = array();
			while ($nostop)
			{
				$ordered_close += current($close_tags);	
				$nostop = next($close_tags) !== false;
			}
			krsort($ordered_close, SORT_NUMERIC);
			$shorten_string .= implode("", $ordered_close);
		}
	}
	
	return $shorten_string;
}

// This will find the correct last needle php4 compatiple for long needles!
function sp_strrpos_needle($haystack, $needle)
{
	if (@version_compare('5.0.0') != -1)
		return strrpos($haystack, $needle);
	else
		return strlen($haystack) - strpos(strrev($haystack), strrev($needle)) - strlen($needle);
}

?>