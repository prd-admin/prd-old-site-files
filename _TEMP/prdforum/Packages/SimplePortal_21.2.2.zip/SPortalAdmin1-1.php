<?php
/**********************************************************************************
* SPortalAdmin1-1.php                                                             *
***********************************************************************************
* SimplePortal                                                                    *
* SMF Modification Project Founded by [SiNaN] (sinan@simplemachines.org)          *
* =============================================================================== *
* Software Version:           SimplePortal 2.2.2                                  *
* Software by:                SimplePortal Team (http://www.simpleportal.net)     *
* Copyright 2008-2009 by:     SimplePortal Team (http://www.simpleportal.net)     *
* Support, News, Updates at:  http://www.simpleportal.net                         *
***********************************************************************************
* This program is free software; you may redistribute it and/or modify it under   *
* the terms of the provided license as published by Simple Machines LLC.          *
*                                                                                 *
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
*                                                                                 *
* See the "license.txt" file for details of the Simple Machines license.          *
* The latest version can always be found at http://www.simplemachines.org.        *
**********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

/*
	void SPortalAdmin()
		// !!!

	void GeneralSettings()
		// !!!

	void BlockSettings()
		// !!!

	void ArticleSettings()
		// !!!

	void Information()
		// !!!

	void BlockList()
		// !!!

	void BlockEdit()
		// !!!

	void BlockDelete()
		// !!!

	void BlockMove()
		// !!!

	void ArticleList()
		// !!!

	array getArticleEntry()
		// !!!

	void ArticleAdd()
		// !!!

	void ArticleEdit()
		// !!!

	void ArticleDelete()
		// !!!

	void CategoryList()
		// !!!

	void CategoryAdd()
		// !!!

	void CategoryEdit()
		// !!!

	void CategoryDelete()
		// !!!

	void StateChange()
		// !!!

	void ColumnChange()
		// !!!
*/

// Main function handling all the actions.
function SPortalAdmin()
{
	global $context, $txt, $scripturl, $sourcedir;

	// Can you moderate it my dear?
	isAllowedTo('sp_moderate');
	
	// Set the index to recognize.
	adminIndex('sportal');

	// Love this template. :)
	loadTemplate('SPortalAdmin1-1');

	// This is only in SMF 1.1.x needed.
	if(loadLanguage('SPortalAdmin', '', false) === false)
			loadLanguage('SPortalAdmin', 'english');

	if(loadLanguage('SPortalHelp', '', false) === false)
		loadLanguage('SPortalHelp', 'english');

	// Include for the saveDB.
	require_once($sourcedir . '/ManageServer.php');

	// Rather a *small* one, yeah? :P
	$areas = array(
		'config' => array(
			'information' => 'Information',
			'generalsettings' => 'GeneralSettings',
			'blocksettings' => 'BlockSettings',
			'articlesettings' => 'ArticleSettings',
		),
		'blocks' => array(
			'list' => 'BlockList',
			'left' => 'BlockList',
			'top' => 'BlockList',
			'bottom' => 'BlockList',
			'right' => 'BlockList',
			'add' => 'BlockEdit',
			'edit' => 'BlockEdit',
			'delete' => 'BlockDelete',
			'move' => 'BlockMove',
			'columnchange' => 'ColumnChange',
			'statechange' => 'StateChange',
		),
		'articles' => array(
			'list' => 'ArticleList',
			'add' => 'ArticleAdd',
			'edit' => 'ArticleEdit',
			'delete' => 'ArticleDelete',
			'statechange' => 'StateChange',
		),
		'categories' => array(
			'list' => 'CategoryList',
			'add' => 'CategoryAdd',
			'edit' => 'CategoryEdit',
			'delete' => 'CategoryDelete',
			'statechange' => 'StateChange',
		),
	);

	// Set the default as the general settings.
	$_REQUEST['area'] = isset($_REQUEST['area']) && isset($areas[$_REQUEST['area']]) ? $_REQUEST['area'] : 'config';
	$_REQUEST['sa'] = isset($_REQUEST['sa']) && isset($areas[$_REQUEST['area']][$_REQUEST['sa']]) ? $_REQUEST['sa'] : ($_REQUEST['area'] == 'config' ? 'information' : 'list');

	$context['page_title'] = $txt['sp-adminTitle'];
	$context['sub_action'] = $_REQUEST['sa'];
	$context['admin_area'] = $_REQUEST['area'];

	// Blocks area menu.
	if($_REQUEST['area'] == 'blocks')
	{
		$context['admin_tabs'] = array(
			'title' => $txt['sp-blocksBlocks'],
			'help' => 'sp_BlocksArea',
			'description' => $txt['sp-adminBlockListDesc'],
			'tabs' => array(
				'list' => array(
					'title' => $txt['sp-adminBlockListName'],
					'description' => $txt['sp-adminBlockListDesc'],
					'href' => $scripturl . '?action=spadmin;area=blocks;sa=list',
					'is_selected' => $_REQUEST['sa'] == 'list' || $_REQUEST['sa'] == 'edit',
				),
				'add' => array(
					'title' => $txt['sp-adminBlockAddName'],
					'description' => $txt['sp-adminBlockAddDesc'],
					'href' => $scripturl . '?action=spadmin;area=blocks;sa=add',
					'is_selected' => $_REQUEST['sa'] == 'add',
				),
				'left' => array(
					'title' => $txt['sp-positionLeft'],
					'description' => $txt['sp-adminBlockLeftListDesc'],
					'href' => $scripturl . '?action=spadmin;area=blocks;sa=left',
					'is_selected' => $_REQUEST['sa'] == 'left',
				),
				'top' => array(
					'title' => $txt['sp-positionTop'],
					'description' => $txt['sp-adminBlockTopListDesc'],
					'href' => $scripturl . '?action=spadmin;area=blocks;sa=top',
					'is_selected' => $_REQUEST['sa'] == 'top',				
				),
				'bottom' => array(
					'title' => $txt['sp-positionBottom'],
					'description' => $txt['sp-adminBlockBottomListDesc'],
					'href' => $scripturl . '?action=spadmin;area=blocks;sa=bottom',
					'is_selected' => $_REQUEST['sa'] == 'bottom',				
				),
				'right' => array(
					'title' => $txt['sp-positionRight'],
					'description' => $txt['sp-adminBlockRightListDesc'],
					'href' => $scripturl . '?action=spadmin;area=blocks;sa=right',
					'is_selected' => $_REQUEST['sa'] == 'right',				
				),
			),
		);
	}
	// Articles area menu.
	elseif($_REQUEST['area'] == 'articles')
	{
		$context['admin_tabs'] = array(
			'title' => $txt['sp-adminCatTitle'],
			'help' => 'sp_ArticlesArea',
			'description' => $txt['sp-adminCatDesc'],
			'tabs' => array(
				'list' => array(
					'title' => $txt['sp-adminArticleListName'],
					'description' => $txt['sp-adminArticleListDesc'],
					'href' => $scripturl . '?action=spadmin;area=articles;sa=list',
					'is_selected' => $_REQUEST['sa'] == 'list' || $_REQUEST['sa'] == 'edit',
				),
				'add' => array(
					'title' => $txt['sp-adminArticleAddName'],
					'description' => $txt['sp-adminArticleAddDesc'],
					'href' => $scripturl . '?action=spadmin;area=articles;sa=add',
					'is_selected' => $_REQUEST['sa'] == 'add',
				),
			),
		);
	}
	// Categories area menu.
	elseif($_REQUEST['area'] == 'categories')
	{
		$context['admin_tabs'] = array(
			'title' => $txt['sp-adminCatTitle'],
			'help' => 'sp_CategoriesArea',
			'description' => $txt['sp-adminCatDesc'],
			'tabs' => array(
				'list' => array(
					'title' => $txt['sp-adminCategoryListName'],
					'description' => $txt['sp-adminCategoryListDesc'],
					'href' => $scripturl . '?action=spadmin;area=categories;sa=list',
					'is_selected' => $_REQUEST['sa'] == 'list' || $_REQUEST['sa'] == 'edit',
				),
				'add' => array(
					'title' => $txt['sp-adminCategoryAddName'],
					'description' => $txt['sp-adminCategoryAddDesc'],
					'href' => $scripturl . '?action=spadmin;area=categories;sa=add',
					'is_selected' => $_REQUEST['sa'] == 'add',
				),
			),
		);
	}
	// Configuration area menu.
	else
	{
		$context['admin_tabs'] = array(
			'title' => $txt['sp-adminConfiguration'],
			'help' => 'sp_ConfigurationArea',
			'description' => $txt['sp-adminConfigurationDesc'],
			'tabs' => array(
				'information' => array(
					'title' => $txt['sp-info_title'],
					'description' => $txt['sp-info_desc'],
					'href' => $scripturl . '?action=spadmin;area=config;sa=information',
					'is_selected' => $_REQUEST['sa'] == 'information',
				),
				'generalsettings' => array(
					'title' => $txt['sp-adminGeneralSettingsName'],
					'description' => $txt['sp-adminConfigurationDesc'],
					'href' => $scripturl . '?action=spadmin;area=config;sa=generalsettings',
					'is_selected' => $_REQUEST['sa'] == 'generalsettings',
				),
				'blocksettings' => array(
					'title' => $txt['sp-adminBlockSettingsName'],
					'description' => $txt['sp-adminConfigurationDesc'],
					'href' => $scripturl . '?action=spadmin;area=config;sa=blocksettings',
					'is_selected' => $_REQUEST['sa'] == 'blocksettings',
				),
				'articlesettings' => array(
					'title' => $txt['sp-adminArticleSettingsName'],
					'description' => $txt['sp-adminConfigurationDesc'],
					'href' => $scripturl . '?action=spadmin;area=config;sa=articlesettings',
					'is_selected' => $_REQUEST['sa'] == 'articlesettings',
				),
			),
		);
	}

	// We need this everywhere.
	require_once($sourcedir . '/Subs-SPortal1-1.php');

	// Call the right function.
	$areas[$_REQUEST['area']][$_REQUEST['sa']]();
}

function GeneralSettings()
{
	global $db_prefix, $context, $scripturl, $txt;

	$request = db_query("
		SELECT ID_THEME, value AS name
		FROM {$db_prefix}themes
		WHERE variable = 'name'
			AND ID_MEMBER = 0
		ORDER BY ID_THEME", __FILE__, __LINE__);
	$context['sp_themes'] = array('0' => &$txt['portalthemedefault']);
	while ($row = mysql_fetch_assoc($request))
		$context['sp_themes'][$row['ID_THEME']] = $row['name'];
	mysql_free_result($request);

	$config_vars = array(
			array('select', 'sp_portal_mode', explode('|', $txt['sp_portal_mode_options'])),
			array('check', 'sp_maintenance'),
			array('text', 'sp_standalone_url'),
		'',
			array('select', 'portaltheme', $context['sp_themes']),
			array('check', 'sp_disableColor'),
			array('check', 'sp_disableForumRedirect'),
			array('check', 'sp_disable_random_bullets'),
			array('check', 'sp_disable_php_validation'),
			array('check', 'sp_disable_side_collapse'),
	);

	if (isset($_GET['save']))
	{
		checkSession();

		saveDBSettings($config_vars);
		redirectexit('action=spadmin;area=config;sa=generalsettings');
	}

	$context['post_url'] = $scripturl . '?action=spadmin;area=config;sa=generalsettings;save';
	$context['settings_title'] = $txt['sp-adminGeneralSettingsName'];
	$context['sub_template'] = 'general_settings';

	prepareDBSettingContext($config_vars);
}

function BlockSettings()
{
	global $context, $scripturl, $txt;

	$config_vars = array(
			array('check', 'showleft'),
			array('check', 'showright'),
			array('text', 'leftwidth'),
			array('text', 'rightwidth'),
		'',
			array('check', 'sp_enableIntegration'),
			array(array('sp_adminIntegrationHide' => $txt[2], 'sp_profileIntegrationHide' => $txt[79], 'sp_pmIntegrationHide' => $txt[144], 'sp_mlistIntegrationHide' => $txt[19], 'sp_searchIntegrationHide' => $txt[182], 'sp_calendarIntegrationHide' => $txt['calendar24']), 'sp_IntegrationHide'),
	);

	if (isset($_GET['save']))
	{
		checkSession();

		$width_checkup = array('left', 'right');
		foreach ($width_checkup as $pos) 
		{
			if (!empty($_POST[$pos . 'width'])) 
			{
				if (stripos($_POST[$pos . 'width'], 'px') !== false)
					$suffix = 'px';
				elseif (strpos($_POST[$pos . 'width'], '%') !== false)
					$suffix = '%';
				else
					$suffix = '';

				preg_match_all('/(?:([0-9]+)|.)/i', $_POST[$pos . 'width'], $matches);

				$number = (int) implode('', $matches[1]);
				if(!empty($number) && $number > 0)
					$_POST[$pos . 'width'] = $number . $suffix;
				else
					$_POST[$pos . 'width'] = '';
			}
			else
				$_POST[$pos . 'width'] = '';
		}

		unset($config_vars[7]);
		$config_vars = array_merge(
			$config_vars,
			array(
				array('check', 'sp_adminIntegrationHide'),
				array('check', 'sp_profileIntegrationHide'),
				array('check', 'sp_pmIntegrationHide'),
				array('check', 'sp_mlistIntegrationHide'),
				array('check', 'sp_searchIntegrationHide'),
				array('check', 'sp_calendarIntegrationHide'),
			)
		);

		saveDBSettings($config_vars);
		redirectexit('action=spadmin;area=config;sa=blocksettings');
	}

	$context['post_url'] = $scripturl . '?action=spadmin;area=config;sa=blocksettings;save';
	$context['settings_title'] = $txt['sp-adminBlockSettingsName'];
	$context['sub_template'] = 'general_settings';

	prepareDBSettingContext($config_vars);
}

function ArticleSettings()
{
	global $context, $scripturl, $txt;

	$config_vars = array(
			array('check', 'articleactive'),
			array('int', 'articleperpage'),
			array('int', 'articlelength'),
			array('check', 'articleavatar'),
	);

	if (isset($_GET['save']))
	{
		checkSession();

		saveDBSettings($config_vars);
		redirectexit('action=spadmin;area=config;sa=articlesettings');
	}

	$context['post_url'] = $scripturl . '?action=spadmin;area=config;sa=articlesettings;save';
	$context['settings_title'] = $txt['sp-adminArticleSettingsName'];
	$context['sub_template'] = 'general_settings';

	prepareDBSettingContext($config_vars);
}

// The most important function of SP. :P
function Information($in_admin = true)
{
	global $context, $scripturl, $txt, $sourcedir, $sportal_version, $user_profile;

	$context['sp_credits'] = array(
		array(
			'pretext' => $txt['sp-info_intro'],
			'title' => $txt['sp-info_team'],
			'groups' => array(
				array(
					'title' => $txt['sp-info_groups_pm'],
					'members' => array(
						'Eliana Tamerin',
						'Huw',
					),
				),
				array(
					'title' => $txt['sp-info_groups_dev'],
					'members' => array(
						'<span onclick="if (getInnerHTML(this).indexOf(\'Sinan\') == -1) setInnerHTML(this, \'Sinan &quot;\' + getInnerHTML(this) + \'&quot; &Ccedil;evik\'); return false;">[SiNaN]</span>',
						'LHVWB',
						'&#12487;&#12451;&#12531;1031',
					),
				),
				array(
					'title' => $txt['sp-info_groups_support'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_customize'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_language'],
					'members' => array(
						'Jade &quot;Alundra&quot; Elizabeth',
					),
				),
				array(
					'title' => $txt['sp-info_groups_marketing'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_beta'],
					'members' => array(
						'Robbo',
						'BurkeKnight',
						'Mulgarus',
						'Ya&#287;&#305;z...',
					),
				),
			),
		),
		array(
			'title' => $txt['sp-info_special'],
			'posttext' => $txt['sp-info_anyone'],
			'groups' => array(
				array(
					'title' => $txt['sp-info_groups_translators'],
					'members' => array(
						$txt['sp-info_translators_message'],
					),
				),
				array(
					'title' => $txt['sp-info_groups_founder'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_groups_orignal_pm'],
					'members' => array(
					),
				),
				array(
					'title' => $txt['sp-info_fam_fam'],
					'members' => array(
						$txt['sp-info_fam_fam_message'],
					),
				),
			),
		),
	);

	if (!$in_admin)
	{
		loadTemplate('SPortalAdmin1-1');
		$context['robot_no_index'] = true;
		$context['in_admin'] = false;
	}
	else
	{
		$context['in_admin'] = true;
		$context['sp_version'] = $sportal_version;
		$context['sp_managers'] = array();

		require_once($sourcedir . '/Subs-Members.php');
		$manager_ids = loadMemberData(membersAllowedTo('sp_moderate'), false, 'minimal');

		if ($manager_ids)
			foreach ($manager_ids as $member)
				$context['sp_managers'][] = '<a href="' . $scripturl . '?action=profile;u=' . $user_profile[$member]['ID_MEMBER'] . '">' . $user_profile[$member]['realName'] . '</a>';
	}

	$context['sub_template'] = 'information';
	$context['page_title'] = $txt['sp-info_title'];
}

// Shows up block list.
function BlockList()
{
	global $txt, $context;
	
	// We have 4 sides...
	$context['sides'] = array(
		'left' => array(
			'id' => '1',
			'name' => 'Left',
			'label' => $txt['sp-positionLeft'],
			'help' => 'sp-blocksLeftList',
		),
		'top' => array(
			'id' => '2',
			'name' => 'Middle-Top',
			'label' => $txt['sp-positionTop'],
			'help' => 'sp-blocksTopList',
		),
		'bottom' => array(
			'id' => '3',
			'name' => 'Middle-Bottom',
			'label' => $txt['sp-positionBottom'],
			'help' => 'sp-blocksBottomList',
		),
		'right' => array(
			'id' => '4',
			'name' => 'Right',
			'label' => $txt['sp-positionRight'],
			'help' => 'sp-blocksRightList',
		),
	);

	$sides = array('left', 'top', 'bottom', 'right');
	// Are we viewing any of the sub lists for an individual side?
	if(in_array($context['sub_action'], $sides))
	{
		// Remove any sides that we don't need to show. ;)
		foreach($sides as $side)
		{
			if($context['sub_action'] != $side)
				unset($context['sides'][$side]);
		}
		$context['sp_blocks_single_side_list'] = true;
	}
	
	// Columns to show.
	$context['columns'] = array(
		'label' => array(
			'width' => '40%',
			'label' => $txt['sp-adminColumnName'],
		),
		'type' => array(
			'width' => '40%',
			'label' => $txt['sp-adminColumnType'],
		),
		'move' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnMove'],
		),
		'action' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnAction'],
		),
	);

	// Get block info for each side.
	foreach($context['sides'] as $side) {
		$context['blocks'][$side['name']] = getBlockInfo($side['id']);
	}

	// Call the sub template.
	$context['sub_template'] = 'block_list';

}

function BlockEdit()
{
	global $txt, $context, $modSettings, $db_prefix, $func;

	$context['SPortal']['is_new'] = empty($_REQUEST['block_id']);

	if ($context['SPortal']['is_new'] && empty($_POST['selected_type']) && empty($_POST['add_block']))
	{
		$context['SPortal']['block_types'] = getFunctionInfo();
			
		if (!empty($_REQUEST['col']))
			$context['SPortal']['block']['column'] = $_REQUEST['col'];

		$context['sub_template'] = 'block_select_type';
	}
	elseif ($context['SPortal']['is_new'] && !empty($_POST['selected_type']))
	{
		$context['SPortal']['block'] = array(
			'id' => 0,
			'label' => $txt['sp-blocksDefaultLabel'],
			'type' => $_POST['selected_type'][0],
			'type_text' => !empty($txt['sp_function_' . $_POST['selected_type'][0] . '_label']) ? $txt['sp_function_' . $_POST['selected_type'][0] . '_label'] : $txt['sp_function_unknown_label'],
			'column' => !empty($_POST['block_column']) ? $_POST['block_column'] : 0,
			'row' => 0,
			'state' => 1,
			'force_view' => 0,
			'allowed_groups' => 'all',
			'permission_type' => 0,
			'display' => '',
			'display_custom' => '',
			'style' => '',
			'parameters' => array(),
			'options'=> $_POST['selected_type'][0](array(), false, true),
			'list_blocks' => !empty($_POST['block_column']) ? getBlockInfo($_POST['block_column']) : array(),
		);
	}
	elseif (!$context['SPortal']['is_new'] && empty($_POST['add_block']))
	{
		$_REQUEST['block_id'] = (int) $_REQUEST['block_id'];
		$context['SPortal']['block'] = current(getBlockInfo(null, $_REQUEST['block_id']));

		$context['SPortal']['block'] += array(
			'options'=> $context['SPortal']['block']['type'](array(), false, true),
			'list_blocks' => getBlockInfo($context['SPortal']['block']['column']),
		);

		if ($context['SPortal']['block']['type'] == 'sp_php' && isset($context['SPortal']['block']['parameters']['content']))
			$context['SPortal']['block']['parameters']['content'] = htmlspecialchars($context['SPortal']['block']['parameters']['content']);
	}

	if (!empty($_POST['preview_block']))
	{
		if (empty($_POST['display_advanced']))
		{
			if (!empty($_POST['display_simple']) && in_array($_POST['display_simple'], array('all', 'sportal', 'sforum', 'allaction', 'allboard')))
				$display = $_POST['display_simple'];
			else
				$display = '';

			$custom = '';
		}
		else
		{
			$display = array();
			$custom = array();

			if (!empty($_POST['display_actions']))
				foreach ($_POST['display_actions'] as $action)
					$display[] = addslashes($func['htmlspecialchars'](stripslashes($action), ENT_QUOTES));
			
			if (!empty($_POST['display_boards']))
				foreach ($_POST['display_boards'] as $board)
					$display[] = (int) $board;

			if (!empty($_POST['display_custom']))
			{
				$temp = explode(',', $_POST['display_custom']);
				foreach ($temp as $action)
					$custom[] = addslashes($func['htmlspecialchars'](stripslashes($action), ENT_QUOTES));
			}

			$display = empty($display) ? '' : implode(', ', $display);
			$custom = empty($custom) ? '' : implode(', ', $custom);
		}

		$style = '';
		$style_parameters = array(
			'title_default_class',
			'title_custom_class',
			'title_custom_style',
			'body_default_class',
			'body_custom_class',
			'body_custom_style',
			'no_title',
			'no_body',
		);

		foreach ($style_parameters as $parameter)
			if (isset($_POST[$parameter]))
				$style .= $parameter . '~' . addslashes($func['htmlspecialchars'](stripslashes($_POST[$parameter]), ENT_QUOTES)) . '|';
			else
				$style .= $parameter . '~|';

		if (!empty($style))
			$style = substr($style, 0, -1);

		if (!empty($_POST['parameters']))
			foreach ($_POST['parameters'] as $variable => $value)
				$_POST['parameters'][$variable] = stripslashes($value);

		$context['SPortal']['block'] = array(
			'id' => $_POST['block_id'],
			'label' => stripslashes($_POST['block_name']),
			'type' => $_POST['block_type'],
			'type_text' => !empty($txt['sp_function_' . $_POST['block_type'] . '_label']) ? $txt['sp_function_' . $_POST['block_type'] . '_label'] : $txt['sp_function_unknown_label'],
			'column' => $_POST['block_column'],
			'row' => !empty($_POST['block_row']) ? $_POST['block_row'] : 0,
			'state' => !empty($_POST['block_active']),
			'force_view' => !empty($_POST['block_force']),
			'allowed_groups' => $_POST['member_groups'],
			'permission_type' => $_POST['permission_type'],
			'display' => $display,
			'display_custom' => $custom,
			'style' => $style,
			'parameters' => !empty($_POST['parameters']) ? $_POST['parameters'] : array(),
			'options'=> $_POST['block_type'](array(), false, true),
			'list_blocks' => getBlockInfo($_POST['block_column']),
			'collapsed' => false,
		);

		if (strpos($modSettings['leftwidth'], '%') !== false || strpos($modSettings['leftwidth'], 'px') !== false)
			$context['widths'][1] = $modSettings['leftwidth'];
		else
			$context['widths'][1] = $modSettings['leftwidth'] . 'px';

		if (strpos($modSettings['rightwidth'], '%') !== false || strpos($modSettings['rightwidth'], 'px') !== false)
			$context['widths'][4] = $modSettings['rightwidth'];
		else
			$context['widths'][4] = $modSettings['rightwidth'] . 'px';

		if (strpos($context['widths'][1], '%') !== false)
			$context['widths'][2] = $context['widths'][3] = 100 - ($context['widths'][1] + $context['widths'][4]) . '%';
		elseif (strpos($context['widths'][1], 'px') !== false)
			$context['widths'][2] = $context['widths'][3] = 960 - ($context['widths'][1] + $context['widths'][4]) . 'px';

		$context['SPortal']['preview'] = true;
	}

	if (!empty($_POST['selected_type']) || !empty($_POST['preview_block']) || (!$context['SPortal']['is_new'] && empty($_POST['add_block'])))
	{
		if ($context['SPortal']['block']['type'] == 'sp_php' && !allowedTo('admin_forum'))
			fatal_lang_error('cannot_admin_forum', false);

		$context['html_headers'] .= '
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		function sp_collapseObject(id)
		{
			mode = document.getElementById("sp_object_" + id).style.display == "" ? 0 : 1;
			document.getElementById("sp_collapse_" + id).src = smf_images_url + (mode ? "/collapse.gif" : "/expand.gif");
			document.getElementById("sp_object_" + id).style.display = mode ? "" : "none";
		}
	// ]]></script>';

		if (loadLanguage('SPortalHelp', '', false) === false)
			loadLanguage('SPortalHelp', 'english');

		if (isset($_POST['member_groups']))
			$context['SPortal']['block']['allowed_groups'] = $_POST['member_groups'];

		sp_loadMemberGroups($context['SPortal']['block']['allowed_groups']);

		$context['simple_actions'] = array(
			'sportal' => $txt['sp-portal'],
			'sforum' => $txt['sp-forum'],
			'allaction' => $txt['sp-blocksOptionAllActions'],
			'allboard' => $txt['sp-blocksOptionAllBoards'],
			'all' => $txt['sp-blocksOptionAllPages'],
		);

		$context['display_actions'] = array(
			'portal' => $txt['sp-portal'],
			'forum' => $txt['sp-forum'],
			'recent' => $txt[214],
			'unread' => $txt['unread_topics_visit'],
			'unreadreplies' => $txt['unread_replies'],
			'profile' => $txt[79],
			'pm' => $txt[144],
			'calendar' => $txt['calendar24'],
			'admin' =>  $txt[2],
			'login' =>  $txt[34],
			'register' =>  $txt[97],
			'post' =>  $txt[105],
			'stats' =>  $txt[645],
			'search' =>  $txt[182],
			'mlist' =>  $txt[19],
			'help' =>  $txt[119],
			'who' =>  $txt['who_title'],
		);

		$request = db_query("
			SELECT id_board, name
			FROM {$db_prefix}boards
			ORDER BY name DESC", __FILE__, __LINE__);
		$context['display_boards'] = array();
		while ($row = mysql_fetch_assoc($request))
			$context['display_boards'][$row['id_board']] = $row['name'];
		mysql_free_result($request);

		if (empty($context['SPortal']['block']['display']))
			$context['SPortal']['block']['display'] = array('0');
		else
			$context['SPortal']['block']['display'] = explode(', ', $context['SPortal']['block']['display']);

		if (in_array($context['SPortal']['block']['display'][0], array('all', 'sportal', 'sforum', 'allaction', 'allboard')) || $context['SPortal']['is_new'] || empty($context['SPortal']['block']['display'][0]) && empty($context['SPortal']['block']['display_custom']))
			$context['SPortal']['block']['display_type'] = 0;
		else
			$context['SPortal']['block']['display_type'] = 1;

		if (!empty($context['SPortal']['block']['style']))
		{
			$temp = explode('|', $context['SPortal']['block']['style']);
			$context['SPortal']['block']['style'] = array();

			foreach ($temp as $style)
			{
				list ($key, $value) = explode('~', $style);
				$context['SPortal']['block']['style'][$key] = $value;
			}
		}
		else
		{
			$context['SPortal']['block']['style'] = array(
				'title_default_class' => 'catbg',
				'title_custom_class' => '',
				'title_custom_style' => '',
				'body_default_class' => 'windowbg',
				'body_custom_class' => '',
				'body_custom_style' => '',
				'no_title' => false,
				'no_body' => false,
			);
		}

		$context['sub_template'] = 'block_edit';
	}

	if (!empty($_POST['add_block']))
	{
		if ($_POST['block_type'] == 'sp_php' && !allowedTo('admin_forum'))
			fatal_lang_error('cannot_admin_forum', false);

		if (!isset($_POST['block_name']) || $func['htmltrim']($func['htmlspecialchars']($_POST['block_name']), ENT_QUOTES) === '')
			fatal_lang_error('error_sp_name_empty', false);
		
		if ($_POST['block_type'] == 'sp_php' && !empty($_POST['block_content']) && empty($modSettings['sp_disable_php_validation']))
		{
			$error = sp_validate_php(stripslashes($_POST['block_content']));

			if ($error)
				fatal_lang_error('error_sp_php_' . $error, false);
		}

		if (!empty($_POST['placement']) && (($_POST['placement'] == 'before') || ($_POST['placement'] == 'after')))
		{
			if (!empty($_REQUEST['block_id']) && ($temp = current(getBlockInfo(null, $_REQUEST['block_id']))))
				$current_row = $temp['row'];
			else
				$current_row = null;

			if ($_POST['placement'] == 'before')
				$row = (int) $_POST['block_row'];
			else
				$row = (int) $_POST['block_row'] + 1;
			
			if (!empty($current_row) && ($row > $current_row))
			{
				$row = $row - 1;

				db_query("
					UPDATE {$db_prefix}sp_blocks
					SET row = row - 1
					WHERE col = ".(int) $_POST['block_column']."
						AND row > $current_row
						AND row <= $row", __FILE__, __LINE__);
			}
			else
			{
				db_query("
					UPDATE {$db_prefix}sp_blocks
					SET row = row + 1
					WHERE col = " . (int) $_POST['block_column'] . "
						AND row >= $row" . (!empty($current_row) ? "
						AND row < $current_row" : ""), __FILE__, __LINE__);
			}
		}
		elseif (!empty($_POST['placement']) && $_POST['placement'] == 'nochange') 
			$row = 0;
		else 
		{
			$request = db_query("
				SELECT row
				FROM {$db_prefix}sp_blocks
				WHERE col = " . (int) $_POST['block_column'] . (!empty($_REQUEST['block_id']) ? "
            AND id_block != " . (int) $_REQUEST['block_id'] : "") . "
				ORDER BY row DESC
				LIMIT 1",__FILE__, __LINE__);
			list ($row) = mysql_fetch_row($request);
			mysql_free_result($request);

			$row = $row + 1;
		}

		$type_parameters = $_POST['block_type'](array(), 0, true);

		if (!empty($_POST['parameters']) && is_array($_POST['parameters']) && !empty($type_parameters))
		{
			foreach ($type_parameters as $name => $type)
			{
				if (isset($_POST['parameters'][$name]))
				{
					if ($type == 'int' || $type == 'select')
						$_POST['parameters'][$name] = (int) $_POST['parameters'][$name];
					elseif (($type == 'text' || $type == 'content') && $_POST['block_type'] != 'sp_php')
						$_POST['parameters'][$name] = addslashes($func['htmlspecialchars'](stripslashes($_POST['parameters'][$name]), ENT_QUOTES));
					elseif ($type == 'check')
						$_POST['parameters'][$name] = !empty($_POST['parameters'][$name]) ? 1 : 0;
				}
			}
		}
		else
			$_POST['parameters'] = array();

		if (!empty($_POST['member_groups']) && is_array($_POST['member_groups']))
			$_POST['allowed_groups'] = implode(',', $_POST['member_groups']);
		else
			$_POST['allowed_groups'] = '';

		if (empty($_POST['display_advanced']))
		{
			if (!empty($_POST['display_simple']) && in_array($_POST['display_simple'], array('all', 'sportal', 'sforum', 'allaction', 'allboard')))
				$display = $_POST['display_simple'];
			else
				$display = '';

			$custom = '';
		}
		else
		{
			$display = array();
			$custom = array();

			if (!empty($_POST['display_actions']))
				foreach ($_POST['display_actions'] as $action)
					$display[] = addslashes($func['htmlspecialchars'](stripslashes($action), ENT_QUOTES));
			
			if (!empty($_POST['display_boards']))
				foreach ($_POST['display_boards'] as $board)
					$display[] = (int) $board;

			if (!empty($_POST['display_custom']))
			{
				$temp = explode(',', $_POST['display_custom']);
				foreach ($temp as $action)
					$custom[] = addslashes($func['htmlspecialchars']($func['htmltrim'](stripslashes($action)), ENT_QUOTES));
			}

			$display = empty($display) ? '' : implode(', ', $display);
			$custom = empty($custom) ? '' : implode(', ', $custom);
		}

		$style = '';
		$style_parameters = array(
			'title_default_class',
			'title_custom_class',
			'title_custom_style',
			'body_default_class',
			'body_custom_class',
			'body_custom_style',
			'no_title',
			'no_body',
		);

		foreach ($style_parameters as $parameter)
			if (isset($_POST[$parameter]))
				$style .= $parameter . '~' . addslashes($func['htmlspecialchars'](stripslashes($_POST[$parameter]), ENT_QUOTES)) . '|';
			else
				$style .= $parameter . '~|';

		if (!empty($style))
			$style = substr($style, 0, -1);

		$blockInfo = array(
			'id' => (int) $_POST['block_id'],
			'label' => addslashes($func['htmlspecialchars'](stripslashes($_POST['block_name']), ENT_QUOTES)),
			'type' => $_POST['block_type'],
			'col' => $_POST['block_column'],
			'row' => $row,
			'state' => !empty($_POST['block_active']) ? 1 : 0,
			'force_view' => !empty($_POST['block_force']) ? 1 : 0,
			'allowed_groups' => $_POST['allowed_groups'],
			'permission_type' => empty($_POST['permission_type']) || $_POST['permission_type'] > 2 ? 0 : $_POST['permission_type'],
			'display' => $display,
			'display_custom' => $custom,
			'style' => $style,
		);

		if ($context['SPortal']['is_new'])
		{
			unset($blockInfo['id']);

			$insert = array();
			foreach ($blockInfo as $key => $info)
				$insert[$key] = "'" . $info . "'";

			db_query("
				INSERT INTO {$db_prefix}sp_blocks
					(" . implode(', ', array_keys($insert)) . ")
				VALUES
					(" . implode(', ', $insert) . ")", __FILE__, __LINE__);

			$blockInfo['id'] = db_insert_id();
		}
		else
		{
			$block_fields = array(
				"label = '$blockInfo[label]'",
				"state = '$blockInfo[state]'",
				"force_view = '$blockInfo[force_view]'",
				"allowed_groups = '$blockInfo[allowed_groups]'",
				"permission_type = '$blockInfo[permission_type]'",
				"display = '$blockInfo[display]'",
				"display_custom = '$blockInfo[display_custom]'",
				"style = '$blockInfo[style]'",
			);

			if (!empty($blockInfo['row']))
				$block_fields[] = "row = '$blockInfo[row]'";
			else
				unset($blockInfo['row']);

			db_query("
				UPDATE {$db_prefix}sp_blocks
				SET " . implode(', ', $block_fields) . "
				WHERE ID_BLOCK = $blockInfo[id]
				LIMIT 1", __FILE__, __LINE__);

			db_query("
				DELETE FROM {$db_prefix}sp_parameters
				WHERE ID_BLOCK = $blockInfo[id]", __FILE__, __LINE__);
		}

		if (!empty($_POST['parameters']))
		{
			$parameters = '';
			foreach ($_POST['parameters'] as $variable => $value)
				$parameters .= "('$blockInfo[id]', '$variable', '$value'),";

			if (substr($parameters, -1) == ',')
				$parameters = substr($parameters, 0, -1);

			db_query("
				INSERT INTO {$db_prefix}sp_parameters
					(ID_BLOCK, variable, value)
				VALUES
					$parameters", __FILE__, __LINE__);
		}

		redirectexit('action=spadmin;area=blocks;sa=list');
	}
}

// Function for deteling a block.
function BlockDelete()
{
	global $db_prefix;

	// Check if he can?
	checkSession('get');

	// Make sure ID is an integer.
	$_REQUEST['block_id'] = (int) $_REQUEST['block_id'];

	// Do we have that?
	if(empty($_REQUEST['block_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// Make sure column ID is an integer too.
	$_REQUEST['col'] = (int)$_REQUEST['col'];
	
	//Only Admins can Remove PHP Blocks :D
	if(!allowedTo('admin_forum')) {
		$context['SPortal']['block_info'] = current(getBlockInfo(null, $_REQUEST['block_id']));
		if($context['SPortal']['block_info']['type'] == 'sp_php' && !allowedTo('admin_forum'))
			fatal_lang_error('cannot_admin_forum', false);
	}
	
	// We don't need it anymore.
	db_query("
		DELETE FROM {$db_prefix}sp_blocks
		WHERE ID_BLOCK = '$_REQUEST[block_id]'
		LIMIT 1", __FILE__, __LINE__);

	db_query("
		DELETE FROM {$db_prefix}sp_parameters
		WHERE ID_BLOCK = '$_REQUEST[block_id]'", __FILE__, __LINE__);

	// Fix column rows.
	fixColumnRows($_REQUEST['col']);

	// Return back to the block list.
	redirectexit('action=spadmin;area=blocks;sa=list');
}

// Function for moving a block.
function BlockMove()
{
	global $db_prefix;

	// Check if he can?
	checkSession('get');

	// Make sure ID is an integer.
	$_REQUEST['block_id'] = (int)$_REQUEST['block_id'];

	// Check it!
	if(empty($_REQUEST['block_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// Change it with the magical tool.
	changeBlockRow($_REQUEST['block_id'], $_REQUEST['direction']);

	$area = !empty($_GET['redirect']) ? $_GET['redirect'] : 'list';

	// Return back to the block list.
	redirectexit('action=spadmin;area=blocks;sa=' . $area);
}

// Gets the category list.
function CategoryList()
{
	global $txt, $context;

	// Category list columns.
	$context['columns'] = array(
		'picture' => array(
			'width' => '35%',
			'label' => $txt['sp-adminColumnPicture'],
		),
		'name' => array(
			'width' => '45%',
			'label' => $txt['sp-adminColumnName'],
		),
		'articles' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnArticles'],
		),
		'publish' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnPublish'],
		),
		'action' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnAction'],
		),
	);

	// Get all the categories.
	$context['categories'] = getCategoryInfo();

	// Call the sub template.
	$context['sub_template'] = 'category_list';
}

// Function for adding a category.
function CategoryAdd()
{
	global $txt, $db_prefix, $context, $func;

	// Not now...
	if(empty($_POST['add_category'])) {

		// Just we need the template.
		$context['sub_template'] = 'category_add';
	}
	else {

		// Session check.
		checkSession();

		// Category name can't be empty.
		if (empty($_POST['category_name']))
			fatal_lang_error('error_sp_name_empty', false);

		// A small info array.
		$categoryInfo = array(
			'name' => addslashes($func['htmlspecialchars'](stripslashes($_POST['category_name']), ENT_QUOTES)),
			'picture' => addslashes($func['htmlspecialchars'](stripslashes($_POST['picture_url']), ENT_QUOTES)),
			'publish' => empty($_POST['show_on_index']) ? '0' : '1',
		);

		// Here we go!
		db_query("
			INSERT INTO {$db_prefix}sp_categories
				(name, picture, articles, publish)
			VALUES ('$categoryInfo[name]', '$categoryInfo[picture]', 0, $categoryInfo[publish])", __FILE__, __LINE__);

		// Return back to the category list.
		redirectexit('action=spadmin;area=categories;sa=list');
	}
}

// Handles the category edit issue.
function CategoryEdit()
{
	global $txt, $db_prefix, $context, $func;

	// Time to edit? Noo!
	if(empty($_POST['add_category'])) {

		// Be sure you made it an integer.
		$_REQUEST['category_id'] = (int)$_REQUEST['category_id'];

		// Show you ID.
		if(empty($_REQUEST['category_id']))
			fatal_lang_error('error_sp_id_empty', false);

		// Get the category info. You need in template.
		$context['category_info'] = getCategoryInfo($_REQUEST['category_id']);
		$context['category_info'] = $context['category_info'][0];

		// Call the right sub template.
		$context['sub_template'] = 'category_edit';
	}
	else {

		// Again.
		checkSession();

		// Why empty? :S
		if (empty($_POST['category_name']))
			fatal_lang_error('error_sp_name_empty', false);

		// Array for the db.		
		$categoryInfo = array(
			'name' => addslashes($func['htmlspecialchars'](stripslashes($_POST['category_name']), ENT_QUOTES)),
			'picture' => addslashes($func['htmlspecialchars'](stripslashes($_POST['picture_url']), ENT_QUOTES)),
			'publish' => empty($_POST['show_on_index']) ? '0' : '1',
		);

		// What to change?
		$category_fields = array();
		$category_fields[] = "name = '$categoryInfo[name]'";
		$category_fields[] = "picture = '$categoryInfo[picture]'";
		$category_fields[] = "publish = '$categoryInfo[publish]'";

		// Go on.
		db_query("
			UPDATE {$db_prefix}sp_categories
			SET " . implode(', ', $category_fields) . "
			WHERE ID_CATEGORY = $_POST[category_id]
			LIMIT 1", __FILE__, __LINE__);

		// Take him back to the list.
		redirectexit('action=spadmin;area=categories;sa=list');
	}
}

// Does more than deleting...
function CategoryDelete()
{
	global $db_prefix, $context;

	// Check if the ID is set.
	if(!empty($_REQUEST['category_id'])) {

		// Be sure you made it an integer.
		$_REQUEST['category_id'] = (int) $_REQUEST['category_id'];

		// Do you know which one to delete?
		if(empty($_REQUEST['category_id']))
			fatal_lang_error('error_sp_id_empty', false);

		// Get the category info. You need in template.
		$context['category_info'] = getCategoryInfo($_REQUEST['category_id']);
		$context['category_info'] = $context['category_info'][0];

		// Also get the category list.
		$context['list_categories'] = getCategoryInfo();

		// If we have one, that is itself. Delete it.
		if(count($context['list_categories']) < 2)
			$context['list_categories'] = array();
	}

	if(empty($_REQUEST['category_id']) && empty($_POST['category_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// No need if category has no articles. But articles are executed if there isn't any other category. :P
	if(empty($_POST['delete_category']) && !empty($context['category_info']['articles'])) {

		// Call the right sub template.
		$context['sub_template'] = 'category_delete';
	}
	elseif(!empty($_POST['delete_category'])) {

		// Again.
		checkSession();

		// Are we going to move something?
		if(!empty($_POST['category_move']) && !empty($_POST['category_move_to'])) {

			// We just need an integer.
			$_POST['category_move_to'] = (int) $_POST['category_move_to'];
			
			// These are the lucky ones, move them.
			db_query("
				UPDATE {$db_prefix}sp_articles
				SET ID_CATEGORY = '$_POST[category_move_to]'
				WHERE ID_CATEGORY = '$_POST[category_id]'", __FILE__, __LINE__);
			
			// Fix the article counts.
			fixCategoryArticles();
		}
		else {
	
			// Kill 'em all. (It's not the Metallica album. :P)
			db_query("
				DELETE FROM {$db_prefix}sp_articles
				WHERE ID_CATEGORY = '$_POST[category_id]'", __FILE__, __LINE__);
		}
			
		// Everybody will die one day...
		db_query("
			DELETE FROM {$db_prefix}sp_categories
			WHERE ID_CATEGORY = '$_POST[category_id]'
			LIMIT 1", __FILE__, __LINE__);
	
		// Return to the list.
		redirectexit('action=spadmin;area=categories;sa=list');
	}
	else {

		// Again.
		checkSession('get');

		// Just delete the category.
		db_query("
			DELETE FROM {$db_prefix}sp_categories
			WHERE ID_CATEGORY = '$_REQUEST[category_id]'
			LIMIT 1", __FILE__, __LINE__);

		// Fix the article counts.
		fixCategoryArticles();
			
		// Return to the list.
		redirectexit('action=spadmin;area=categories;sa=list');
	}
}

// A rahter complex one: Article list.
function ArticleList()
{
	global $txt, $db_prefix, $context, $article_request, $scripturl;

	// Call the template.
	$context['sub_template'] = 'article_list';

	// You clicked to the remove button? Naughty boy. :P
	if (!empty($_POST['removeArticles']) && !empty($_POST['remove']) && is_array($_POST['remove']))
	{

		// But can you?
		checkSession();

		// Are they integer?
		foreach ($_POST['remove'] as $index => $articleid)
			$_POST['remove'][(int) $index] = (int) $articleid;

		// Delete 'em all.
		db_query("
			DELETE FROM {$db_prefix}sp_articles
			WHERE ID_ARTICLE IN (" . implode(', ', $_POST['remove']) . ')
			LIMIT ' . count($_POST['remove']), __FILE__, __LINE__);
		
		//Fix the category article counts.
		fixCategoryArticles();
	}

	// How can we sort the list?
	$sort_methods = array(
		'topic' =>  array(
			'down' => 'm.subject ASC',
			'up' => 'm.subject DESC'
		),
		'board' => array(
			'down' => 'b.name ASC',
			'up' => 'b.name DESC'
		),
		'poster' => array(
			'down' => 'm.posterName ASC',
			'up' => 'm.posterName DESC'
		),
		'time' => array(
			'down' => 'm.posterTime ASC',
			'up' => 'm.posterTime DESC'
		),
		'category' => array(
			'down' => 'c.name ASC',
			'up' => 'c.name DESC'
		),
		'approved' => array(
			'down' => 'a.approved ASC',
			'up' => 'a.approved DESC'
		),
	);

	// Columns to show.
	$context['columns'] = array(
		'topic' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnTopic'],
			'sortable' => true
		),
		'board' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnBoard'],
			'sortable' => true
		),
		'poster' => array(
			'width' => '10%',
			'label' => $txt['sp-adminColumnPoster'],
			'sortable' => true
		),
		'time' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnTime'],
			'sortable' => true
		),
		'category' => array(
			'width' => '20%',
			'label' => $txt['sp-adminColumnCategory'],
			'sortable' => true
		),
		'approved' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnApproved'],
			'sortable' => true,
		),
		'actions' => array(
			'width' => '5%',
			'label' => $txt['sp-adminColumnAction'],
			'sortable' => false
		)
	);

	// Default sort is according to the topic.
	if (!isset($_REQUEST['sort']) || !isset($sort_methods[$_REQUEST['sort']]))
		$_REQUEST['sort'] = 'topic';

	// Set the sort links.
	foreach ($context['columns'] as $col => $dummy)
	{
		$context['columns'][$col]['selected'] = $col == $_REQUEST['sort'];
		$context['columns'][$col]['href'] = $scripturl . '?action=spadmin;area=articles;sa=list;sort=' . $col;

		if (!isset($_REQUEST['desc']) && $col == $_REQUEST['sort'])
			$context['columns'][$col]['href'] .= ';desc';

		$context['columns'][$col]['link'] = '<a href="' . $context['columns'][$col]['href'] . '">' . $context['columns'][$col]['label'] . '</a>';
	}

	$context['sort_by'] = $_REQUEST['sort'];
	$context['sort_direction'] = !isset($_REQUEST['desc']) ? 'down' : 'up';

	// Count all the articles.
	$request = db_query("
		SELECT COUNT(*)
		FROM {$db_prefix}sp_articles", __FILE__, __LINE__);
	list ($totalArticles) = mysql_fetch_row($request);
	mysql_free_result($request);

	// Construct the page index. 20 articles per page.
	$context['page_index'] = constructPageIndex($scripturl . '?action=spadmin;area=articles;sa=list;sort=' . $_REQUEST['sort'] . (isset($_REQUEST['desc']) ? ';desc' : ''), $_REQUEST['start'], $totalArticles, 20);
	$context['start'] = $_REQUEST['start'];

	// A *small* query to get article info.
	$article_request = db_query("
		SELECT a.ID_ARTICLE, a.ID_CATEGORY, a.ID_MESSAGE, a.approved, c.name as cname, m.ID_MEMBER, m.posterName,
			m.posterTime,	m.subject, t.ID_TOPIC, t.numReplies, t.numViews, b.ID_BOARD, b.name	as bname, mem.realName		
		FROM {$db_prefix}sp_articles AS a
			INNER JOIN {$db_prefix}sp_categories AS c ON (c.ID_CATEGORY = a.ID_CATEGORY)
			INNER JOIN {$db_prefix}messages AS m ON (m.ID_MSG = a.ID_MESSAGE)
			INNER JOIN {$db_prefix}topics AS t ON (t.ID_FIRST_MSG = a.ID_MESSAGE)
			INNER JOIN {$db_prefix}boards AS b ON (b.ID_BOARD = m.ID_BOARD)
			LEFT JOIN {$db_prefix}members AS mem ON (mem.ID_MEMBER = m.ID_MEMBER)
		ORDER BY " . $sort_methods[$_REQUEST['sort']][$context['sort_direction']] . "
		LIMIT $context[start], 20", __FILE__, __LINE__);

	// Call-back...
	$context['get_article'] = 'getArticleEntry';
}

// Call-back for getting a row of article data.
function getArticleEntry($reset = false)
{
	global $scripturl, $article_request, $txt, $context, $settings;

	if ($article_request == false)
		return false;

	if (!($row = mysql_fetch_assoc($article_request)))
		return false;

	// Build up the array.		
	$output = array(
		'article' => array(
			'id' => $row['ID_ARTICLE'],
			'approved' => $row['approved'],
		),
		'category' => array(
			'id' => $row['ID_CATEGORY'],
			'name' => '<a href="' . $scripturl . '?action=spadmin;area=categories;sa=edit;category_id=' . $row['ID_CATEGORY'] . '">' . $row['cname'] . '</a>',
		),
		'message' => array(
			'id' => $row['ID_MESSAGE'],
			'subject' => $row['subject'],
			'time' => timeformat($row['posterTime'], '%H:%M:%S, %d/%m/%y'),
		),
		'poster' => array(
			'id' => $row['ID_MEMBER'],
			'name' => $row['posterName'],
			'link' => (empty($row['ID_MEMBER']) ? $row['posterName'] : '<a href="' . $scripturl . '?action=profile;u=' . $row['ID_MEMBER'] . '">' . $row['realName'] . '</a>'),
		),
		'topic' => array(
			'id' => $row['ID_TOPIC'],
			'replies' => $row['numReplies'],
			'views' => $row['numViews'],
			'link' => '<a href="' . $scripturl . '?topic=' . $row['ID_TOPIC'] . '.0">' . $row['subject'] . '</a>',
		),
		'board' => array(
			'id' => $row['ID_BOARD'],
			'name' => $row['bname'],
			'link' => '<a href="' . $scripturl . '?board=' . $row['ID_BOARD'] . '.0">' . $row['bname'] . '</a>',
		),
		'edit' => '<a href="' . $scripturl . '?action=spadmin;area=articles;sa=edit;article_id=' . $row['ID_ARTICLE'] . ';sesc=' . $context['session_id'] . '">' . sp_embed_image('modify') . '</a>',
		'delete' => '<a href="' . $scripturl . '?action=spadmin;area=articles;sa=delete;article_id=' . $row['ID_ARTICLE'] . ';sesc=' . $context['session_id'] . '" onclick="return confirm(\''.$txt['sp-articlesDeleteConfirm'].'\');">' . sp_embed_image('delete') . '</a>'
	);

	return $output;
}

// Function for adding articles.
function ArticleAdd()
{
	global $txt, $context, $scripturl, $db_prefix, $modSettings;

	// Are we ready?
	if(empty($_POST['createArticle']) || empty($_POST['articles'])) {

		// List all the categories.
		$context['list_categories'] = getCategoryInfo();

		if(empty($context['list_categories']))
			fatal_error($txt['error_sp_no_category'] . '<br />' . (allowedTo('sp_moderate') ? sprintf($txt['error_sp_no_category_sp_moderator'], $scripturl . '?action=spadmin;area=categories;sa=add') : $txt['error_sp_no_category_normaluser']), false);
			
		// Which board to show?
		if(isset($_REQUEST['targetboard']))
			$_REQUEST['targetboard'] = (int) $_REQUEST['targetboard'];
		else {

			// Find one yourself.
			$request = db_query("
				SELECT ID_BOARD
				FROM {$db_prefix}boards
				ORDER BY ID_BOARD DESC
				LIMIT 1", __FILE__, __LINE__);
			list ($_REQUEST['targetboard']) = mysql_fetch_row($request);
			mysql_free_result($request);
		}
		
		$context['target_board'] = $_REQUEST['targetboard'];

		// Get the total topic count.
		$request = db_query("
			SELECT COUNT(*)
			FROM {$db_prefix}topics as t
				LEFT JOIN {$db_prefix}sp_articles as a ON (a.ID_MESSAGE = t.ID_FIRST_MSG)
			WHERE ID_BOARD = $_REQUEST[targetboard]
				AND IFNULL(a.ID_ARTICLE, 0) = 0", __FILE__, __LINE__);
		list ($topiccount) = mysql_fetch_row($request);
		mysql_free_result($request);

		// Create the page index.
		$context['page_index'] = constructPageIndex($scripturl . '?action=spadmin;area=articles;sa=add;targetboard=' . $_REQUEST['targetboard'] . ';board=' . $_REQUEST['targetboard'] . '.%d', $_REQUEST['start'], $topiccount, $modSettings['defaultMaxTopics'], true);

		// Get some info about the boards and categories.
		$request = db_query("
			SELECT b.ID_BOARD, b.name AS bName, c.name AS cName
			FROM {$db_prefix}boards AS b
				LEFT JOIN {$db_prefix}categories AS c ON (c.ID_CAT = b.ID_CAT)", __FILE__, __LINE__);
		$context['boards'] = array();
		while ($row = mysql_fetch_assoc($request))
			$context['boards'][] = array(
				'id' => $row['ID_BOARD'],
				'name' => $row['bName'],
				'category' => $row['cName']
			);
		mysql_free_result($request);

		// Time to get the topic data.
		$request = db_query("
			SELECT t.ID_TOPIC, m.subject, m.ID_MEMBER, IFNULL(mem.realName, m.posterName) AS posterName, m.ID_MSG
			FROM ({$db_prefix}topics AS t, {$db_prefix}messages AS m)
				LEFT JOIN {$db_prefix}members AS mem ON (mem.ID_MEMBER = m.ID_MEMBER)
				LEFT JOIN {$db_prefix}sp_articles as a ON (a.ID_MESSAGE = t.ID_FIRST_MSG)
			WHERE m.ID_MSG = t.ID_FIRST_MSG
				AND IFNULL(a.ID_ARTICLE, 0) = 0
				AND t.ID_BOARD = $_REQUEST[targetboard]
			ORDER BY " . (!empty($modSettings['enableStickyTopics']) ? 't.isSticky DESC, ' : '') . "t.ID_LAST_MSG DESC
			LIMIT $_REQUEST[start], $modSettings[defaultMaxTopics]", __FILE__, __LINE__);
		$context['topics'] = array();
		while ($row = mysql_fetch_assoc($request))
		{
			censorText($row['subject']);

			$context['topics'][] = array(
				'id' => $row['ID_TOPIC'],
				'msg_id' => $row['ID_MSG'],
				'poster' => array(
					'id' => $row['ID_MEMBER'],
					'name' => $row['posterName'],
					'href' => empty($row['ID_MEMBER']) ? '' : $scripturl . '?action=profile;u=' . $row['ID_MEMBER'],
					'link' => empty($row['ID_MEMBER']) ? $row['posterName'] : '<a href="' . $scripturl . '?action=profile;u=' . $row['ID_MEMBER'] . '" target="_blank">' . $row['posterName'] . '</a>'
				),
				'subject' => $row['subject'],
				'js_subject' => addcslashes(addslashes($row['subject']), '/')
			);
		}
		mysql_free_result($request);

		// Set the page title and sub-template.
		$context['page_title'] = $txt['sp-articlesAdd'];
		$context['sub_template'] = 'article_add';
	}
	else {
	
		// But can you?
		checkSession();

		// Are they integer?
		foreach ($_POST['articles'] as $index => $articleid)
			$_POST['articles'][(int) $index] = (int) $articleid;
			
		// Add all of them.
		foreach($_POST['articles'] as $article) {

			// Set them. They have their own IDs.
			$articleOptions = array(
				'ID_CATEGORY' => !empty($_POST['category']) ? (int) $_POST['category'] : 0,
				'ID_MESSAGE' => $article,
				'approved' => 1,
			);

			// A tricky function.
			createArticle($articleOptions);
		}

		// Time to go back.
		redirectexit('action=spadmin;area=articles;sa=list');
	}
}

// Function for editing an article.
function ArticleEdit()
{
	global $txt, $db_prefix, $context;
	global $func;

	// Seems that we aren't ready.
	if(empty($_POST['add_article'])) {

		// Check it as we just accept integer.
		$_REQUEST['article_id'] = (int)$_REQUEST['article_id'];

		// Do we know the one to be edited?
		if(empty($_REQUEST['article_id']))
			fatal_lang_error('error_sp_id_empty', false);

		// Get the article info.
		$context['article_info'] = getArticleInfo($_REQUEST['article_id']);
		$context['article_info'] = $context['article_info'][0];

		// List all the categories.
		$context['list_categories'] = getCategoryInfo();

		// Call the right template.
		$context['sub_template'] = 'article_edit';
	}
	else {

		// A small array.
		$articleInfo = array(
			'category' => $_POST['category'],
			'approved' => empty($_POST['approved']) ? '0' : '1',
		);

		// Set the fields to change.
		$category_fields = array();
		$category_fields[] = "ID_CATEGORY = '$articleInfo[category]'";
		$category_fields[] = "approved = '$articleInfo[approved]'";

		// Do it please.
		db_query("
			UPDATE {$db_prefix}sp_articles
			SET " . implode(', ', $category_fields) . "
			WHERE ID_ARTICLE = $_POST[article_id]
			LIMIT 1", __FILE__, __LINE__);

		// Fix the article counts.
		fixCategoryArticles();

		// I wanna go back to the list. :)
		redirectexit('action=spadmin;area=articles;sa=list');
	}
}

// Deleting an article...
function ArticleDelete()
{
	global $db_prefix, $context;

	// Check if he can?
	checkSession('get');

	// We just accept integers.
	$_REQUEST['article_id'] = (int)$_REQUEST['article_id'];
	
	// Can't delete without an ID.
	if(empty($_REQUEST['article_id']))
		fatal_lang_error('error_sp_id_empty', false);

	// Life is short... Delete it.
	db_query("
		DELETE FROM {$db_prefix}sp_articles
		WHERE ID_ARTICLE = '$_REQUEST[article_id]'
		LIMIT 1", __FILE__, __LINE__);

	// Fix the article counts.
	fixCategoryArticles();
	
	// Again comes the list.
	redirectexit('action=spadmin;area=articles;sa=list');
}

// Function for changing the state of everything.
function StateChange()
{
	// Check if he can?
	checkSession('get');

	// Make sure ID is an integer.
	if (!empty($_REQUEST['block_id']))
		$id = (int) $_REQUEST['block_id'];
	elseif (!empty($_REQUEST['category_id']))
		$id = (int) $_REQUEST['category_id'];
	elseif (!empty($_REQUEST['article_id']))
		$id = (int) $_REQUEST['article_id'];
	else
		fatal_lang_error('error_sp_id_empty', false);

	// I love these Subs functions. :)
	changeState($_REQUEST['type'], $id);
	
	// Return back to the list where we were.
	if($_REQUEST['type'] == 'block')
	{
		$sides = array(1 => 'left', 2 => 'top', 3 => 'bottom', 4 => 'right');
		$list = !empty($_GET['redirect']) && isset($sides[$_GET['redirect']]) ? $sides[$_GET['redirect']] : 'list';
		
		redirectexit('action=spadmin;area=blocks;sa=' . $list);
	}
	elseif($_REQUEST['type'] == 'category')
		redirectexit('action=spadmin;area=categories;sa=list');
	elseif($_REQUEST['type'] == 'article')
		redirectexit('action=spadmin;area=articles;sa=list');
	else
		redirectexit('action=spadmin');
}

function ColumnChange()
{
	global $db_prefix;

	checkSession('get');

	if (empty($_REQUEST['block_id']))
		fatal_lang_error('error_sp_id_empty', false);
	else
		$id = (int) $_REQUEST['block_id'];

	if (empty($_REQUEST['to']) || !in_array($_REQUEST['to'], array('left', 'right')))
		fatal_lang_error('error_sp_side_wrong', false);
	else
		$to = $_REQUEST['to'];

	$request = db_query("
		SELECT col
		FROM {$db_prefix}sp_blocks
		WHERE ID_BLOCK = $id
		LIMIT 1", __FILE__, __LINE__);
	list ($from) = mysql_fetch_row($request);
	mysql_free_result($request);

	if (empty($from))
		fatal_lang_error('error_sp_block_wrong', false);

	$to = ($to == 'left') ? ($from - 1) : ($from + 1);

	if ($to < 1 || $to > 4)
		fatal_lang_error('error_sp_side_wrong', false);

	db_query("
		UPDATE {$db_prefix}sp_blocks
		SET col = $to, row = 100
		WHERE ID_BLOCK = $id
		LIMIT 1", __FILE__, __LINE__);

	fixColumnRows($from);
	fixColumnRows($to);
	
	$sides = array(1 => 'left', 2 => 'top', 3 => 'bottom', 4 => 'right');
	$list = isset($_GET['redirect']) ? $sides[$to] : 'list';
	
	redirectexit('action=spadmin;area=blocks;sa=' . $list);
}

?>