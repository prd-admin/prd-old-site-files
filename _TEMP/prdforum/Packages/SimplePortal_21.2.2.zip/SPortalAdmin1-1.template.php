<?php
// Version: 2.2.2; SPortalAdmin

function template_general_settings()
{
	global $context, $txt, $settings, $scripturl, $modSettings;

	echo '
	<form action="', $context['post_url'], '" method="post" accept-charset="', $context['character_set'], '">
		<table width="80%" border="0" cellspacing="0" cellpadding="0" class="tborder" align="center">
			<tr><td>
				<table border="0" cellspacing="0" cellpadding="4" width="100%">
					<tr class="titlebg">
						<td colspan="3">', $context['settings_title'], '</td>
					</tr>';

	// Have we got some custom code to insert?
	if (!empty($context['settings_message']))
		echo '
					<tr>
						<td class="windowbg2" colspan="3">', $context['settings_message'], '</td>
					</tr>';

	// Now actually loop through all the variables.
	foreach ($context['config_vars'] as $config_var)
	{
		echo '
					<tr class="windowbg2">';

		if (is_array($config_var))
		{
			// Show the [?] button.
			if ($config_var['help'])
				echo '
						<td class="windowbg2" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=', $config_var['help'], '" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>';
			else
				echo '
						<td class="windowbg2"></td>';

			echo '
						<td valign="top" ', ($config_var['disabled'] ? ' style="color: #777777;"' : ''), '><label for="', $config_var['name'], '">', $config_var['label'], ($config_var['type'] == 'password' ? '<br /><i>' . $txt['admin_confirm_password'] . '</i>' : ''), '</label></td>
						<td class="windowbg2" width="50%">';

			// Show a check box.
			if ($config_var['type'] == 'check')
				echo '
							<input type="hidden" name="', $config_var['name'], '" value="0" /><input type="checkbox"', ($config_var['disabled'] ? ' disabled="disabled"' : ''), ' name="', $config_var['name'], '" id="', $config_var['name'], '" ', ($config_var['value'] ? ' checked="checked"' : ''), ' class="check" />';
			// Escape (via htmlspecialchars.) the text box.
			elseif ($config_var['type'] == 'password')
				echo '
							<input type="password"', ($config_var['disabled'] ? ' disabled="disabled"' : ''), ' name="', $config_var['name'], '[0]"', ($config_var['size'] ? ' size="' . $config_var['size'] . '"' : ''), ' value="*#fakepass#*" onfocus="this.value = \'\'; this.form.', $config_var['name'], '.disabled = false;" /><br />
							<input type="password" disabled="disabled" id="', $config_var['name'], '" name="', $config_var['name'], '[1]"', ($config_var['size'] ? ' size="' . $config_var['size'] . '"' : ''), ' />';
			// Show a selection box.
			elseif ($config_var['type'] == 'select')
			{
				echo '
							<select name="', $config_var['name'], '"', ($config_var['disabled'] ? ' disabled="disabled"' : ''), '>';
				foreach ($config_var['data'] as $option)
					echo '
								<option value="', $option[0], '"', ($option[0] == $config_var['value'] ? ' selected="selected"' : ''), '>', $option[1], '</option>';
				echo '
							</select>';
			}
			// Text area?
			elseif ($config_var['type'] == 'large_text')
			{
				echo '
							<textarea rows="', ($config_var['size'] ? $config_var['size'] : 4), '" cols="30" ', ($config_var['disabled'] ? ' disabled="disabled"' : ''), ' name="', $config_var['name'], '">', $config_var['value'], '</textarea>';
			}
			// Multiple checkboxes?
			elseif (is_array($config_var['type']))
			{

				foreach($config_var['type'] as $name => $title)
				{	
					echo '
							<input type="hidden" name="', $name, '" value="0" /><input type="checkbox" name="', $name, '" id="', $name, '" ', (!empty($modSettings[$name]) ? ' checked="checked"' : ''), ' class="check" />
							', $title, '<br />';
				}
			}
			// Assume it must be a text box.
			else
				echo '
							<input type="text"', ($config_var['disabled'] ? ' disabled="disabled"' : ''), ' name="', $config_var['name'], '" value="', $config_var['value'], '"', ($config_var['size'] ? ' size="' . $config_var['size'] . '"' : ''), ' />';

			echo '
						</td>';
		}
		else
		{
			// Just show a separator.
			if ($config_var == '')
				echo '
							<td colspan="3" class="windowbg2"><hr size="1" width="100%" class="hrcolor" /></td>';
			else
				echo '
							<td colspan="3" class="windowbg2" align="center"><b>' . $config_var . '</b></td>';
		}
		echo '
					</tr>';
	}
	echo '
					<tr>
						<td class="windowbg2" colspan="3" align="center" valign="middle"><input type="submit" value="', $txt[10], '"', (!empty($context['save_disabled']) ? ' disabled="disabled"' : ''), ' /></td>
					</tr>
				</table>
			</td></tr>
		</table>
		<input type="hidden" name="sc" value="', $context['session_id'], '" />
	</form>';
}

// Shhh... You didn't see this!
function template_information()
{
	global $context, $txt;

	if ($context['in_admin'])
	{
		echo '
		<table width="100%" cellpadding="0" cellspacing="0" border="0" style="margin-top: 0.5em;">
			<tr>
				<td valign="top">
					<table width="100%" cellpadding="5" cellspacing="0" border="0" class="tborder">
						<tr>
							<td class="titlebg">
								', $txt['sp-info_live'], '
							</td>
						</tr><tr>
							<td class="windowbg2" valign="top" style="height: 18ex; padding: 0;">
								<div id="spAnnouncements" style="height: 18ex; overflow: auto; padding-right: 1ex;"><div style="margin: 4px; font-size: 0.85em;">', $txt['sp-info_no_live'], '</div></div>
							</td>
						</tr>
					</table>
				</td>
				<td style="width: 1ex;">&nbsp;</td>
				<td valign="top" style="width: 40%;">
					<table width="100%" cellpadding="5" cellspacing="0" border="0" class="tborder" id="spVersionsTable">
						<tr>
							<td class="titlebg">', $txt['sp-info_general'], '</td>
						</tr><tr>
							<td class="windowbg2" valign="top" style="height: 18ex; line-height: 1.5em;">
								<b>', $txt['sp-info_versions'], ':</b><br />
								', $txt['sp-info_your_version'], ':
								<i id="spYourVersion" style="white-space: nowrap;">', $context['sp_version'], '</i><br />
								', $txt['sp-info_current_version'], ':
								<i id="spCurrentVersion" style="white-space: nowrap;">??</i><br />
								<b>', $txt['sp-info_managers'], ':</b>
								', implode(', ', $context['sp_managers']), '
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<script language="JavaScript" type="text/javascript" src="http://www.simpleportal.net/sp/current-version.js"></script>
		<script language="JavaScript" type="text/javascript" src="http://www.simpleportal.net/sp/latest-news.js"></script>
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			function spSetAnnouncements()
			{
				if (typeof(window.spAnnouncements) == "undefined" || typeof(window.spAnnouncements.length) == "undefined")
					return;

				var str = "<div style=\"margin: 4px; font-size: 0.85em;\">";

				for (var i = 0; i < window.spAnnouncements.length; i++)
				{
					str += "\n	<div style=\"padding-bottom: 2px;\"><a hre" + "f=\"" + window.spAnnouncements[i].href + "\">" + window.spAnnouncements[i].subject + "<" + "/a> ', $txt[30], ' " + window.spAnnouncements[i].time + "<" + "/div>";
					str += "\n	<div style=\"padding-left: 2ex; margin-bottom: 1.5ex; border-top: 1px dashed;\">"
					str += "\n		" + window.spAnnouncements[i].message;
					str += "\n	<" + "/div>";
				}

				setInnerHTML(document.getElementById("spAnnouncements"), str + "<" + "/div>");
			}

			function spAnnouncementsFixHeight()
			{
				if (document.getElementById("spVersionsTable").offsetHeight)
					document.getElementById("spAnnouncements").style.height = (document.getElementById("spVersionsTable").offsetHeight - 10) + "px";
			}

			function spCurrentVersion()
			{
				var spVer, yourVer;

				if (typeof(window.spVersion) != "string")
					return;

				spVer = document.getElementById("spCurrentVersion");
				yourVer = document.getElementById("spYourVersion");

				setInnerHTML(spVer, window.spVersion);

				var currentVersion = getInnerHTML(yourVer);
				if (currentVersion != window.spVersion)
					setInnerHTML(yourVer, "<span style=\"color: red;\">" + currentVersion + "<" + "/span>");
			}';

		echo '
			var oldonload;
			if (typeof(window.onload) != "undefined")
				oldonload = window.onload;

			window.onload = function ()
			{
				spSetAnnouncements();
				spCurrentVersion();';

	if ($context['browser']['is_ie'] && !$context['browser']['is_ie4'])
		echo '
				if (typeof(smf_codeFix) != "undefined")
					window.detachEvent("onload", smf_codeFix);
				window.attachEvent("onload",
					function ()
					{
						with (document.all.spVersionsTable)
							style.height = parentNode.offsetHeight;
					}
				);
				if (typeof(smf_codeFix) != "undefined")
					window.attachEvent("onload", smf_codeFix);';

	echo '

				if (oldonload)
					oldonload();
			}
		// ]]></script>';
	}

	echo '
		<table width="100%" cellpadding="5" cellspacing="0" border="0" class="tborder" style="margin-top: 2ex;">
			<tr class="titlebg">
				<td>', $txt['sp-info_title'], '</td>
			</tr><tr>
				<td class="windowbg2" style="padding: 0 10px;"><div style="line-height: 1.5em;">';

	foreach ($context['sp_credits'] as $section)
	{
		if (isset($section['pretext']))
			echo '
					<p>', $section['pretext'], '</p>';

		foreach ($section['groups'] as $group)
		{
			if (empty($group['members']))
				continue;

			echo '
					<div style="margin-top: 1ex;">';

			if (isset($group['title']))
				echo '<strong>', $group['title'], ':</strong> ';

			echo implode(', ', $group['members']), '</div>';
		}

		if (isset($section['posttext']))
			echo '
					<p>', $section['posttext'], '</p>';
	}

	echo '
					<hr />
					<p>Did you find this mod useful? <a href="http://www.simpleportal.net/index.php?action=contribute" target="_blank">Contribute to the project!</a></p>
				</div></td>
			</tr>
		</table>';
}

function template_block_list()
{
	global $context, $settings, $options, $scripturl, $txt;

	echo '
		<table border="0" align="center" cellspacing="1" cellpadding="4" class="bordercolor" width="100%">';

	foreach($context['sides'] as $side) {

		echo '
				<tr class="catbg3">
					<td colspan="4" align="left">
						<a class="sp_float_right" href="', $scripturl, '?action=spadmin;area=blocks;sa=add;col=', $side['id'], '">', sp_embed_image('add', sprintf($txt['sp-blocksCreate'], $side['label'])), '</a>
						<a href="', $scripturl, '?action=helpadmin;help=', $side['help'], '" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>
						<strong>', $side['label'], ' ', $txt['sp-blocksBlocks'], '</strong>
					</td>
				</tr>';

		echo '
				<tr class="titlebg">';
		foreach ($context['columns'] as $column)
		{
				echo '
					<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
						', $column['label'], '
					</th>';
		}
		echo '
				</tr>';

		foreach($context['blocks'][$side['name']] as $block)
		{
			//Yes it's lazy... but it the fastest way to solve it :X
			$block += array(
				'state_icon' => empty($block['state']) ? '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=statechange;' . (empty($context['sp_blocks_single_side_list']) ? '' : 'redirect=' . $block['column'] . ';') . 'block_id=' . $block['id'] . ';type=block;sesc=' . $context['session_id'] . '">' . sp_embed_image('deactive', $txt['sp-blocksActivate']) . '</a>' : '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=statechange;' . (empty($context['sp_blocks_single_side_list']) ? '' : 'redirect=' . $block['column'] . ';') . 'block_id=' . $block['id'] . ';type=block;sesc=' . $context['session_id'] . '">' . sp_embed_image('active', $txt['sp-blocksDeactivate']) . '</a>',
				'edit' => '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=edit;block_id=' . $block['id'] . ';sesc=' . $context['session_id'] . '">' . sp_embed_image('modify') . '</a>',
				'delete' => '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=delete;block_id=' . $block['id'] . ';col=' . $block['column'] . ';sesc=' . $context['session_id'] . '" onclick="return confirm(\''.$txt['sp-deleteblock'].'\');">' . sp_embed_image('delete') . '</a>',
				'moveup' => '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=move;redirect=' . $context['sub_action'] . ';block_id=' . $block['id'] . ';direction=up;sesc=' . $context['session_id'] . '">' . sp_embed_image('up', $txt['sp-blocksMoveUp']) . '</a>',
				'movedown' => '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=move;redirect=' . $context['sub_action'] . ';block_id=' . $block['id'] . ';direction=down;sesc=' . $context['session_id'] . '">' . sp_embed_image('down', $txt['sp-blocksMoveDown']) . '</a>',
				'moveleft' => '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=columnchange;' . (empty($context['sp_blocks_single_side_list']) ? '' : 'redirect;') . 'block_id=' . $block['id'] . ';to=left;sesc=' . $context['session_id'] . '">' . sp_embed_image('left', $txt['sp-blocksMoveLeft']) . '</a>',
				'moveright' => '<a href="' . $scripturl . '?action=spadmin;area=blocks;sa=columnchange;' . (empty($context['sp_blocks_single_side_list']) ? '' : 'redirect;') . 'block_id=' . $block['id'] . ';to=right;sesc=' . $context['session_id'] . '">' . sp_embed_image('right', $txt['sp-blocksMoveRight']) . '</a>'
			);

			echo '
				<tr>
					<td align="left" valign="top" class="windowbg">', $block['label'], '</td>
					<td align="left" valign="top" class="windowbg2">', $txt['sp_function_' . $block['type'] . '_label'], '</td>
					<td align="center" valign="top" class="windowbg2">';

			if ($side['id'] != 1)
				echo $block['moveleft'];

			if($block['row'] != 1)
				echo $block['moveup']; 

			if($block['row'] != count($context['blocks'][$side['name']]))
				echo $block['movedown'];

			if ($side['id'] != 4)
				echo $block['moveright'];

			echo '
					</td>
					<td align="center" valign="top" class="windowbg2">', $block['state_icon'], ' ', $block['edit'], ' ', $block['delete'], '</td>
				</tr>';
		}
	}
	echo '
			<tr class="catbg3">
				<td colspan="4" align="left">
				</td>
			</tr>
		</table>';
}

// Function to show the 'Add or Edit Block' page.
function template_block_edit()
{
	global $context, $settings, $options, $scripturl, $txt, $helptxt, $modSettings;

	if (!empty($context['SPortal']['preview']))
	{
		echo '
<div style="width: ', $context['widths'][$context['SPortal']['block']['column']], '; margin: 0 auto;">';

		template_block($context['SPortal']['block']);

		echo '
</div>';
	}

	echo '<br />
<form action="', $scripturl, '?action=spadmin;area=blocks;sa=edit" method="post" accept-charset="', $context['character_set'], '">
	<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="65%">
		<tr class="catbg">
			<td>
				<a href="', $scripturl, '?action=helpadmin;help=sp-blocks', $context['SPortal']['is_new'] ? 'Edit' : 'Add', '" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
				', $context['SPortal']['is_new'] ? $txt['sp-blocksEdit'] : $txt['sp-blocksAdd'], '
			</td>
		</tr>
		<tr class="windowbg2">
			<td align="center">
					<table border="0" cellspacing="0" cellpadding="4" width="100%">';

	if (empty($modSettings['showleft']) || empty($modSettings['showright']))
	{
		echo '
						<tr class="windowbg3">
							<td colspan="3" style="font-weight: bold; text-align: center;">';

		if (empty($modSettings['showleft']) && empty($modSettings['showright']))
			echo $txt['sp-blocksDisabledBoth'];
		elseif (empty($modSettings['showleft']))
			echo $txt['sp-blocksDisabledLeft'];
		else
			echo $txt['sp-blocksDisabledRight'];

		echo '
							</td>
						</tr>';
	}

	echo
						'<tr>
							<td class="windowbg2" valign="top" width="16">&nbsp;</td>
							<th style="text-align:right;" valign="top">', $txt['sp-adminColumnType'], ':</th>
							<td class="windowbg2">', $context['SPortal']['block']['type_text'], '</td>
						</tr>
						<tr>
							<td class="windowbg2" valign="top" width="16">&nbsp;</td>
							<th style="text-align:right;" valign="top">', $txt['sp-adminColumnName'], ':</th>
							<td class="windowbg2"><input type="text" name="block_name" value="', $context['SPortal']['block']['label'], '" size="30" /></td>
						</tr>
						<tr>
							<td class="windowbg2" valign="top" width="16">&nbsp;</td>
							<th style="text-align:right;" valign="top">', $txt['sp-blocksPermissions'], ':</th>
							<td class="windowbg2">';

	sp_template_inline_permissions();

	echo '
							</td>
						</tr>
						<tr>
							<td class="windowbg2" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-blocksPermissionType" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
							<th style="text-align:right;" valign="top">', $txt['sp-blocksPermissionType'], ':</th>
							<td class="windowbg2">
								<input class="check" type="radio" name="permission_type" value="0"', empty($context['SPortal']['block']['permission_type']) || $context['SPortal']['block']['permission_type'] > 2 ? ' checked="checked"' : '', ' />', $txt['sp-blocksPermissionOne'], '<br />
								<input class="check" type="radio" name="permission_type" value="1"', $context['SPortal']['block']['permission_type'] == 1 ? ' checked="checked"' : '', ' />', $txt['sp-blocksPermissionAll'], '<br />
								<input class="check" type="radio" name="permission_type" value="2"', $context['SPortal']['block']['permission_type'] == 2 ? ' checked="checked"' : '', ' />', $txt['sp-blocksPermissionIgnore'], '<br />
							</td>
						</tr>';

	foreach ($context['SPortal']['block']['options'] as $name => $type)
	{
		if (empty($context['SPortal']['block']['parameters'][$name]))
			$context['SPortal']['block']['parameters'][$name] = '';

		echo '
						<tr>
							<td class="windowbg2" valign="top" width="16">';

		if (!empty($helptxt['sp_param_' . $context['SPortal']['block']['type'] . '_' . $name]))
			echo '
								<a href="', $scripturl, '?action=helpadmin;help=sp_param_', $context['SPortal']['block']['type'] , '_' , $name, '" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>';

		echo '
							</td>
							<th style="text-align:right;" valign="top">', $txt['sp_param_' . $context['SPortal']['block']['type'] . '_' . $name], ':</th>
							<td class="windowbg2">';

		if ($type == 'int')
			echo '
								<input type="text" name="parameters[', $name, ']" value="', $context['SPortal']['block']['parameters'][$name],'" size="7" />';
		elseif ($type == 'text')
			echo '
								<input type="text" name="parameters[', $name, ']" value="', $context['SPortal']['block']['parameters'][$name],'" size="25" />';
		elseif ($type == 'check')
				echo '
							<input type="checkbox" name="parameters[', $name, ']"', !empty($context['SPortal']['block']['parameters'][$name]) ? ' checked="checked"' : '', ' class="check" />';
		elseif ($type == 'select')
		{
				$options = explode('|', $txt['sp_param_' . $context['SPortal']['block']['type'] . '_' . $name . '_options']);

				echo '
							<select name="parameters[', $name, ']">';

				foreach ($options as $key => $option)
					echo '
								<option value="', $key, '"', $context['SPortal']['block']['parameters'][$name] == $key ? ' selected="selected"' : '', '>', $option, '</option>';

				echo '
							</select>';
		}
		elseif ($type == 'textarea')
		{
			echo '
							<textarea name="parameters[', $name, ']" id="', $name, '" cols="60" rows="10">', $context['SPortal']['block']['parameters'][$name], '</textarea>
							<input type="button" value="-" onclick="document.getElementById(\'', $name, '\').rows -= 10" />
							<input type="button" value="+" onclick="document.getElementById(\'', $name, '\').rows += 10" />';
		}

		echo '
							</td>
						</tr>';
	}

	if (empty($context['SPortal']['block']['column']))
		echo '
						<tr>
							<td class="windowbg2" valign="top" width="16">&nbsp;</td>
							<th style="text-align:right;" valign="top">', $txt['sp-blocksColumn'], ':</th>
							<td class="windowbg2">
								<select id="block_column" name="block_column">
									<option value="1">', $txt['sp-positionLeft'], '</option>
									<option value="2">', $txt['sp-positionTop'], '</option>
									<option value="3">', $txt['sp-positionBottom'], '</option>
									<option value="4">', $txt['sp-positionRight'], '</option>
								</select>
							</td>
						</tr>';
	else
		echo '
					<input type="hidden" name="block_column" value="', $context['SPortal']['block']['column'], '" />';

	if (count($context['SPortal']['block']['list_blocks']) > 1)
	{
		echo '
						<tr>
							<td class="windowbg2" valign="top" width="16">&nbsp;</td>
							<th style="text-align:right;" valign="top">', $txt['sp-blocksRow'], ':</th>
							<td class="windowbg2">
								<select id="order" name="placement"', !$context['SPortal']['is_new'] ? ' onchange="this.form.block_row.disabled = this.options[this.selectedIndex].value == \'\';"' : '', '>
									', !$context['SPortal']['is_new'] ? '<option value="nochange">' . $txt['sp-placementUnchanged'] . '</option>' : '', '
									<option value="before">', $txt['sp-placementBefore'], '...</option>
									<option value="after">', $txt['sp-placementAfter'], '...</option>
								</select>
								<select id="block_row" name="block_row"', !$context['SPortal']['is_new'] ? ' disabled="disabled"' : '', '>';

		foreach ($context['SPortal']['block']['list_blocks'] as $block)
			if ($block['id'] != $context['SPortal']['block']['id'])
				echo '
										<option value="', $block['row'], '">', $block['label'], '</option>';

		echo '
								</select>
							</td>
						</tr>';
	}

	if ($context['SPortal']['block']['type'] != 'sp_boardNews')
	{
		echo '
						<tr>
							<td class="windowbg2" valign="top" width="16">&nbsp;</td>
							<th style="text-align:right;" valign="top">', $txt['sp-blocksForce'], ':</th>
							<td class="windowbg2"><input type="checkbox" name="block_force" value="1" id="block_force"', $context['SPortal']['block']['force_view'] ? ' checked="checked"' : '', ' /></td>
						</tr>';
	}

	echo '
						<tr>
							<td class="windowbg2" valign="top" width="16">&nbsp;</td>
							<th style="text-align:right;" valign="top">', $txt['sp-blocksActive'], ':</th>
							<td class="windowbg2"><input type="checkbox" name="block_active" value="1" id="block_active"', $context['SPortal']['block']['state'] ? ' checked="checked"' : '', ' /></td>
						</tr>
						<tr>
							<td colspan="3" align="center"><input type="submit" name="add_block" value="', !$context['SPortal']['is_new'] ? $txt['sp-blocksEdit'] : $txt['sp-blocksAdd'], '" /> <input type="submit" name="preview_block" value="', $txt['sp-blocksPreview'], '" /></td>
						</tr>
					</table>
					<input type="hidden" name="block_type" value="', $context['SPortal']['block']['type'], '" />
					<input type="hidden" name="block_id" value="', $context['SPortal']['block']['id'], '" />
					<input type="hidden" name="sc" value="', $context['session_id'], '" />
			</td>
		</tr>
	</table>';

	if (!empty($modSettings['sp_enableIntegration']))
	{
		echo '
		<br />
		<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="65%">
			<tr class="catbg">
				<td>
					<a href="', $scripturl, '?action=helpadmin;help=sp-blocksDisplayOptions" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
					', $txt['sp-blocksDisplayOptions'], '
				</td>
			</tr>
			<tr class="windowbg2">
				<td align="left">
					<table width="100%">
						<tr>
							<td colspan="2">
								<div style="float: right;">', $txt['sp-blocksAdvancedOptions'], '<input type="checkbox" name="display_advanced" id="display_advanced" onclick="document.getElementById(\'sp_display_advanced\').style.display = this.checked ? \'block\' : \'none\'; document.getElementById(\'display_simple\').disabled = this.checked;" class="check"', empty($context['SPortal']['block']['display_type']) ? '' : ' checked="checked"', ' /></div>
								', $txt['sp-blocksShowBlock'], '
								<select name="display_simple" id="display_simple"', empty($context['SPortal']['block']['display_type']) ? '' : ' disabled="disabled"', '>';

		foreach ($context['simple_actions'] as $action => $label)
			echo '
									<option value="', $action, '"', in_array($action, $context['SPortal']['block']['display']) ? ' selected="selected"' : '', '>', $label, '</option>';

		echo '
								</select>
							</td>
						</tr>
					</table>
					<div id="sp_display_advanced"', empty($context['SPortal']['block']['display_type']) ? ' style="display: none;"' : '', '>
					<div style="padding: 5px;"><a href="javascript:void(0);" onclick="sp_collapseObject(\'actions\')"><img id="sp_collapse_actions" src="', $settings['images_url'], '/expand.gif" alt="*" border="0" /></a>&nbsp;', $txt['sp-blocksSelectActions'], '</div>
					<table width="100%" id="sp_object_actions" style="display: none;">';

		$counter = 1;
		foreach ($context['display_actions'] as $index => $action)
		{
			if ($counter == 1)
				echo '
						<tr>';

			echo '
							<td valign="top" width="50%">
								<input type="checkbox" name="display_actions[]" value="', $index, '"', in_array($index, $context['SPortal']['block']['display']) ? ' checked="checked"' : '', ' />', $action, '
							</td>';

			if ($counter == 2)
			{
				$counter = 0;
				echo '
						</tr>';
			}

			$counter++;
		}

		if (count($context['display_actions']) % 2 != 0)
			echo '
							<td valign="top" width="50%">
								&nbsp;
							</td>
						</tr>';

		echo '
						<tr>
							<td colspan="2" align="right">
								<input type="checkbox" onclick="invertAll(this, this.form, \'display_actions[]\');" /> <em>', $txt[737], '</em>
							</td>
						</tr>
					</table>
					<div style="padding: 5px;"><a href="javascript:void(0);" onclick="sp_collapseObject(\'boards\')"><img id="sp_collapse_boards" src="', $settings['images_url'], '/expand.gif" alt="*" /></a>&nbsp;', $txt['sp-blocksSelectBoards'], '</div>
					<table width="100%" id="sp_object_boards" style="display: none;">';

		$counter = 1;
		foreach ($context['display_boards'] as $index => $board)
		{
			if ($counter == 1)
				echo '
						<tr>';

			echo '
							<td valign="top" width="50%">
								<input type="checkbox" name="display_boards[]" value="', $index, '"', in_array($index, $context['SPortal']['block']['display']) ? ' checked="checked"' : '', ' />', $board, '
							</td>';

			if ($counter == 2)
			{
				$counter = 0;
				echo '
						</tr>';
			}

			$counter++;
		}

		if (count($context['display_boards']) % 2 != 0)
			echo '
							<td valign="top" width="50%">
								&nbsp;
							</td>
						</tr>';

		echo '
						<tr>
							<td colspan="2" align="right">
								<input type="checkbox" onclick="invertAll(this, this.form, \'display_boards[]\');" /> <em>', $txt[737], '</em>
							</td>
						</tr>
					</table>
					<br />
					<a href="', $scripturl, '?action=helpadmin;help=sp-blocksCustomDisplayOptions" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;', $txt['sp_display_custom'], ': <input type="text" name="display_custom" value="', $context['SPortal']['block']['display_custom'], '" />
					<br /><br />
					</div>
					<div style="text-align: center;"><input type="submit" name="add_block" value="', !$context['SPortal']['is_new'] ? $txt['sp-blocksEdit'] : $txt['sp-blocksAdd'], '" /></div>
				</td>
			</tr>
		</table>';
	}

	if ($context['SPortal']['block']['type'] != 'sp_boardNews')
	{
		echo '
		<br />
		<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="65%">
			<tr class="catbg">
				<td>
					<a href="', $scripturl, '?action=helpadmin;help=sp-blocksStyleOptions" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
					', $txt['sp-blocksStyleOptions'], '
				</td>
			</tr>
			<tr class="windowbg2">
				<td align="left">
					<table width="100%">
						<tr>
							<td style="text-align: right;">
								', $txt['sp-blocksTitleDefaultClass'], ':
							</td>
							<td>
								<select name="title_default_class" id="title_default_class">
									<option value="catbg"', $context['SPortal']['block']['style']['title_default_class'] == 'catbg' ? ' selected="selected"' : '', '>catbg</option>
									<option value="catbg2"', $context['SPortal']['block']['style']['title_default_class'] == 'catbg2' ? ' selected="selected"' : '', '>catbg2</option>
									<option value="catbg3"', $context['SPortal']['block']['style']['title_default_class'] == 'catbg3' ? ' selected="selected"' : '', '>catbg3</option>
									<option value="titlebg"', $context['SPortal']['block']['style']['title_default_class'] == 'titlebg' ? ' selected="selected"' : '', '>titlebg</option>
									<option value="titlebg2"', $context['SPortal']['block']['style']['title_default_class'] == 'titlebg2' ? ' selected="selected"' : '', '>titlebg2</option>
								</select>
							</td>
							<td style="text-align: right;">
								', $txt['sp-blocksBodyDefaultClass'], ':
							</td>
							<td>
								<select name="body_default_class" id="body_default_class">
									<option value="windowbg"', $context['SPortal']['block']['style']['body_default_class'] == 'windowbg' ? ' selected="selected"' : '', '>windowbg</option>
									<option value="windowbg2"', $context['SPortal']['block']['style']['body_default_class'] == 'windowbg2' ? ' selected="selected"' : '', '>windowbg2</option>
									<option value="windowbg3"', $context['SPortal']['block']['style']['body_default_class'] == 'windowbg3' ? ' selected="selected"' : '', '>windowbg3</option>
								</select>
							</td>
						</tr>
						<tr>
							<td style="text-align: right;">
								', $txt['sp-blocksTitleCustomClass'], ':
							</td>
							<td>
								<input type="text" name="title_custom_class" id="title_custom_class" value="', $context['SPortal']['block']['style']['title_custom_class'], '" />
							</td>
							<td style="text-align: right;">
								', $txt['sp-blocksBodyCustomClass'], ':
							</td>
							<td>
								<input type="text" name="body_custom_class" id="body_custom_class" value="', $context['SPortal']['block']['style']['body_custom_class'], '" />
							</td>
						</tr>
						<tr>
							<td style="text-align: right;">
								', $txt['sp-blocksTitleCustomStyle'], ':
							</td>
							<td>
								<input type="text" name="title_custom_style" id="title_custom_style" value="', $context['SPortal']['block']['style']['title_custom_style'], '" />
							</td>
							<td style="text-align: right;">
								', $txt['sp-blocksBodyCustomStyle'], ':
							</td>
							<td>
								<input type="text" name="body_custom_style" id="body_custom_style" value="', $context['SPortal']['block']['style']['body_custom_style'], '" />
							</td>
						</tr>
						<tr>
							<td style="text-align: right;">
								', $txt['sp-blocksNoTitle'], ':
							</td>
							<td>
								<input type="checkbox" name="no_title" id="no_title" value="1"', !empty($context['SPortal']['block']['style']['no_title']) ? ' checked="checked"' : '', ' onclick="document.getElementById(\'title_default_class\').disabled = document.getElementById(\'title_custom_class\').disabled = document.getElementById(\'title_custom_style\').disabled = this.checked;" />
							</td>
							<td style="text-align: right;">
								', $txt['sp-blocksNoBody'], ':
							</td>
							<td>
								<input type="checkbox" name="no_body" id="no_body" value="1"', !empty($context['SPortal']['block']['style']['no_body']) ? ' checked="checked"' : '', ' onclick="document.getElementById(\'body_default_class\').disabled = this.checked;" />
							</td>
						</tr>
					</table>
					<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
						document.getElementById("title_default_class").disabled = document.getElementById("no_title").checked;
						document.getElementById("title_custom_class").disabled = document.getElementById("no_title").checked;
						document.getElementById("title_custom_style").disabled = document.getElementById("no_title").checked;
						document.getElementById("body_default_class").disabled = document.getElementById("no_body").checked;
					// ]]></script>
					<div style="text-align: center;"><input type="submit" name="add_block" value="', !$context['SPortal']['is_new'] ? $txt['sp-blocksEdit'] : $txt['sp-blocksAdd'], '" /></div>
				</td>
			</tr>
		</table>';
	}

	echo '
	</form>';
}

function template_block_select_type()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '<br />
	<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="80%">
		<tr class="catbg">
			<td>
				<a href="', $scripturl, '?action=helpadmin;help=sp-blocksSelectType" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
				', $txt['sp-blocksSelectType'], '
			</td>
		</tr>
		<tr class="windowbg">
			<td align="center">
				<form action="', $scripturl, '?action=spadmin;area=blocks;sa=add" method="post" accept-charset="', $context['character_set'], '">
					<table cellpadding="4">';

	$row_check = 0;
	$function_count = 0;

	foreach ($context['SPortal']['block_types'] as $type)
	{
		$function_count = $function_count + 1;

		if ($row_check == 0)
			echo '
						<tr>';

		echo '
							<td width="190px" valign="top" class="windowbg2">
								<input type="radio" name="selected_type[]" value="', $type['function'], '" class="check" />&nbsp;&nbsp;<label for="', $type['function'], '"><b>', $txt['sp_function_' . $type['function'] . '_label'], '</b></label><br /><br />
								<span class="smalltext">', $txt['sp_function_' . $type['function'] . '_desc'], '<br /><br /></span>
							</td>';

		$row_check = $row_check + 1;
		if ($row_check == 3)
		{
			echo '
						</tr>';
			$row_check = 0;
		}
	}

	if ($function_count % 3 != 0)
	{
		$empty_cells = 3 - ($function_count % 3);
		while($empty_cells > 0)
		{
			echo '
							<td class="windowbg2">
								&nbsp;
							</td>';
			$empty_cells = $empty_cells - 1;
		}

			echo '
						</tr>';
	}

	echo '
						<tr>
							<td colspan="3" align="center"><input type="submit" name="select_type" value="', $txt['sp-blocksSelectType'], '" /></td>
						</tr>
					</table>';

	if (!empty($context['SPortal']['block']['column']))
		echo '
					<input type="hidden" name="block_column" value="', $context['SPortal']['block']['column'], '" />';

	echo '
					<input type="hidden" name="sc" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
	</table>';
}

function template_category_list()
{
	global $context, $settings, $options, $scripturl, $txt;

	echo '
		<table border="0" align="center" cellspacing="1" cellpadding="4" class="bordercolor" width="100%">
			<tr class="catbg3">
				<td colspan="5" align="left">
					<div style="float: left;">
						<a href="', $scripturl, '?action=helpadmin;help=sp-categoriesCategories" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>
						<b>', $txt['sp-categoriesCategories'], '</b>
					</div>
				</td>
			</tr>';

	echo '
			<tr class="titlebg">';
	foreach ($context['columns'] as $column)
	{
			echo '
				<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
					', $column['label'], '
				</th>';
	}
	echo '
			</tr>';

	foreach($context['categories'] as $category)
	{
		echo '
			<tr>
				<td align="center" valign="top" class="windowbg">', !empty($category['picture']['href']) ? $category['picture']['image'] : '', '</td>
				<td align="left" valign="middle" class="windowbg2">', $category['name'], '</td>
				<td align="center" valign="middle" class="windowbg2">', $category['articles'], '</td>
				<td align="center" valign="middle" class="windowbg2"><a href="', $scripturl, '?action=spadmin;area=categories;sa=statechange;category_id=', $category['id'], ';type=category;sesc=', $context['session_id'], '">', empty($category['publish']) ? sp_embed_image('deactive', $txt['sp-stateNo']) : sp_embed_image('active', $txt['sp-stateYes']), '</a></td>
				<td align="center" valign="middle" class="windowbg2"><a href="', $scripturl, '?action=spadmin;area=categories;sa=edit;category_id=', $category['id'], ';sesc=', $context['session_id'], '">', sp_embed_image('modify'), '</a> <a href="', $scripturl, '?action=spadmin;area=categories;sa=delete;category_id=', $category['id'], ';sesc=', $context['session_id'], '"', (empty($category['articles']) ? ' onclick="return confirm(\'' . $txt['sp-categoriesDeleteConfirm'] . '\');"' : ''), '>', sp_embed_image('delete'), '</a></td>
			</tr>';
	}
	echo '
			<tr class="catbg3">
				<td colspan="5" align="left">
				</td>
			</tr>
		</table>';
}

function template_category_add()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '<br />
	<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="60%">
		<tr class="catbg">
			<td>
				<a href="', $scripturl, '?action=helpadmin;help=sp-categoriesAdd" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
				', $txt['sp-categoriesAdd'], '
			</td>
		</tr>
		<tr class="windowbg2">
			<td align="center">
				<form action="', $scripturl, '?action=spadmin;area=categories;sa=add" method="post" accept-charset="', $context['character_set'], '">
					<table cellpadding="4">
						<tr>
							<th align="right">', $txt['sp-categoriesName'], ':</th>
							<td align="left"><input type="text" name="category_name" value="" size="20" /></td>
						</tr><tr>
							<th align="right">', $txt['sp-categoriesPicture'], ':</th>
							<td align="left"><input type="text" name="picture_url" value="" size="30" /></td>
						</tr><tr>
							<th align="right">', $txt['sp-categoriesPublish'], ':</th>
							<td align="left"><input type="checkbox" name="show_on_index" value="1" id="show_on_index" checked="checked" /></td>
						</tr><tr>
							<td colspan="2" align="right"><input type="submit" name="add_category" value="', $txt['sp-categoriesAdd'], '" /></td>
						</tr>
					</table>
				<input type="hidden" name="sc" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
	</table>';
}

function template_category_edit()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '<br />
	<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="60%">
		<tr class="catbg">
			<td>
				<a href="', $scripturl, '?action=helpadmin;help=sp-categoriesEdit" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
				', $txt['sp-categoriesEdit'], '
			</td>
		</tr>
		<tr class="windowbg2">
			<td align="center">
				<form action="', $scripturl, '?action=spadmin;area=categories;sa=edit" method="post" accept-charset="', $context['character_set'], '">
					<table cellpadding="4">
						<tr>
							<th align="right">', $txt['sp-categoriesName'], ':</th>
							<td align="left"><input type="text" name="category_name" value="', $context['category_info']['name'], '" size="20" /></td>
						</tr><tr>
							<th align="right">', $txt['sp-categoriesPicture'], ':</th>
							<td align="left"><input type="text" name="picture_url" value="', $context['category_info']['picture']['href'], '" size="30" /></td>
						</tr><tr>
							<th align="right">', $txt['sp-categoriesPublish'], ':</th>
							<td align="left"><input type="checkbox" name="show_on_index" value="1" id="show_on_index"', !empty($context['category_info']['publish']) ? ' checked="checked"' : '', ' /></td>
						</tr><tr>
							<td colspan="2" align="right"><input type="submit" name="add_category" value="', $txt['sp-categoriesEdit'], '" /></td>
						</tr>
					</table>
				<input type="hidden" name="category_id" value="', $context['category_info']['id'], '" />
				<input type="hidden" name="sc" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
	</table>';
}

function template_category_delete()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '<br />
	<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="60%">
		<tr class="catbg">
			<td>
				<a href="', $scripturl, '?action=helpadmin;help=sp-categoriesDelete" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
				', $txt['sp-categoriesDelete'], '
			</td>
		</tr>
		<tr class="windowbg2">
			<td align="center">
				<form action="', $scripturl, '?action=spadmin;area=categories;sa=delete" method="post" accept-charset="', $context['character_set'], '">
					<table cellpadding="4">
						<tr>
							<td colspan="2" align="center">';
							printf($txt['sp-categoriesDeleteCount'], $context['category_info']['articles']);
	echo '<br />', !empty($context['list_categories']) ? $txt['sp-categoriesDeleteOption1'] : $txt['sp-categoriesDeleteOption2'], '</td>
						</tr>';
	if(!empty($context['list_categories'])) {
		echo '
						<tr>
							<th align="right">', $txt['sp-categoriesMove'], ':</th>
							<td align="left"><input type="checkbox" name="category_move" value="1" id="category_move" checked="checked" /></td>
						</tr>
						<tr>
							<th align="right">', $txt['sp-categoriesMoveTo'], ':</th>
							<td align="left"><select id="category_move_to" name="category_move_to">';
								foreach($context['list_categories'] as $category) {
									if($category['id'] != $context['category_info']['id'])
										echo '
										<option value="' . $category['id'] . '">' . $category['name'] . '</option>';
								}
								echo '
								</select></td>
						</tr>';
	}
	echo '
						<tr>
							<td colspan="2" align="center"><input type="submit" name="delete_category" value="', $txt['sp-categoriesDelete'], '" /></td>
						</tr>
					</table>
				<input type="hidden" name="category_id" value="', $context['category_info']['id'], '" />
				<input type="hidden" name="sc" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
	</table>';
}

function template_article_list()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '
	<form action="', $scripturl, '?action=spadmin;area=articles;sa=list" method="post" accept-charset="', $context['character_set'], '" onsubmit="return confirm(\'', $txt['sp-articlesConfirm'], '\');">
		<table border="0" align="center" cellspacing="1" cellpadding="4" class="bordercolor" width="100%">
			<tr class="catbg3">
				<td colspan="8"><b>', $txt[139], ':</b> ', $context['page_index'], '</td>
			</tr><tr class="titlebg">';
	foreach ($context['columns'] as $column)
	{
		if ($column['selected'])
			echo '
				<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
					<a href="', $column['href'], '">', $column['label'], '&nbsp;<img src="', $settings['images_url'], '/sort_', $context['sort_direction'], '.gif" alt="" /></a>
				</th>';
		elseif ($column['sortable'])
			echo '
				<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
					', $column['link'], '
				</th>';
		else
			echo '
				<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
					', $column['label'], '
				</th>';
	}
	echo '
				<th><input type="checkbox" class="check" onclick="invertAll(this, this.form);" /></th>
			</tr>';

	while ($article = $context['get_article']())
	{
		echo '
			<tr>
				<td align="left" valign="top" class="windowbg">', $article['topic']['link'], '</td>
				<td align="left" valign="top" class="windowbg">', $article['board']['link'], '</td>
				<td align="center" valign="top" class="windowbg">', $article['poster']['link'], '</td>
				<td align="center" valign="top" class="windowbg">', $article['message']['time'], '</td>
				<td align="left" valign="top" class="windowbg">', $article['category']['name'], '</td>
				<td align="center" valign="top" class="windowbg"><a href="' . $scripturl . '?action=spadmin;area=articles;sa=statechange;article_id=' . $article['article']['id'] . ';type=article;sesc=' . $context['session_id'] . '" title="', empty($article['article']['approved']) ? $txt['sp-blocksActivate'] : $txt['sp-blocksDeactivate'], '">', empty($article['article']['approved']) ? $txt['sp-stateNo'] : $txt['sp-stateYes'], '</a></td>
				<td align="center" valign="top" class="windowbg">', $article['edit'], $article['delete'], '</td>
				<td align="center" valign="top" class="windowbg2"><input type="checkbox" name="remove[]" value="', $article['article']['id'], '" class="check" /></td>
			</tr>';
	}
	echo '
			<tr class="catbg3">
				<td colspan="8" align="left">
					<div style="float: left;">
						<b>', $txt[139], ':</b> ', $context['page_index'], '
					</div>
					<div style="float: right;">
						<input type="submit" name="removeArticles" value="', $txt['sp-articlesRemove'], '" />
					</div>
				</td>
			</tr>
		</table>
		<input type="hidden" name="sc" value="', $context['session_id'], '" />
	</form>';
}

function template_article_add()
{
	global $context, $settings, $options, $txt, $scripturl;

	echo '
		<form action="' . $scripturl . '?action=spadmin;area=articles;sa=add;targetboard=' . $context['target_board'] . '" method="post" accept-charset="', $context['character_set'], '">
			<table border="0" width="540" cellspacing="1" class="bordercolor" cellpadding="4" align="center">
				<tr class="catbg3">
					<td>
						<a href="', $scripturl, '?action=helpadmin;help=sp-articlesAdd" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
						', $txt['sp-articlesAdd'], '
					</td>
				</tr>
				<tr>
					<td class="windowbg" align="center">
						<table border="0" width="100%">
							<tr>
								<td class="windowbg" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-articlesCategory" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
								<td style="text-align:right;">', $txt['sp-articlesCategory'], ':</td>
								<td width="50%">
									<select id="category" name="category">';
												foreach($context['list_categories'] as $category) {
													echo '
													<option value="' . $category['id'] . '">' . $category['name'] . '</option>';
												}
												echo '
									</select>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td colspan="3" class="titlebg">
						<table cellpadding="0" cellspacing="0" border="0"><tr>
							<td><b>' . $txt[139] . ':</b> ' . $context['page_index'] . '</td>
						</tr></table>
					</td>
				</tr>
				<tr>
					<td class="windowbg" valign="middle" align="center">
						<table border="0" width="100%">
							<tr>';

	if (!empty($context['boards']) && count($context['boards']) > 1)
	{
		echo '
								<td class="windowbg" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-articlesBoards" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
								<td align="right"><br /><b>', $txt['smf82'], ':</b></td>
								<td align="left" width="50%">
									<br />
									<select name="targetboard" onchange="this.form.submit();">';
		foreach ($context['boards'] as $board)
			echo '
										<option value="', $board['id'], '"', $board['id'] == $context['target_board'] ? ' selected="selected"' : '', '>', $board['category'], ' - ', $board['name'], '</option>';
		echo '
									</select><noscript><input type="submit" value="', $txt['sp-articlesAdd'], '" /></noscript>
								</td>
								<td class="windowbg" valign="top" width="16"></td>';
	}

	echo '
							</tr><tr>
								<td class="windowbg" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-articlesTopics" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
								<td align="right" valign="top"><br /><b>', $txt[64], ':</b></td>
								<td align="left" style="white-space: nowrap;" width="50%">
									<br />
									<table>';

	foreach ($context['topics'] as $topic)
		echo '
										<tr>
											<td align="center" valign="top" class="windowbg">
												<input type="checkbox" name="articles[]" value="', $topic['msg_id'], '" class="check" />
											</td>
											<td valign="middle" style="white-space: nowrap;">
												<a href="' . $scripturl . '?topic=' . $topic['id'] . '.0" target="_blank">' . $topic['subject'] . '</a> ' . $txt[109] . ' ' . $topic['poster']['link'] . '
											</td>
										</tr>';
	echo '
									</table>
								</td>
								<td class="windowbg" valign="top" width="16"></td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td colspan="2" class="windowbg2" align="center">
						<input type="submit" name="createArticle" value="', $txt['sp-articlesAdd'], '" />
						<input type="hidden" name="sc" value="', $context['session_id'], '" />
					</td>
				</tr>
				<tr>
					<td colspan="2" class="titlebg">
						<table cellpadding="0" cellspacing="0" border="0"><tr>
							<td><b>' . $txt[139] . ':</b> ' . $context['page_index'] . '</td>
						</tr></table>
					</td>
				</tr>
			</table>
		</form>';
}

function template_article_edit()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '<br />
	<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="60%">
		<tr class="catbg">
			<td>
				<a href="', $scripturl, '?action=helpadmin;help=sp-articlesEdit" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a>&nbsp;
				', $txt['sp-articlesEdit'], '
			</td>
		</tr>
		<tr class="windowbg2">
			<td align="center">
				<form action="', $scripturl, '?action=spadmin;area=articles;sa=edit" method="post" accept-charset="', $context['character_set'], '">
					<table border="0" cellspacing="0" cellpadding="4" width="100%">
						<tr>
							<td class="windowbg2" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-articlesCategory" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
							<th style="text-align:right;" valign="top">', $txt['sp-articlesCategory'], ':</th>
							<td class="windowbg2" width="50%"">
								<select id="category" name="category">';
								foreach($context['list_categories'] as $category) {
									echo '
									<option value="' . $category['id'] . '"' . ($context['article_info']['category']['id'] == $category['id'] ? ' selected="selected"' : '') . ' >' . $category['name'] . '</option>';
								}
								echo '
								</select>
							</td>
						</tr>
						<tr>
							<td class="windowbg2" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-articlesApproved" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
							<th style="text-align:right;" valign="top">', $txt['sp-articlesApproved'], ':</th>
							<td class="windowbg2" width="50%"">
								<input type="checkbox" name="approved" value="1" id="approved"', !empty($context['article_info']['article']['approved']) ? ' checked="checked"' : '', ' />
							</td>
						</tr>
						<tr>
							<td colspan="3" align="center"><input type="submit" name="add_article" value="', $txt['sp-articlesEdit'], '" /></td>
						</tr>
					</table>
				<input type="hidden" name="article_id" value="', $context['article_info']['article']['id'], '" />
				<input type="hidden" name="sc" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
	</table>';
}

function sp_template_inline_permissions()
{
	global $context, $settings, $options, $txt;

	echo '
		<fieldset id="permissions">
			<legend><a href="javascript:void(0);" onclick="document.getElementById(\'permissions\').style.display = \'none\';document.getElementById(\'permissions_link\').style.display = \'block\'; return false;">', $txt['avatar_select_permission'], '</a></legend>';
		echo '
			<table width="100%" border="0">';
	foreach ($context['member_groups'] as $group)
	{
		echo '
				<tr>
					<td align="center"><input type="checkbox" name="member_groups[]" value="', $group['id'], '"', !empty($group['checked']) ? ' checked="checked"' : '', ' class="check" /></td>
					<td><span', $group['is_post_group'] ? ' style="border-bottom: 1px dotted;" title="' . $txt['mboards_groups_post_group'] . '"' : '', '>', $group['name'], '</span></td>
				</tr>';
	}
	echo '
				<tr>
					<td colspan="2">
						<i>', $txt[737], '</i> <input type="checkbox" onclick="invertAll(this, this.form, \'member_groups[]\');" />
					</td>
				</tr>
			</table>
		</fieldset>

		<a href="javascript:void(0);" onclick="document.getElementById(\'permissions\').style.display = \'block\'; document.getElementById(\'permissions_link\').style.display = \'none\'; return false;" id="permissions_link" style="display: none;">[ ', $txt['avatar_select_permission'], ' ]</a>

		<script language="JavaScript" type="text/javascript"><!-- // --><' . '!' . '[' . 'CDATA' . '[
			document.getElementById("permissions").style.display = "none";
			document.getElementById("permissions_link").style.display = "";
		// ' . ']' . ']' . '></script>';
}

?>