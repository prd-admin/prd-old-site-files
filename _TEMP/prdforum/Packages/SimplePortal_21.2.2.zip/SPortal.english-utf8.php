<?php
// Version: 2.2.2; SPortal
// Last Revision: Sunday, March 29th by Jade (Alundra), who was sick at the time, so don't pick on her for mistakes :P. 
// I dub this the boring file, because on average there's about 3 words a string.

// General strings
$txt['sp-forum'] = 'Forum';
$txt['sp-portal'] = 'Portal';
$txt['sp-adminTitle'] = 'SimplePortal Admin';
$txt['sp-adminCatTitle'] = 'SimplePortal';
$txt['sp-make_article'] = 'Add as Article';
$txt['sp-dot'] = 'Dot';
$txt['sp-arrow'] = 'Arrow';

// Block labels
$txt['sp_function_sp_userInfo_label'] = 'Member Information';
$txt['sp_function_sp_latestMember_label'] = 'Latest Member';
$txt['sp_function_sp_whosOnline_label'] = 'Who\'s Online';
$txt['sp_function_sp_showPoll_label'] = 'Poll';
$txt['sp_function_sp_boardStats_label'] = 'Board Statistics';
$txt['sp_function_sp_quickSearch_label'] = 'Quick Search';
$txt['sp_function_sp_topPoster_label'] = 'Top Poster';
$txt['sp_function_sp_topBoards_label'] = 'Top Boards';
$txt['sp_function_sp_topTopics_label'] = 'Top Topics';
$txt['sp_function_sp_recent_label'] = 'Compact Recent';
$txt['sp_function_sp_recentPosts_label'] = 'Recent Posts';
$txt['sp_function_sp_recentTopics_label'] = 'Recent Topics';
$txt['sp_function_sp_boardNews_label'] = 'Board News';
$txt['sp_function_sp_news_label'] = 'Forum News';
$txt['sp_function_sp_smfShop_label'] = 'SMF Shop';
$txt['sp_function_sp_smfArcade_label'] = 'SMF Arcade';
$txt['sp_function_sp_smfGallery_label'] = 'SMF Gallery';
$txt['sp_function_sp_bbc_label'] = 'Custom BBC';
$txt['sp_function_sp_html_label'] = 'Custom HTML';
$txt['sp_function_sp_php_label'] = 'Custom PHP';
$txt['sp_function_sp_attachmentImage_label'] = 'Recent Image Attachments';
$txt['sp_function_sp_attachmentRecent_label'] = 'Recent Attachments';
$txt['sp_function_sp_mgallery_label'] = 'Media Gallery';
$txt['sp_function_sp_calendar_label'] = 'Calendar';
$txt['sp_function_sp_calendarInformation_label'] = 'Calendar Information';
$txt['sp_function_sp_rssFeed_label'] = 'RSS Feed';
$txt['sp_function_sp_theme_select_label'] = 'Theme Selection';
$txt['sp_function_sp_staff_label'] = 'Staff List';
$txt['sp_function_sp_articles_label'] = 'Articles';
$txt['sp_function_sp_gallery_label'] = 'Gallery';
$txt['sp_function_sp_arcade_label'] = 'Arcade';
$txt['sp_function_sp_shop_label'] = 'Shop';
$txt['sp_function_sp_blog_label'] = 'Blog';
$txt['sp_function_sp_menu_label'] = 'Forum Menu';
$txt['sp_function_unknown_label'] = 'Unknown Block Type';

// Block descriptions
$txt['sp_function_sp_latestMember_desc'] = 'Displays the latest member and their avatar.';
$txt['sp_function_sp_userInfo_desc'] = 'Displays member information if the viewer is logged in, and a login box if the viewer is a guest.';
$txt['sp_function_sp_whosOnline_desc'] = 'Displays the who\'s online list.';
$txt['sp_function_sp_showPoll_desc'] = 'Displays a poll with voting options if the viewer can vote, or the results if the viewer is unable to vote.';
$txt['sp_function_sp_boardStats_desc'] = 'Displays some statistical information about the forum.';
$txt['sp_function_sp_quickSearch_desc'] = 'Displays a simple quick search form.';
$txt['sp_function_sp_topPoster_desc'] = 'Displays the top posters with their post count and avatars.';
$txt['sp_function_sp_topBoards_desc'] = 'Displays a list of boards according to their activity.';
$txt['sp_function_sp_topTopics_desc'] = 'Displays a list topics according to their activity.';
$txt['sp_function_sp_recent_desc'] = 'Displays a compact list of the forums recent posts or topics, enabling the list to be used in a side block.';
$txt['sp_function_sp_recentPosts_desc'] = 'Displays a list of the forums recent posts.';
$txt['sp_function_sp_recentTopics_desc'] = 'Displays a list of the forums recent topics.';
$txt['sp_function_sp_boardNews_desc'] = 'Displays a list of posts from a selected board.';
$txt['sp_function_sp_news_desc'] = 'Displays a random news line.';
$txt['sp_function_sp_smfShop_desc'] = 'Displays a list of recently purchased items.';
$txt['sp_function_sp_smfArcade_desc'] = 'Displays a list of the top players and the last winner.';
$txt['sp_function_sp_smfGallery_desc'] = 'Displays either the last image added to the gallery or a random image.';
$txt['sp_function_sp_attachmentImage_desc'] = 'Displays a list of recently attached images.';
$txt['sp_function_sp_attachmentRecent_desc'] = 'Displays a list of recent attachments.';
$txt['sp_function_sp_calendar_desc'] = 'Displays a full month calendar with all events.';
$txt['sp_function_sp_calendarInformation_desc'] = 'Displays calendar information such as birthdays, events and holidays.';
$txt['sp_function_sp_mgallery_desc'] = 'Displays a list of recent items from the Media Gallery.';
$txt['sp_function_sp_rssFeed_desc'] = 'Displays an RSS Feed.';
$txt['sp_function_sp_theme_select_desc'] = 'Displays a list of available themes and allows members to select one.';
$txt['sp_function_sp_staff_desc'] = 'Displays list of forum staff with their position and avatar.';
$txt['sp_function_sp_articles_desc'] = 'Displays recent or random articles.';
$txt['sp_function_sp_gallery_desc'] = 'Displays a list of recent gallery items.';
$txt['sp_function_sp_arcade_desc'] = 'Displays various statistics from the arcade if an arcade mod is installed.';
$txt['sp_function_sp_shop_desc'] = 'Displays the richest members or various items from the shop if a shop mod is installed.';
$txt['sp_function_sp_blog_desc'] = 'Displays various information from the forum blog.';
$txt['sp_function_sp_menu_desc'] = 'Displays a vertical forum menu.';
$txt['sp_function_sp_bbc_desc'] = 'A custom block where BBC content can be added.';
$txt['sp_function_sp_html_desc'] = 'A custom block where HTML content can be added.';
$txt['sp_function_sp_php_desc'] = 'A custom block where PHP content can be added.';

// Block parameters
$txt['sp_param_sp_latestMember_limit'] = 'Members to Show';
$txt['sp_param_sp_boardStats_averages'] = 'Show Averages';
$txt['sp_param_sp_topPoster_limit'] = 'Top Posters to Display';
$txt['sp_param_sp_topPoster_type'] = 'Display';
$txt['sp_param_sp_recent_limit'] = 'Recent Posts or Topics to Display';
$txt['sp_param_sp_recent_type'] = 'Display';
$txt['sp_param_sp_recentPosts_limit'] = 'Recent Posts to Display';
$txt['sp_param_sp_recentTopics_limit'] = 'Recent Topics to Display';
$txt['sp_param_sp_topTopics_type'] = 'Sorting Type';
$txt['sp_param_sp_topTopics_limit'] = 'Topics to Display';
$txt['sp_param_sp_topBoards_limit'] = 'Boards to Display';
$txt['sp_param_sp_showPoll_topic'] = 'Topic ID';
$txt['sp_param_sp_showPoll_type'] = 'Type';
$txt['sp_param_sp_boardNews_board'] = 'Board ID';
$txt['sp_param_sp_boardNews_limit'] = 'Topics to Display';
$txt['sp_param_sp_boardNews_start'] = 'Starting Post ID';
$txt['sp_param_sp_boardNews_length'] = 'Maximum Characters';
$txt['sp_param_sp_boardNews_avatar'] = 'Display Avatars';
$txt['sp_param_sp_boardNews_per_page'] = 'Posts Per Page';
$txt['sp_param_sp_attachmentImage_limit'] = 'Images to Display';
$txt['sp_param_sp_attachmentImage_direction'] = 'List Direction';
$txt['sp_param_sp_attachmentRecent_limit'] = 'Attachments to Display';
$txt['sp_param_sp_calendar_events'] = 'Show Events';
$txt['sp_param_sp_calendar_birthdays'] = 'Show Birthdays';
$txt['sp_param_sp_calendar_holidays'] = 'Show Holidays';
$txt['sp_param_sp_calendarInformation_events'] = 'Show Events';
$txt['sp_param_sp_calendarInformation_future'] = 'Events in Future';
$txt['sp_param_sp_calendarInformation_birthdays'] = 'Show Birthdays';
$txt['sp_param_sp_calendarInformation_holidays'] = 'Show Holidays';
$txt['sp_param_sp_rssFeed_url'] = 'Feed URL';
$txt['sp_param_sp_rssFeed_titles_only'] = 'Titles Only';
$txt['sp_param_sp_rssFeed_count'] = 'Items to Show';
$txt['sp_param_sp_rssFeed_limit'] = 'Character Limit';
$txt['sp_param_sp_staff_lmod'] = 'Disable Local Moderators';
$txt['sp_param_sp_articles_limit'] = 'Articles to Display';
$txt['sp_param_sp_articles_type'] = 'Display Type';
$txt['sp_param_sp_articles_image'] = 'Image';
$txt['sp_param_sp_gallery_limit'] = 'Items to Display';
$txt['sp_param_sp_gallery_type'] = 'Display';
$txt['sp_param_sp_gallery_direction'] = 'List Direction';
$txt['sp_param_sp_arcade_limit'] = 'Items to display';
$txt['sp_param_sp_arcade_type'] = 'Display';
$txt['sp_param_sp_shop_style'] = 'Display';
$txt['sp_param_sp_shop_limit'] = 'Items to display';
$txt['sp_param_sp_shop_type'] = 'Money type';
$txt['sp_param_sp_shop_sort'] = 'Item type';
$txt['sp_param_sp_blog_limit'] = 'Items to Display';
$txt['sp_param_sp_blog_type'] = 'Item Type';
$txt['sp_param_sp_blog_sort'] = 'Display';
$txt['sp_param_sp_html_content'] = 'Custom HTML';
$txt['sp_param_sp_bbc_content'] = 'Custom BBC';
$txt['sp_param_sp_php_content'] = 'Custom PHP';

// Parameter options
$txt['sp_param_sp_topPoster_type_options'] = 'All Time|Today|This Week|This Month';
$txt['sp_param_sp_recent_type_options'] = 'Posts|Topics';
$txt['sp_param_sp_topTopics_type_options'] = 'Replies|Views';
$txt['sp_param_sp_showPoll_type_options'] = 'Normal|Recent|Random';
$txt['sp_param_sp_attachmentImage_direction_options'] = 'Vertical|Horizontal';
$txt['sp_param_sp_articles_type_options'] = 'Latest|Random';
$txt['sp_param_sp_articles_image_options'] = 'None|Poster Avatar|Category Image';
$txt['sp_param_sp_gallery_type_options'] = 'Latest|Random';
$txt['sp_param_sp_gallery_direction_options'] = 'Vertical|Horizontal';
$txt['sp_param_sp_arcade_type_options'] = 'Most Played|Best Players|Longest Champ';
$txt['sp_param_sp_shop_style_options'] = 'Members|Items';
$txt['sp_param_sp_shop_type_options'] = 'Total|Pocket|Bank';
$txt['sp_param_sp_shop_sort_options'] = 'Recent|Random';
$txt['sp_param_sp_blog_type_options'] = 'Articles|Blogs';
$txt['sp_param_sp_blog_sort_options'] = 'Latest|Random';

// Block specific strings
$txt['sp-usertmessage'] = 'Total Messages';
$txt['sp-usernmessage'] = 'New Messages';
$txt['sp-articlesComments'] = 'Comments';
$txt['sp-articlesViews'] = 'Views';
$txt['sp-articlesPages'] = 'Pages';
$txt['sp-downloadsCount'] = 'Downloads'; 
$txt['sp-downloadsPoster'] = 'Posted by';
$txt['sp_calendar_noEventsFound'] = 'Sorry! There are no calendar events available at the moment.';
$txt['sp_calendar_events'] = 'Today Events';
$txt['sp_calendar_upcomingEvents'] = 'Upcoming Events';
$txt['sp_calendar_holidays'] = 'Holidays';
$txt['sp_calendar_birthdays'] = 'Birthdays';
$txt['sp-pollViewTopic'] = 'View Topic';
$txt['sp-read_more'] = 'Read More';
$txt['sp-downloadsSize'] = 'Size'; 
$txt['sp-average_posts'] = 'Average Posts';
$txt['sp-average_topics'] = 'Average Topics';
$txt['sp-average_members'] = 'Average Members';
$txt['sp-average_online'] = 'Average Online';
$txt['sp-online_today'] = 'Online Today';
$txt['sp-theme_change'] = 'Change';
$txt['sp-theme_permanent'] = 'Permanently';
$txt['sp-game_plays'] = 'Plays';
$txt['sp-game_rating'] = 'Rating';
$txt['sp-games'] = 'games';
$txt['sp-champ_duration'] = 'Duration';

// Error messages
$txt['error_sp_no_message_id'] = 'Invalid message ID.';
$txt['error_sp_article_exists'] = 'This article already exists.';
$txt['error_sp_cannot_add_article'] = 'You don\'t have permission to add an article.';
$txt['error_sp_name_empty'] = 'The name field was left empty.';
$txt['error_sp_no_category'] = 'Sorry, articles require categories to be published! Please create a category for articles.';
$txt['error_sp_no_category_normaluser'] = 'Sorry, articles require categories to be published! Please ask an administrator to create a category for articles.';
$txt['error_sp_no_category_sp_moderator'] = 'A new category can be created <a href="%s">here</a>.';
$txt['error_sp_side_wrong'] = 'Wrong side selected.';
$txt['error_sp_block_wrong'] = 'Wrong block selected.';
$txt['error_sp_php_syntax'] = 'Syntax error in block code. Please check the code.';
$txt['error_sp_php_database'] = 'Database error in block code. Please check the code.';
$txt['error_sp_no_posts_found'] = 'No posts were found.';
$txt['error_sp_no_members_found'] = 'No members were found.';
$txt['error_sp_no_gallery_found'] = 'There are no gallery mods installed.';
$txt['error_sp_no_pictures_found'] = 'There are no pictures in the gallery.';
$txt['error_sp_no_boards_found'] = 'This forum does not have any boards.';
$txt['error_sp_no_topics_found'] = 'This forum does not have any topics.';
$txt['error_sp_no_attachments_found'] = 'No attachments were found.';
$txt['error_sp_no_polls_found'] = 'No polls were found.';
$txt['error_sp_invalid_feed'] = 'Invalid feed.';
$txt['error_sp_no_online'] = 'There aren\'t any users online.';
$txt['error_sp_no_items_day'] = 'No calendar events were found.';
$txt['error_sp_no_blog_found'] = 'There are no blog mods installed.';
$txt['error_sp_no_blogs_found'] = 'No blogs were found.';
$txt['error_sp_no_articles_found'] = 'There are no articles to display.';
$txt['error_sp_no_shop_found'] = 'There are no shop mods installed.';
$txt['error_sp_no_arcade_found'] = 'There are no arcade mods installed.';
$txt['error_sp_no_stats_found'] = 'No statistics found.';

// Permissions
$txt['permissiongroup_sp'] = 'SimplePortal';
$txt['permissiongroup_simple_sp'] = 'SimplePortal';
$txt['permissionname_sp_moderate'] = 'Moderate portal';
$txt['permissionhelp_sp_moderate'] = 'This permission allows users to access the SimplePortal administration panel.';
$txt['permissionname_sp_add_article'] = 'Can add article';
$txt['permissionhelp_sp_add_article'] = 'This permission allows users to add articles.';
$txt['permissionname_sp_auto_article_approval'] = 'Automatic article approval';
$txt['permissionhelp_sp_auto_article_approval'] = 'This permission allows users to add articles without requiring approval.';

?>