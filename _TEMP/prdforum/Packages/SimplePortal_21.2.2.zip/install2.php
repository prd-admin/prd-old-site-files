<?php
/**********************************************************************************
* install2.php                                                                    *
***********************************************************************************
* SimplePortal                                                                    *
* SMF Modification Project Founded by [SiNaN] (sinan@simplemachines.org)          *
* =============================================================================== *
* Software Version:           SimplePortal 2.2.2                                  *
* Software by:                SimplePortal Team (http://www.simpleportal.net)     *
* Copyright 2008-2009 by:     SimplePortal Team (http://www.simpleportal.net)     *
* Support, News, Updates at:  http://www.simpleportal.net                         *
***********************************************************************************
* This program is free software; you may redistribute it and/or modify it under   *
* the terms of the provided license as published by Simple Machines LLC.          *
*                                                                                 *
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
*                                                                                 *
* See the "license.txt" file for details of the Simple Machines license.          *
* The latest version can always be found at http://www.simplemachines.org.        *
**********************************************************************************/

// Handle running this file by using SSI.php
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')) 
{
	$_GET['debug'] = 'Blue Dream!';
	require_once(dirname(__FILE__) . '/SSI.php');
}
// Hmm... no SSI.php and no SMF?
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

global $smcFunc, $db_prefix, $modSettings, $sourcedir, $settings;

// Make sure that we have the package database functions.
if (!array_key_exists('db_add_column', $smcFunc))
	db_extend('packages');
	
// Load all tables.
$tables = array(
	'sp_articles' => array(
		'columns' => array(
			array(
				'name' => 'id_article',
				'type' => 'int',
				'size' => '10',
				'auto' => true,
			),
			array(
				'name' => 'id_category',
				'type' => 'int',
				'size' => '10',
				'default' => 0,
			),
			array(
				'name' => 'id_message',
				'type' => 'int',
				'size' => '10',
				'default' => 0,
			),
			array(
				'name' => 'approved',
				'type' => 'tinyint',
				'size' => '2',
			),
		),
		'indexes' => array(
			array(
				'type' => 'primary',
				'columns' => array('id_article'),
			),
		),
	),
	'sp_blocks' => array(
		'columns' => array(
			array(
				'name' => 'id_block',
				'type' => 'int',
				'size' => '10',
				'auto' => true,
			),
			array(
				'name' => 'label',
				'type' => 'tinytext',
			),
			array(
				'name' => 'type',
				'type' => 'text',
			),
			array(
				'name' => 'col',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 0,
			),
			array(
				'name' => 'row',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 0,
			),
			array(
				'name' => 'state',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 1,
			),
			array(
				'name' => 'allowed_groups',
				'type' => 'text',
			),
			array(
				'name' => 'force_view',
				'type' => 'tinyint',
				'size' => '2',
				'default' => 0,
			),
			array(
				'name' => 'permission_type',
				'type' => 'tinyint',
				'size' => '2',
				'default' => 0,
			),
			array(
				'name' => 'display',
				'type' => 'text',
			),
			array(
				'name' => 'display_custom',
				'type' => 'text',
			),
			array(
				'name' => 'style',
				'type' => 'text',
			),
		),
		'indexes' => array(
			array(
				'type' => 'primary',
				'columns' => array('id_block'),
			),
		),
	),
	'sp_categories' => array(
		'columns' => array(
			array(
				'name' => 'id_category',
				'type' => 'int',
				'size' => '10',
				'auto' => true,
			),
			array(
				'name' => 'name',
				'type' => 'tinytext',
			),
			array(
				'name' => 'picture',
				'type' => 'tinytext',
			),
			array(
				'name' => 'articles',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 0,
			),
			array(
				'name' => 'publish',
				'type' => 'tinyint',
				'size' => '1',
				'default' => 0,
			),
		),
		'indexes' => array(
			array(
				'type' => 'primary',
				'columns' => array('id_category'),
			),
		),
	),
	'sp_functions' => array(
		'columns' => array(
			array(
				'name' => 'id_function',
				'type' => 'tinyint',
				'size' => '4',
				'auto' => true,
			),
			array(
				'name' => 'function_order',
				'type' => 'tinyint',
				'size' => '4',
			),
			array(
				'name' => 'name',
				'type' => 'tinytext',
			),
			array(
				'name' => 'parameter',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 0,
			),
		),
		'indexes' => array(
			array(
				'type' => 'primary',
				'columns' => array('id_function'),
			),
		),
	),
	'sp_parameters' => array(
		'columns' => array(
			array(
				'name' => 'id_block',
				'type' => 'int',
				'size' => '10',
			),
			array(
				'name' => 'variable',
				'type' => 'varchar',
				'size' => 255,
			),
			array(
				'name' => 'value',
				'type' => 'text',
			),
		),
		'indexes' => array(
			array(
				'type' => 'primary',
				'columns' => array('id_block', 'variable')
			),
			array(
				'type' => 'key',
				'columns' => array('variable')
			),
		),
	),
);

$deprecated_fields = array(
	'sp_articles' => array(
	),
	'sp_blocks' => array(
		'content',
		'parameters',
	),
	'sp_categories' => array(
	),
	'sp_functions' => array(
	),
	'sp_parameters' => array(
	),
);

// We always need a fresh functions table.
$smcFunc['db_query']('', '
	DROP TABLE IF EXISTS {db_prefix}sp_functions',
	array(
	)
);

$current_tables = $smcFunc['db_list_tables'](false, '%sp%');
$real_prefix = preg_match('~^(`?)(.+?)\\1\\.(.*?)$~', $db_prefix, $match) === 1 ? $match[3] : $db_prefix;
$is_utf8 = !empty($modSettings['global_character_set']) && $modSettings['global_character_set'] === 'UTF-8';
$info = '<ul>';

// Loop through each table and do what needed.
foreach ($tables as $table => $data)
{
	if (in_array($real_prefix . $table, $current_tables))
	{
		$info .= '
	<li>"' . $table . '" table exists, updating table structure.
		<ul>';

		if ($is_utf8)
		{
			$smcFunc['db_query']('', '
				ALTER TABLE {db_prefix}{raw:table}
				CONVERT TO CHARACTER SET utf8',
				array(
					'table' => $table,
				)
			);
		}

		foreach ($data['columns'] as $column)
		{
			$smcFunc['db_add_column']($table, $column);

			if ($is_utf8 && in_array($column['type'], array('text', 'tinytext')))
			{
				$smcFunc['db_query']('', '
					ALTER TABLE {db_prefix}{raw:table}
					CHANGE {raw:name} {raw:name} {raw:type} CHARACTER SET utf8 COLLATE utf8_general_ci',
					array(
						'table' => $table,
						'name' => $column['name'],
						'type' => $column['type'],
					)
				);
			}
		}

		$info .= '
			<li>Table columns updated.</li>';

		foreach ($data['indexes'] as $index)
			$smcFunc['db_add_index']($table, $index, array(), 'ignore');

		$info .= '
			<li>Table indexes updated.</li>
		</ul>
	</li>';
	}
	else
	{
		$smcFunc['db_create_table']($table, $data['columns'], $data['indexes'], array(), 'ignore');

		if ($is_utf8)
		{
			$smcFunc['db_query']('', '
				ALTER TABLE {db_prefix}{raw:table}
				CONVERT TO CHARACTER SET utf8',
				array(
					'table' => $table,
				)
			);

			foreach ($date['columns'] as $column)
			{
				if (!in_array($column['type'], array('text', 'tinytext')))
					continue;

				$smcFunc['db_query']('', '
					ALTER TABLE {db_prefix}{raw:table}
					CHANGE {raw:name} {raw:name} {raw:type} CHARACTER SET utf8 COLLATE utf8_general_ci',
					array(
						'table' => $table,
						'name' => $column['name'],
						'type' => $column['type'],
					)
				);
			}
		}

		$info .= '<li>"' . $table . '" table created.</li>';
	}
}

// Insert current functions.
$smcFunc['db_insert']('ignore',
	'{db_prefix}sp_functions',
	array(
		'id_function' => 'int',
		'function_order' => 'int',
		'name' => 'string',
		'parameter' => 'int'
	),
	array(
		array(1, 1, 'sp_userInfo', 0),
		array(2, 2, 'sp_latestMember', 1),
		array(3, 3, 'sp_whosOnline', 0),
		array(4, 11, 'sp_showPoll', 2),
		array(5, 4, 'sp_boardStats', 1),
		array(6, 13, 'sp_quickSearch', 0),
		array(7, 5, 'sp_topPoster', 2),	
		array(8, 10, 'sp_topBoards', 1),
		array(9, 9, 'sp_topTopics', 2),
		array(10, 7, 'sp_recentPosts', 1),
		array(11, 8, 'sp_recentTopics', 1),
		array(12, 12, 'sp_boardNews', 6),
		array(13, 14, 'sp_news', 0),
		array(17, 99, 'sp_html', 0),
		array(18, 100, 'sp_php', 0),
		array(19, 98, 'sp_bbc', 0),
		array(20, 15, 'sp_attachmentImage', 2),
		array(21, 16, 'sp_attachmentRecent', 1),
		array(23, 6, 'sp_recent', 2),
		array(24, 18, 'sp_calendarInformation', 4),
		array(25, 19, 'sp_rssFeed', 4),
		array(26, 23, 'sp_gallery', 3),
		array(27, 17, 'sp_calendar', 3),
		array(28, 27, 'sp_menu', 0),
		array(29, 20, 'sp_theme_select', 0),
		array(30, 21, 'sp_staff', 0),
		array(31, 26, 'sp_blog', 3),
		array(32, 22, 'sp_articles', 3),
		array(33, 24, 'sp_arcade', 2),
		array(34, 25, 'sp_shop', 2),
	),
	array('id_function')
);

$info .= '
	<li>"sp_functions" table data inserted.</li>';

$result = $smcFunc['db_query']('','
	SELECT id_block
	FROM {db_prefix}sp_blocks
	LIMIT 1',
	array(
	)
);
list ($has_block) = $smcFunc['db_fetch_row']($result);
$smcFunc['db_free_result']($result);

if (empty($has_block))
{
	foreach ($deprecated_fields as $table => $fields)
		foreach ($fields as $field)
			$smcFunc['db_remove_column']($table, $field);

	$welcome_text = '<h2 style="text-align: center;">Welcome to SimplePortal!</h2>
<p>SimplePortal is one of several portal mods for Simple Machines Forum (SMF). Although always developing, SimplePortal is produced with the user in mind first. User feedback is the number one method of growth for SimplePortal, and our users are always finding ways for SimplePortal to grow. SimplePortal stays competative with other portal software by adding numerous user-requested features such as articles, block types and the ability to completely customize the portal page.</p>
<p>All this and SimplePortal has remained Simple! SimplePortal is built for simplicity and ease of use; ensuring the average forum administrator can install SimplePortal, configure a few settings, and show off the brand new portal to the users in minutes. Confusing menus, undesired pre-loaded blocks and settings that cannot be found are all avoided as much as possible. Because when it comes down to it, SimplePortal is YOUR portal, and should reflect your taste as much as possible.</p>
<p><strong>Ultimate Simplicity</strong>
<br />
The simplest portal you can ever think of... You only need a few clicks to install it through Package Manager. A few more to create your own blocks and articles. Your portal is ready to go within a couple of minutes, and simple to customise to reflect YOU.</p>
<p><strong>Install Friendly</strong>
<br />
With the ingenius design of install and update packages, SimplePortal is incredibly install and update friendly. You will never need any manual changes even on a heavily modified forum.</p>
<p><strong>Incredible Theme Support</strong>
<br />
The simple but powerful structure of SimplePortal brings you wide-range theme support too. You can use SimplePortal with all SMF themes by just adding a button for it.</p>
<p><strong>Professional Support</strong>
<br />
SimplePortal offers high quality professional support with its own well known support team.</p>';

	$current_groups = array(-1, 0);

	$request = $smcFunc['db_query']('', '
		SELECT id_group
		FROM {db_prefix}membergroups
		WHERE id_group != 1',
		array(
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($request))
		$current_groups[] = $row['id_group'];
	$smcFunc['db_free_result']($request);

	$current_groups = implode(',', $current_groups);

	$default_blocks = array(
		'user_info' => array(
			'label' => 'User Info',
			'type' => 'sp_userInfo',
			'col' => 1,
			'row' => 1,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'whos_online' => array(
			'label' => 'Who&#039;s Online',
			'type' => 'sp_whosOnline',
			'col' => 1,
			'row' => 2,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'board_stats' => array(
			'label' => 'Board Stats',
			'type' => 'sp_boardStats',
			'col' => 1,
			'row' => 3,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'theme_select' => array(
			'label' => 'Theme Select',
			'type' => 'sp_theme_select',
			'col' => 1,
			'row' => 4,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'search' => array(
			'label' => 'Search',
			'type' => 'sp_quickSearch',
			'col' => 1,
			'row' => 5,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'news' => array(
			'label' => 'News',
			'type' => 'sp_news',
			'col' => 2,
			'row' => 1,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => 'title_default_class~|title_custom_class~|title_custom_style~|body_default_class~windowbg|body_custom_class~|body_custom_style~|no_title~1|no_body~',
		),
		'welcome' => array(
			'label' => 'Welcome',
			'type' => 'sp_html',
			'col' => 2,
			'row' => 2,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => 'title_default_class~|title_custom_class~|title_custom_style~|body_default_class~windowbg|body_custom_class~|body_custom_style~|no_title~1|no_body~',
		),
		'board_news' => array(
			'label' => 'Board News',
			'type' => 'sp_boardNews',
			'col' => 2,
			'row' => 3,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'recent_topics' => array(
			'label' => 'Recent Topics',
			'type' => 'sp_recentTopics',
			'col' => 3,
			'row' => 1,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'top_poster' => array(
			'label' => 'Top Poster',
			'type' => 'sp_topPoster',
			'col' => 4,
			'row' => 1,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'recent_posts' => array(
			'label' => 'Recent Posts',
			'type' => 'sp_recent',
			'col' => 4,
			'row' => 2,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'staff' => array(
			'label' => 'Forum Staff',
			'type' => 'sp_staff',
			'col' => 4,
			'row' => 3,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'calendar' => array(
			'label' => 'Calendar',
			'type' => 'sp_calendar',
			'col' => 4,
			'row' => 4,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
		'top_boards' => array(
			'label' => 'Top Boards',
			'type' => 'sp_topBoards',
			'col' => 4,
			'row' => 5,
			'allowed_groups' => $current_groups,
			'display' => '',
			'display_custom' => '',
			'style' => '',
		),
	);

	$smcFunc['db_insert']('ignore',
		'{db_prefix}sp_blocks',
		array(
			'label' => 'text',
			'type' => 'text',
			'col' => 'int',
			'row' => 'int',
			'allowed_groups' => 'text',
			'display' => 'text',
			'display_custom' => 'text',
			'style' => 'text',
		),
		$default_blocks,
		array('id_block')
	);

	$request = $smcFunc['db_query']('', '
		SELECT id_block, type
		FROM {db_prefix}sp_blocks
		WHERE type IN ({array_string:types})
		LIMIT 3',
		array(
			'types' => array('sp_html', 'sp_boardNews', 'sp_calendar'),
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($request))
		$block_ids[$row['type']] = $row['id_block'];
	$smcFunc['db_free_result']($request);

	$default_parameters = array(
		array(
			'id_block' => $block_ids['sp_html'],
			'variable' => 'content',
			'value' => htmlspecialchars($welcome_text),
		),
		array(
			'id_block' => $block_ids['sp_boardNews'],
			'variable' => 'avatar',
			'value' => 1,
		),
		array(
			'id_block' => $block_ids['sp_boardNews'],
			'variable' => 'per_page',
			'value' => 3,
		),
		array(
			'id_block' => $block_ids['sp_calendar'],
			'variable' => 'events',
			'value' => 1,
		),
		array(
			'id_block' => $block_ids['sp_calendar'],
			'variable' => 'birthdays',
			'value' => 1,
		),
		array(
			'id_block' => $block_ids['sp_calendar'],
			'variable' => 'holidays',
			'value' => 1,
		),
	);

	$smcFunc['db_insert']('replace',
		'{db_prefix}sp_parameters',
		array(
			'id_block' => 'int',
			'variable' => 'text',
			'value' => 'text',
		),
		$default_parameters,
		array()
	);

	$info .= '
	<li>Default blocks created.</li>';
}
elseif (empty($modSettings['sp_version']) || $modSettings['sp_version'] < '2.2')
{
	$block_updates = array(
		array(
			'old' => 'sp_smfGallery',
			'new' => 'sp_gallery'
		),
		array(
			'old' => 'sp_mgallery',
			'new' => 'sp_gallery'
		),
	);

	foreach ($block_updates as $type)
		$smcFunc['db_query']('', '
			UPDATE {db_prefix}sp_blocks
			SET type = {string:new}
			WHERE type = {string:old}',
			$type
		);

	require_once($sourcedir . '/SPortal2.php');
	$old_parameters = array();

	$request = $smcFunc['db_query']('', '
		SELECT id_block, type, content, parameters
		FROM {db_prefix}sp_blocks',
		array(
		)
	);
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		if (in_array($row['type'], array('sp_bbc', 'sp_html', 'sp_php')))
		{
			$old_parameters[] = array(
				'id_block' => $row['id_block'],
				'variable' => 'content',
				'value' => $row['content'],
			);
		}
		elseif (function_exists($row['type']))
		{
			$type_parameters = $row['type'](array(), 0, true);

			if (empty($row['parameters']) || empty($type_parameters))
				continue;

			$row['parameters'] = explode(',', $row['parameters']);

			foreach ($type_parameters as $variable => $value)
			{
				$old = current($row['parameters']);
				next($row['parameters']);

				if (empty($old))
					continue;

				$old_parameters[] = array(
					'id_block' => $row['id_block'],
					'variable' => $variable,
					'value' => $old,
				);
			}
		}
		else
			continue;
	}
	$smcFunc['db_free_result']($request);

	if (!empty($old_parameters))
	{
		$smcFunc['db_insert']('replace',
			'{db_prefix}sp_parameters',
			array(
				'id_block' => 'int',
				'variable' => 'text',
				'value' => 'text',
			),
			$old_parameters,
			array()
		);
	}

	foreach ($deprecated_fields as $table => $fields)
		foreach ($fields as $field)
			$smcFunc['db_remove_column']($table, $field);

	$info .= '
	<li>Block types and parameters updated.</li>';
}
else
	foreach ($deprecated_fields as $table => $fields)
		foreach ($fields as $field)
			$smcFunc['db_remove_column']($table, $field);

// Let's setup some standard settings.
$defaults = array(
	'sp_portal_mode' => 1,
	'sp_disableForumRedirect' => 1,
	'showleft' => 1,
	'showright' => 1,
	'leftwidth' => 200,
	'rightwidth' => 200,
	'sp_enableIntegration' => 1,
	'sp_adminIntegrationHide' => 1,
);

$updates = array(
	'sp_version' => '2.2',
	'sp_smf_version' => '2',
);

foreach ($defaults as $index => $value)
	if (!isset($modSettings[$index]))
		$updates[$index] = $value;

updateSettings($updates);

$info .= '
	<li>Default settings inserted.</li>';

$info .= '</ul>';

// Show them a nice message.
if (SMF == 'SSI')
{
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"', $context['right_to_left'] ? ' dir="rtl"' : '', '>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=', $context['character_set'], '" />
	<title>SimplePortal &bull; Database Tool</title>
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/style.css?rc1" />
	<meta name="robots" content="noindex" />
	<style type="text/css">
		body, html
		{
			height: 100%;
			overflow: auto;
			padding: 0;
		}
		body
		{
			font-size: 14px;
			text-align: center;
		}
		ul
		{
			padding-left: 3em;
			line-height: 1.5em;
		}
		ul li, li
		{
			list-style: disc;
		}
		h1
		{
			padding-left: 5px;
		}
		#page
		{
			width: 600px;
			border: 1px solid #000000;
			padding: 1px;
			margin: 0 auto;
			text-align: left;
			line-height: 28px;
			clear: left;
		}
		#info
		{
			padding-left: 20px;
			border: 1px solid #DDDDDD;
			margin-left: 10px;
			margin-right: 10px;
		}
		#distance
		{
			float: left;
			height: 50%;
			margin-top: -200px;
			width: 1px;
		}
		#copy
		{
			font-size: x-small;
			text-align: center;
		}
	</style>
</head>
<body>
<div id="distance"></div>
<div id="page" class="windowbg2">
	<h1 class="catbg">SimplePortal &bull; Database Tool</h1>
	<p id="info" class="windowbg">This tool will prepare your database to work with SimplePortal. It will also fix database issues related to SimplePortal, if there are any.</p>
	', $info, '
	<p id="copy">SimplePortal &copy; 2008-2009</p>
</div>
</body>
</html>';
}

?>