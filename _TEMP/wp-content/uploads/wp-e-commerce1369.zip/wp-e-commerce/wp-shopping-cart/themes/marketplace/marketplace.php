<?php
if(get_option('wpsc_selected_theme') == 'marketplace') {
	function wpsc_grid_title_and_price(&$product) {
		$output .= "<div class='grid_price'>";
		if ($soldout) {
			$output .= "<span class='soldoutgrid'>Sold out</span>";
		} else {
			if($product['special']==1) {
				$output .= nzshpcrt_currency_display(($product['price'] - $product['special_price']), $product['notax'],false,$product['id']) . "\n\r";
			} else {
				$output .= nzshpcrt_currency_display($product['price'], $product['notax']) . "\n\r";
			}
		}
		$output .= "</div>";
		$output .= "<div class='grid_prodcut_title'><a href='".wpsc_product_url($product['id'])."'>".stripslashes($product['name'])."</a></div>";
	
		return $output;
	}
	
	
	function wpsc_theme_html($product) {
		$siteurl = get_option('siteurl');
		$wpsc_theme['html'] ="<input type='image' src='".WPSC_URL."/themes/marketplace/images/atc.gif' id='product_".$product['id']."_submit_button' class='wpsc_buy_button' name='Buy' value='".TXT_WPSC_ADDTOCART."'  />";
		return $wpsc_theme;
	}
}
?>