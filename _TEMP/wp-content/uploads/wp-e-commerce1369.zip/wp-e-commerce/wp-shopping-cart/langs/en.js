if(tinyMCE.addToLang) {
	tinyMCE.addToLang('',{
	insert_ecom_title : 'Insert e-Commerce category',
	lang_dd_code_desc : 'Add an e-Commerce category list of your product'
	});
}

if(tinyMCE.addI18n) {
	tinyMCE.addI18n('en.ecom',{
	insert_ecom_title : 'Insert e-Commerce category',
	lang_dd_code_desc : 'Add an e-Commerce category list of your product'
	});
}
