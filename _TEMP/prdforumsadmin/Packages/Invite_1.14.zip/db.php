<?php

if (!defined('SMF'))
	die('Hacking attempt...');

db_query("CREATE TABLE IF NOT EXISTS {$db_prefix}invites (
  ID_INVITE mediumint(8) unsigned NOT NULL auto_increment,
  ID_MEMBER mediumint(8) unsigned NOT NULL default '0',
  ID_REGISTRATION mediumint(8) unsigned NOT NULL default '0',
  inviteTime int(10) unsigned NOT NULL default '0',
  inviteKey varchar(64) NOT NULL default '',
  PRIMARY KEY  (ID_INVITE),
  KEY ID_MEMBER (ID_MEMBER),
  KEY inviteTime (inviteTime),
  KEY inviteKey (inviteKey)
)", __FILE__, __LINE__);



$request = db_query("
	SHOW COLUMNS
	FROM {$db_prefix}invites
	", __FILE__, __LINE__);

$columns = array();
while ($row = mysql_fetch_assoc($request))
	$columns[] = $row['Field'];

if (!in_array('inviteEmail', $columns))
	db_query("ALTER TABLE {$db_prefix}invites ADD inviteEmail TINYTEXT NOT NULL", __FILE__, __LINE__);

?>