<?php
if (!defined('SMF'))
	die('Hacking attempt...');

// Returns the invite key if it's valid, and a fatal error or false if not.  Called from Register() and Register2() in Register.php
function validateInviteKey($invite_key, $fatal = false)
{
	global $db_prefix, $modSettings;

	if (empty($invite_key) || !preg_match('~^([0-9a-f]){40}$~', $invite_key))
	{
		if ($fatal)
			fatal_lang_error('registration_invite_only', false);
		else
			return false;
	}
	else
	{
		$request = db_query("
			SELECT inviteTime, inviteKey
			FROM {$db_prefix}invites
			WHERE inviteKey = '$invite_key'
				AND ID_REGISTRATION = 0
			LIMIT 1", __FILE__, __LINE__);

		$row = mysql_fetch_assoc($request);
		mysql_free_result($request);

		if ($row)
		{
			// Is it expired?
			if (!empty($modSettings['invite_expire']) && $modSettings['invite_expire'] * 60 * 60 * 24 < time() - $row['inviteTime'])
			{
				if ($fatal)
					fatal_lang_error('registration_invite_expired', false);
				else
					return false;
			}

			// It's all good from here on! 
		}
		else
		{
			if ($fatal)
				fatal_lang_error('registration_invite_only', false);
			else
				return false;
		}

	}

	return $invite_key;
}


// Admin settings.  Called from ModifyInviteSettings() in ModSettigns.php
function InviteSettings()
{
	global $txt, $scripturl, $context, $settings, $sc, $sourcedir, $modSettings;

	$config_vars = array(
			array('text', 'invite_menu_title', 20, 'invite_menu_title'),
		'',
			array('check', 'invite_only'),
			array('int', 'invite_days'),
			array('int', 'invite_max'),
			array('int', 'invite_expire'),
		'',
			array('check', 'invite_email_disable'),
			array('text', 'invite_email_subject', 38, 'invite_email_subject'),
			array('large_text', 'invite_email_message', 8, 'invite_email_message'),
		'',
	);

	$config_vars[] = '<a href="' . $scripturl . '?action=permissions">' . $txt['invite_group_settings'] . '</a>';

	if (isset($_GET['save']))
	{
		saveDBSettings($config_vars);
		redirectexit('action=featuresettings;sa=invite');
	}

	if (empty($modSettings['invite_menu_title']))
		$modSettings['invite_menu_title'] = $txt['invite_title'];

	if (empty($modSettings['invite_email_subject']))
		$modSettings['invite_email_subject'] = $txt['invite_default_email_subject'];

	if (empty($modSettings['invite_email_message']))
		$modSettings['invite_email_message'] = $txt['invite_default_email_message'];

	$context['post_url'] = $scripturl . '?action=featuresettings2;save;sa=invite';
	$context['settings_title'] = $txt['invite_title'];

	prepareDBSettingContext($config_vars);
}


// Sets up the Invite page, and then send it off to the template.
function InviteMain()
{
	global $context, $ID_MEMBER, $db_prefix, $modSettings, $user_profile, $txt;

	if (!empty($_REQUEST['u']) && $memberResult = loadMemberData((int) $_REQUEST['u']))
		list ($memID) = $memberResult;
	else
		$memID = $ID_MEMBER;

	// Are you viewing your own, or someone else's?
	if ($ID_MEMBER == $memID)
		$context['user']['is_owner'] = true;
	else
		$context['user']['is_owner'] = false;

	// Load users invites from DB.
	$invites = array();
	$invitees = array();
	$request = db_query("
		SELECT inviteTime, inviteKey, inviteEmail, ID_REGISTRATION
		FROM {$db_prefix}invites
		WHERE ID_MEMBER = $memID", __FILE__, __LINE__);
	while ($row = mysql_fetch_assoc($request))
	{
		$invites[] = array(
			'inviteTime' => $row['inviteTime'],
			'inviteKey' => $row['inviteKey'],
			'inviteEmail' => $row['inviteEmail'],
			'ID_REGISTRATION' => $row['ID_REGISTRATION'],
		);
	}
	mysql_free_result($request);

	$now = time();

	if (empty($modSettings['invite_days']) || empty($modSettings['invite_only']) || allowedTo('invite_unlimited'))
	{
		// Unlimited.
		$context['invite_credits'] = -1;
	}
	else
	{
		$date_registered = $user_profile[$memID]['dateRegistered'];
		$period = 60 * 60 * 24 * $modSettings['invite_days'];
		$point_in_time = $date_registered;

		if (!empty($modSettings['invite_max']))
		{
			$current_credits = 0;

			foreach ($invites as $row)
			{
				// Invite credits at this point in time.
				$current_credits += ($row['inviteTime'] - $point_in_time) / $period;

				// Make sure it's never above the max.
				if ($current_credits > $modSettings['invite_max'])
					$current_credits = $modSettings['invite_max'];

				// Remove the one just sent.
				$current_credits--;

				// Prepare for next loop.
				$point_in_time = $row['inviteTime'];
			}

			// Add from last invite to now.
			$current_credits += ($now - $point_in_time) / $period;

			// Make sure it's never above the max.
			if ($current_credits > $modSettings['invite_max'])
				$current_credits = $modSettings['invite_max'];
		}
		else
		{
			$current_credits = ($now - $point_in_time) / $period - $invite_count;
		}
		
		// Make sure it's not below 0 (in case the options have been set lower than previously).
		if ($current_credits < 0)
			$current_credits = 0;

		$context['invite_credits'] = $current_credits;
		
		if (!empty($modSettings['invite_max']) && $modSettings['invite_max'] == $context['invite_credits'])
			$context['invite_next'] = '<i>(' . $txt['invite_max_reached'] . ')</i>';
		else
			$context['invite_next'] = timeformat($now - ($current_credits - intval($current_credits)) * $period + $period, true);
	}

	// Which subaction is it?
	if ($context['current_subaction'] == 'make')
		MakeInviteKey();
	elseif ($context['current_subaction'] == 'send')
		SendInviteMail();
	elseif ($context['current_subaction'] == 'mail' || empty($modSettings['invite_only']))
		InviteMail();
	else
		InvitePage($memID, $invites, $now);
}


// Generate a new key.
function MakeInviteKey()
{
	global $context, $db_prefix, $modSettings;

	isAllowedTo('invite');

	if (!$context['user']['is_owner'])
		fatal_lang_error('cannot_invite_as_other', false);

	checkSession();

	if (empty($context['invite_credits']))
		fatal_lang_error('cannot_make_key', false);

	// Make new key
	$context['invite_key'] = sha1(microtime());

	db_query("
		INSERT INTO {$db_prefix}invites
			(ID_MEMBER, inviteTime, inviteKey)
		VALUES ({$context['user']['id']}, " . time() . ", '" . sha1(microtime()) . "')", __FILE__, __LINE__);

	// Back to the main invite page.
	redirectexit('action=invite');
}


// Show the mail page.
function InviteMail()
{
	global $context, $db_prefix, $modSettings;

	if (!empty($modSettings['invite_email_disable']) && !empty($modSettings['invite_only']))
		redirectexit('action=invite');

	isAllowedTo('invite');

	if (!$context['user']['is_owner'])
		fatal_lang_error('cannot_invite_as_other', false);

	if (!empty($_REQUEST['invite_key']))
		$context['invite_key'] = $_REQUEST['invite_key'];

	// Load the template.
	$context['sub_template'] = 'mail';
	loadTemplate('Invite');
}


// Send the invite key.
function SendInviteMail()
{
	global $context, $sourcedir, $scripturl, $db_prefix, $txt, $modSettings;

	if (!empty($modSettings['invite_email_disable']))
		redirectexit('action=invite');

	isAllowedTo('invite');

	if (!$context['user']['is_owner'])
		fatal_lang_error('cannot_invite_as_other', false);

	if (empty($_REQUEST['recipient_name']))
		fatal_lang_error('invite_no_name', false);

	if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $_REQUEST['recipient_email']))
		fatal_lang_error('invite_no_email', false);

	$invite_key = $_REQUEST['invite_key'];

	// Check that the key hasn't already been sent.
	if(invite_key_email($invite_key))
		fatal_lang_error('cannot_send_invite', false);

	checkSession();


	// Get it all ready.
	$from = $context['user']['email'];
	$to = $_REQUEST['recipient_email'];

	$subject = !empty($modSettings['invite_email_subject']) ? $modSettings['invite_email_subject'] : $txt['invite_default_email_subject'];
	$message = !empty($modSettings['invite_email_message']) ? $modSettings['invite_email_message'] : $txt['invite_default_email_message'];

	$subject = str_replace('{invitee}', $_REQUEST['recipient_name'], $subject);
	$subject = str_replace('{inviter}', $context['user']['name'], $subject);
	$subject = str_replace('{forum}', $context['forum_name'], $subject);

	$message = str_replace('{invitee}', $_REQUEST['recipient_name'], $message);
	$message = str_replace('{inviter}', $context['user']['name'], $message);
	$message = str_replace('{forum}', $context['forum_name'], $message);
	$message = str_replace('{message}', $_REQUEST['invite_message'], $message);

	if (!empty($modSettings['invite_only']))
		$message = str_replace('{link}', $scripturl . '?action=register;invite_key=' . $invite_key, $message);
	else
		$message = str_replace('{link}', $scripturl . '?action=register;inviter=' . $context['user']['id'], $message);

	// Shwing!
	require_once($sourcedir . '/Subs-Post.php');
	if (!sendmail($to, $subject, $message, $from))
		fatal_lang_error('cannot_send_invite');
	
	if (!empty($modSettings['invite_only']))
		db_query("
			UPDATE {$db_prefix}invites
			SET inviteEmail = '$to'
			WHERE inviteKey = '$invite_key'
			LIMIT 1", __FILE__, __LINE__);

	// Back to the main invite page.
	redirectexit('action=invite;sent=true');
}


// Sets up the Invite page, and then send it off to the template.
function InvitePage($memID, $invites, $now)
{
	global $context, $ID_MEMBER, $txt, $user_profile, $memberContext, $db_prefix, $scripturl, $modSettings;

	// It's not the owner, and they're not allowed to view someone else's invitees.
	if (!$context['user']['is_owner'] && !allowedTo('invitees_any'))
		fatal_lang_error('cannot_invitees_any', false);

	// It's the owner, and they're not allowed to invite.
	if ($context['user']['is_owner'] && !allowedTo('invite'))
		fatal_lang_error('cannot_invite', false);


	// Remove expired (if set) and used keys.
	$context['invites'] = array();
	foreach ($invites as $row)
	{
		if ($row['ID_REGISTRATION'] == 0 && (empty($modSettings['invite_expire']) || $modSettings['invite_expire'] * 60 * 60 * 24 > $now - $row['inviteTime']))
			$context['invites'][] = $row;
	}

	$context['page_title'] = $txt['invite_someone'];

	// Load the template.
	loadTemplate('Invite');
}


// Returns the member id of the person who invited the specified user (false if not invited), and loads some $context stuff for template.  Called from template_summary() in Profile.template.php
function inviter($invitee_id)
{
	global $context, $user_profile, $db_prefix, $modSettings;

	$request = db_query("
		SELECT ID_MEMBER
		FROM {$db_prefix}invites
		WHERE ID_REGISTRATION = $invitee_id
		LIMIT 1", __FILE__, __LINE__);

	$row = mysql_fetch_assoc($request);
	mysql_free_result($request);

	if ($row)
	{
		$ID = $row['ID_MEMBER'];
		loadMemberData(array($ID));
		$context['member']['invited_by'] = $ID;
		$context['member']['invited_by_name'] = $user_profile[$ID]['realName'];
		return $ID;
	}
	else
		return false;
}


// Returns the number of members (including deleted members) the person has invited (false if no invitees).  Called from template_summary() in Profile.template.php
function invitees($inviter_id)
{
	global $context, $user_profile, $db_prefix, $modSettings;

	$request = db_query("
		SELECT COUNT(ID_REGISTRATION)
		FROM {$db_prefix}invites
		WHERE ID_MEMBER = $inviter_id
			AND ID_REGISTRATION != 0
		", __FILE__, __LINE__);

	$row = mysql_fetch_assoc($request);
	mysql_free_result($request);

	if ($row)
		return $row['COUNT(ID_REGISTRATION)'];
	else
		return false;
}


// Returns the email the key was sent to, or false if it wasn't sent or not found.
function invite_key_email($invite_key)
{
	global $context, $db_prefix;

	$request = db_query("
		SELECT inviteEmail
		FROM {$db_prefix}invites
		WHERE inviteKey = '$invite_key'
		LIMIT 1", __FILE__, __LINE__);

	$row = mysql_fetch_assoc($request);
	mysql_free_result($request);

	if (!empty($row['inviteEmail']))
		return $row['inviteEmail'];
	else
		return false;
}


// Stats!
function InviteStats()
{
	global $context, $user_profile, $db_prefix, $scripturl;

	$top_inviters_result = db_query("
		SELECT ID_MEMBER, ID_REGISTRATION
		FROM {$db_prefix}invites
		WHERE ID_REGISTRATION !=0
		", __FILE__, __LINE__);

	$top_inviters = array();
	$top_inviters_by_posts = array();
	$max_invitees = 1;
	$max_invitees2 = 1;

	while ($row = mysql_fetch_assoc($top_inviters_result))
	{
		$id = $row['ID_MEMBER'];

		if (loadMemberData(array($id)))
		{
			if (empty($top_inviters[$id]))
				$top_inviters[$id] = 1;
			else
				$top_inviters[$id]++;

			if ($max_invitees < $top_inviters[$id])
				$max_invitees = $top_inviters[$id];

			if (loadMemberData(array($row['ID_REGISTRATION']), false, 'minimal'))
			{
				if (empty($top_inviters_by_posts[$id]))
					$top_inviters_by_posts[$id] = (int)$user_profile[$row['ID_REGISTRATION']]['posts'];
				else
					$top_inviters_by_posts[$id] += (int)$user_profile[$row['ID_REGISTRATION']]['posts'];

			if ($max_invitees2 < $top_inviters_by_posts[$id])
				$max_invitees2 = $top_inviters_by_posts[$id];
			}
		}
	}
	mysql_free_result($top_inviters_result);

	$context['top_inviters'] = array();
	arsort($top_inviters);
	foreach ($top_inviters as $id => $num)
	{
		if (!empty($context['top_inviters']) && count($context['top_inviters']) == 10)
			break;

		if (!empty($user_profile[$id]['member_group_color']))
			 $color = ' style="color: ' . $user_profile[$id]['member_group_color'] . '"';
		elseif (!empty($user_profile[$id]['post_group_color']))
			 $color = ' style="color: ' . $user_profile[$id]['post_group_color'] . '"';
		else
			 $color = '';

		$context['top_inviters'][$id]['num'] = $num;
		$context['top_inviters'][$id]['link'] = '<a href="' . $scripturl . '?action=profile;u=' . $id . '"><span' . $color . '>' . $user_profile[$id]['realName'] . '</span></a>';
		$context['top_inviters'][$id]['percent'] = round(($num * 100) / $max_invitees);
	}

	$context['top_inviters_by_posts'] = array();
	arsort($top_inviters_by_posts);
	foreach ($top_inviters_by_posts as $id => $num)
	{
		if (!empty($context['top_inviters_by_posts']) && count($context['top_inviters_by_posts']) == 10)
			break;

		if (!empty($user_profile[$id]['member_group_color']))
			 $color = ' style="color: ' . $user_profile[$id]['member_group_color'] . '"';
		elseif (!empty($user_profile[$id]['post_group_color']))
			 $color = ' style="color: ' . $user_profile[$id]['post_group_color'] . '"';
		else
			 $color = '';

		$context['top_inviters_by_posts'][$id]['num'] = $num;
		$context['top_inviters_by_posts'][$id]['link'] = '<a href="' . $scripturl . '?action=profile;u=' . $id . '"><span' . $color . '>' . $user_profile[$id]['realName'] . '</span></a>';
		$context['top_inviters_by_posts'][$id]['percent'] = round(($num * 100) / $max_invitees2);
	}
}


// Top inviters, for TP blocks and stuff.
function top_inviters($limit = 5)
{
	global $user_profile, $db_prefix, $scripturl;

	$request = db_query("
		SELECT ID_MEMBER, COUNT(*) as invitees 
		FROM {$db_prefix}invites 
		WHERE ID_REGISTRATION != 0 
		GROUP BY ID_MEMBER
		ORDER BY invitees DESC
		LIMIT $limit
		", __FILE__, __LINE__);

	$top_inviters = array();

	while ($row = mysql_fetch_assoc($request))
	{
		$id = $row['ID_MEMBER'];

		if(loadMemberData(array($id)))
		{
			if (!empty($user_profile[$id]['member_group_color']))
				$color = ' style="color: ' . $user_profile[$id]['member_group_color'] . '"';
			elseif (!empty($user_profile[$id]['post_group_color']))
				$color = ' style="color: ' . $user_profile[$id]['post_group_color'] . '"';
			else
				$color = '';

			$top_inviters[$row['ID_MEMBER']] = array(
				'invitees' => '<a href="' . $scripturl . '?action=mlist;sa=search;inviter=' . $id . '">' . $row['invitees'] . '</a>',
				'name' => '<a href="' . $scripturl . '?action=profile;u=' . $id . '"><span' . $color . '>' . $user_profile[$id]['realName'] . '</span></a>',
			);
		}
	}
	mysql_free_result($request);

	return $top_inviters;
}


?>