<?php

// Outputs the invite page for sending invites and shows who the user has invited.
function template_main()
{
	global $context, $settings, $options, $txt, $scripturl, $user_profile, $modSettings;

	if (!empty($_REQUEST['sent']))
		echo '<div style="font-weight: bold; width: 100%; text-align: center; color: red; margin: 20px;">' . $txt['invite_sent'] . '</div>';

	// The invite keys.
	if (($context['user']['is_owner'] && allowedTo('invite')))
	{
		echo '
						<table border="0" width="100%" cellspacing="1" cellpadding="4" align="center" class="bordercolor">
							<tr class="titlebg">
								<td height="26">
									&nbsp;<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;
									', $txt['invite_someone'], '
								</td>
							</tr><tr class="windowbg">
								<td class="smalltext" height="25" style="padding: 2ex;">
									', $txt['invite_info'], '
								</td>
							</tr><tr>
								<td class="windowbg2" width="100%">
									<table width="100%" cellspacing="0" cellpadding="3" border="0">
										<tr>
											<td width="40%"><b>', $txt['invite_credits'], ': </b></td>';

		// Show current invite credits.
		if ($context['invite_credits'] === -1)
		{
			echo '
											<td><i>(', $txt['invite_unlimited'], ')</i></td>';
		}
		else
		{
			echo '
											<td>', intval($context['invite_credits']), '</td>
										</tr><tr>
											<td><b>', $txt['next_invite_credit'], ': </b></td>
											<td>', $context['invite_next'], '</td>';
		}

		// Show invite form if they have credits.
		if ($context['invite_credits'] !== 0)
		{
			echo '
										</tr><tr>
											<td colspan="2"><hr width="100%" size="1" class="hrcolor" /></td>
										</tr><tr>
											<td colspan="2" align="center">
												<form action="', $scripturl, '?action=invite;sa=make" method="post" accept-charset="', $context['character_set'], '" style="margin: 0;">
													<input type="submit" value="', $txt['make_new_invite_key'], '" />
													<input type="hidden" name="sc" value="', $context['session_id'], '" />
												</form>
											</td>';
		}

		echo '
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<br />';

		// Show active invite keys.
		if (count($context['invites']) !== 0)
		{
			echo '
						<table width="100%" cellspacing="1" cellpadding="4" border="0" align="center" class="bordercolor">
							<tr class="catbg3">
								<td>', $txt['invite_key'], '</td>';
			
			if (empty($modSettings['invite_email_disable']))
				echo '
								<td>', $txt['invite_email'], '</td>';

			// Display expiration date?
			if (!empty($modSettings['invite_expire']))
				echo '
								<td>', $txt['invite_expires'], '</td>';

			foreach ($context['invites'] as $row)
			{
				echo '
							</tr>
							<tr>
								<td class="windowbg"><a href="', $scripturl, '?action=register;invite_key=', $row['inviteKey'], '">', $row['inviteKey'], '</a></td>';
				
				if (empty($modSettings['invite_email_disable']))
				{
					echo '
								<td class="windowbg">';

					if (!empty($row['inviteEmail']))
						echo $row['inviteEmail'];
					else
						echo '<a href="', $scripturl, '?action=invite;sa=mail;invite_key=', $row['inviteKey'], '">', (!empty($row['inviteEmail']) ? $row['inviteEmail'] : $txt['invite_send_email']), '</a>';

					echo '</td>';
				}
							
				// Display expiration date?
				if (!empty($modSettings['invite_expire']))
					echo '
								<td class="windowbg">', timeformat($row['inviteTime'] + $modSettings['invite_expire'] * 60 * 60 * 24), '</td>';
			}

			echo '
						</tr>
					</table>';
		}
	}
}


// Outputs the page page for emailing invite keys.
function template_mail()
{
	global $context, $settings, $options, $txt, $scripturl, $user_profile, $modSettings;

	if (!empty($_REQUEST['sent']))
		echo '<div style="font-weight: bold; width: 100%; text-align: center; color: red; margin: 20px;">' . $txt['invite_sent'] . '</div>';

	if (empty($modSettings['invite_only']))
		echo '
					<table border="0" width="85%" cellspacing="1" cellpadding="4" align="center" class="bordercolor" style="margin-bottom: 20px;">
						<tr class="titlebg">
							<td height="26">
								&nbsp;<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;
								', $txt['invite_someone'], '
							</td>
						</tr><tr class="windowbg">
							<td class="smalltext" height="25" style="padding: 2ex;">
								', $txt['invite_link'], '
							</td>
						</tr><tr class="windowbg2">
							<td class="smalltext" height="25" style="padding: 2ex;">
								<a href="', $scripturl, '?action=register;inviter=', $context['user']['id'], '">', $scripturl, '?action=register;inviter=', $context['user']['id'], '</a>
							</td>
						</tr>
					</table>';
	
	if (empty($modSettings['invite_email_disable']))
		echo '
					<form action="', $scripturl, '?action=invite;sa=send" method="post" accept-charset="', $context['character_set'], '" style="margin: 0;">
						<table border="0" width="85%" cellspacing="1" cellpadding="4" align="center" class="bordercolor">
							<tr class="titlebg">
								<td height="26">
									&nbsp;<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" align="top" />&nbsp;
									', $txt['invite_email'], '
								</td>
							</tr><tr class="windowbg">
								<td class="smalltext" height="25" style="padding: 2ex;">
									', $txt['invite_email_info'], '
								</td>
							</tr><tr>
								<td class="windowbg2" width="100%">

									<table width="100%" cellspacing="0" cellpadding="3" border="0">
										<tr>
											<td width="30%"><b>', $txt['invite_recipient_name'], ': </b></td>
											<td width="60%"><input type="text" name="recipient_name" value="" style="width: 90%;" /></td>
										</tr><tr>
											<td><b>', $txt['invite_recipient_email'], ': </b></td>
											<td><input type="text" name="recipient_email" value="" style="width: 90%;" /></td>
										</tr><tr>
											<td><b>', $txt['invite_message'], ': </b></td>
											<td><textarea name="invite_message" rows="4" style="width: 90%;"></textarea></td>
										</tr><tr>
											<td colspan="2" align="center">
												<input type="submit" value="', $txt['invite_send_email'], '" />
												<input type="hidden" name="sc" value="', $context['session_id'], '" />
												<input type="hidden" name="invite_key" value="', !empty($context['invite_key']) ? $context['invite_key'] : '', '" />
											</td>
										</tr>
									</table>

								</td>
							</tr>
						</table>
					</form>';
}

?>