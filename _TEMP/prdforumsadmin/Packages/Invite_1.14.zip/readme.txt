This MOD adds an invite system to SMF.  Users get invite credits which they can use to invite people to the forum, and showing who invited whom.  The forum can also be set to only accept registrations through invitations, meaning that you need to be invited to join.

Admin options are in "Features and Options" -> "Invite", and "Manage Permissions".

As always, I'm open to feedback and improvement ideas.


Changelog:

1.14 (May 15, 2007)
- Fixed incompatibility with older MySQL version in db.php.
- Improved compatibility with other mods that also change the permissions.

1.13 (Mar 21, 2007)
- Added "Invited By" edit box on the Account Related Settings, so the admin can easily set the inviter of a member.
- Fixed unlimited credits permission being available as a guest permission.

1.12 (Mar 13, 2007)
- Changed how the mod works when "invitation only" isn't set; instead of invite keys, an inviter can use the same link several times.
- Added permission to grant membergroups unlimited credits.
- Fixed the top_inviter() function for block code so it sorts the inviters properly.

1.11 (Mar 10, 2007)
- Fixed uninitialised array from 1.10.

1.10 (Mar 10, 2007)
- Added Stats.
- Added option to disable mailing feature.
- Increased compatibility with other mods that also add a new menu button.

1.09 (Mar 08, 2007)
- Moved the invitees list to the member list page instead, so it looks the same as the regular member list. 
- In the profile summary, added "Members Invited" count and removed the old link at the bottom. 

1.08 (Mar 06, 2007)
- [Invite.php]  Fixed two undefined globals, caused when I moved stuff around for 1.06.
- [Invite.php]  Fixed a bug that incorrectly calculated the credits based on the admin's registration date instead of the user's.

1.07 (Mar 06, 2007)
- [Invite.php]  Fixed undefined variable notice.

1.06 (Mar 05, 2007)
- Moved it from the profile to it's own page with it's own menu link.
- Added mailing feature.
- Further reduced the number of changes made to the SMF code.
- Other minor stuff I don't remember.

1.05 (Mar 05, 2007)
- Removed text that said the forum only accepted invitations through invitation even when that wasn't true.
- Increased compatibility with other mods that also change the profile summary page's "Additional Information" area (notably "Show Topics").
- Reduced the number of changes made to the SMF code.

1.04 (Mar 04, 2007)
- Fixed bug that didn't set the inviter and caused a undefined variable notice (caused by renaming a variable and good ol' copy+paste).

1.03 (Mar 01, 2007)
- Added input field on the registration "invitation only" page so the invite key can be entered manually.
- Fixed undefined index notice in Register.php when invite_key is not set.
- Fixed bug that displayed deleted members in the invitees list.

1.02 (Feb 20, 2007)
- Security improvement.
- Minor SMF-conformity fixes.

1.01 (Feb 02, 2007)
- Fixed bug that didn't send the invite key properly to the registration template.
- Fixed bug that still displayed used keys in the invite screen if keys were set to not expire.

1.00 (Jan 30, 2007)
- Initial release.