[b]Custom Tab[/b]

Version: 1.2 Date 2008-11-24
Compatibility: SMF 1.1.6-1.1.7, SMF 2.0 Beta 4

[b]Features[/b]

Adds a new custom tab with a label and URL of your choosing. You select whether guests, members or both can see and use the custom tab.

[b]Configuration[/b]

[i]Custom Tab[/i] configuration settings are located in Admin -> Configuration -> Modifications -> Custom Tab (SMF 2.0) or in Admin -> Configuration -> Features and Options -> Custom Tab (SMF 1.1.6). The following settings are provided:

[list]
[li][b]Allow guest access[/b]: Enable to allow guests to use the tab.[/li]
[li][b]Allow member access[/b]: Enable to allow members to use the tab.[/li]
[li][b]Custom tab label[/b]: Enter your label text here. Defaults to CUSTOM.[/li]
[li][b]Custom tab execute URL[/b]: Enter your URL here. Defaults to your forum's main index URL.[/li]
[/list]

[b]Important note:[/b] You must enable either "allow guest access" or "allow member access" or nobody will be able to see or use your custom tab.


[b]Support[/b]

You may get support or submit questions and comments in the modification's [url=http://www.simplemachines.org/community/index.php?topic=262449.0]support topic[/url] at the SMF site.

[b]Donations[/b]

[table][tr][td][url=https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=1400104][img]https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif[/img][/url][/td][td]      [/td][td]If you like my modification packages, please donate to support their continued development. Any amount will be greatly appreciated. Thank you![/td][/tr][/table]

[size=1]Copyright (c) 2008 by Deprecated (at) Earthlink (dot) net. All rights reserved. Redistribution prohibited except at SimpleMachines.org[/size]