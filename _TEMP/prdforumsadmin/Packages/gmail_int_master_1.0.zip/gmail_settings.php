<?php

// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');

	
elseif( !defined('SMF') )
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');
 
	db_query("
ALTER TABLE {$db_prefix}members ADD COLUMN
gmail VARCHAR(50) NOT NULL default ''", __FILE__, __LINE__);

if( SMF == 'SSI' )
   echo '<b>The GMAIL settings has been added~.</b>';

?>