/**
 * Internal dependencies
 */
import LikesCheckbox from './likes-checkbox';

export const name = 'likes';

export const settings = { render: LikesCheckbox };
