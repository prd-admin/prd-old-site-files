/**
 * Internal dependencies
 */
import { name, settings } from '.';
import registerJetpackPlugin from '../../shared/register-jetpack-plugin';

registerJetpackPlugin( name, settings );
