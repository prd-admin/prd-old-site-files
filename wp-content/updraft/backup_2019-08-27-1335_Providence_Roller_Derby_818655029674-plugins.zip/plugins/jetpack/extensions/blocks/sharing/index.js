/**
 * Internal dependencies
 */
import SharingCheckbox from './sharing-checkbox';

export const name = 'sharing';

export const settings = { render: SharingCheckbox };
