/**
 * Internal dependencies
 */
import registerJetpackBlock from '../../shared/register-jetpack-block';
import { childBlocks, name, settings } from '.';

registerJetpackBlock( name, settings, childBlocks );
