// Created by iWeb 3.0.1 local-build-20100521

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWStrokeParts([{rect:new IWRect(-1,1,2,163),url:'Welcome_files/stroke.png'},{rect:new IWRect(-1,-1,2,2),url:'Welcome_files/stroke_1.png'},{rect:new IWRect(1,-1,698,2),url:'Welcome_files/stroke_2.png'},{rect:new IWRect(699,-1,2,2),url:'Welcome_files/stroke_3.png'},{rect:new IWRect(699,1,2,163),url:'Welcome_files/stroke_4.png'},{rect:new IWRect(699,164,2,2),url:'Welcome_files/stroke_5.png'},{rect:new IWRect(1,164,698,2),url:'Welcome_files/stroke_6.png'},{rect:new IWRect(-1,164,2,2),url:'Welcome_files/stroke_7.png'}],new IWSize(700,165)),shadow_2:new IWShadow({blurRadius:11,offset:new IWPoint(-2.3474,4.4147),color:'#3a060f',opacity:0.210000}),shadow_0:new IWShadow({blurRadius:2,offset:new IWPoint(1.0000,0.0000),color:'#3a060f',opacity:1.000000}),shadow_1:new IWShadow({blurRadius:9,offset:new IWPoint(-2.4404,5.4813),color:'#000000',opacity:0.206897})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Welcome_files/WelcomeMoz.css')
fixAllIEPNGs('Media/transparent.gif');applyEffects()}
