// Created by iWeb 3.0.1 local-build-20100521

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({shadow_0:new IWShadow({blurRadius:3,offset:new IWPoint(0.1745,4.9970),color:'#3a060f',opacity:0.500000}),shadow_1:new IWShadow({blurRadius:3,offset:new IWPoint(0.1745,4.9970),color:'#3a060f',opacity:0.500000}),stroke_0:new IWStrokeParts([{rect:new IWRect(-2,0,4,132),url:'Contact_files/stroke.png'},{rect:new IWRect(-2,-2,4,2),url:'Contact_files/stroke_1.png'},{rect:new IWRect(2,-2,128,2),url:'Contact_files/stroke_2.png'},{rect:new IWRect(130,-2,5,2),url:'Contact_files/stroke_3.png'},{rect:new IWRect(130,0,5,132),url:'Contact_files/stroke_4.png'},{rect:new IWRect(130,132,5,3),url:'Contact_files/stroke_5.png'},{rect:new IWRect(2,132,128,3),url:'Contact_files/stroke_6.png'},{rect:new IWRect(-2,132,4,3),url:'Contact_files/stroke_7.png'}],new IWSize(133,133))});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Contact_files/ContactMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');fixAllIEPNGs('Media/transparent.gif');applyEffects()}
